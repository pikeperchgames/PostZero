#include "il2cpp-config.h"
#include "C:\Program Files\Unity\Hub\Editor\2020.2.1f1\Editor\Data\il2cpp\libil2cpp\codegen\il2cpp-codegen-common.cpp"
#include "C:\Program Files\Unity\Hub\Editor\2020.2.1f1\Editor\Data\il2cpp\libil2cpp\codegen\il2cpp-codegen-il2cpp.cpp"
#include "C:\Program Files\Unity\Hub\Editor\2020.2.1f1\Editor\Data\il2cpp\libil2cpp\codegen\il2cpp-codegen-tiny.cpp"
