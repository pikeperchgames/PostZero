﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 UnityEngine.InputSystem.InputActionAsset PlayerInput::get_asset()
extern void PlayerInput_get_asset_mC78B60CC7CCB2D77F076FE53BEB9B265241123DE (void);
// 0x00000002 System.Void PlayerInput::.ctor()
extern void PlayerInput__ctor_m84EAB041CD5C8D268A3C5741EC3A70B5F1E47B20 (void);
// 0x00000003 System.Void PlayerInput::Dispose()
extern void PlayerInput_Dispose_m560794A2B84F1C6308F607BF82B1E4A1EDF38E21 (void);
// 0x00000004 System.Nullable`1<UnityEngine.InputSystem.InputBinding> PlayerInput::get_bindingMask()
extern void PlayerInput_get_bindingMask_m83EC78F082519231793D2384AE79AD073326D42D (void);
// 0x00000005 System.Void PlayerInput::set_bindingMask(System.Nullable`1<UnityEngine.InputSystem.InputBinding>)
extern void PlayerInput_set_bindingMask_m9921F2BADFADAC2E62F410BCB79DD0D2D512D629 (void);
// 0x00000006 System.Nullable`1<UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.InputDevice>> PlayerInput::get_devices()
extern void PlayerInput_get_devices_mAA2B0EE7E5CD6C60BB63F582828D00B6E80DA125 (void);
// 0x00000007 System.Void PlayerInput::set_devices(System.Nullable`1<UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.InputDevice>>)
extern void PlayerInput_set_devices_mC8B1B8AE41EEB805BD39504612A6540ADF0A0F22 (void);
// 0x00000008 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.InputControlScheme> PlayerInput::get_controlSchemes()
extern void PlayerInput_get_controlSchemes_m8E11232C93DD0644BBD67AEB9FEA9E503AE7F4FB (void);
// 0x00000009 System.Boolean PlayerInput::Contains(UnityEngine.InputSystem.InputAction)
extern void PlayerInput_Contains_m0CDC3D9D39D268FC1F77854CA7C164F996E78B69 (void);
// 0x0000000A System.Collections.Generic.IEnumerator`1<UnityEngine.InputSystem.InputAction> PlayerInput::GetEnumerator()
extern void PlayerInput_GetEnumerator_m4CC727A8CC35520DB0BCC60C684C305C8D4CD45E (void);
// 0x0000000B System.Collections.IEnumerator PlayerInput::System.Collections.IEnumerable.GetEnumerator()
extern void PlayerInput_System_Collections_IEnumerable_GetEnumerator_mC4FB5A6DEF54DCC127F7710AE1CE80BFAE93E46A (void);
// 0x0000000C System.Void PlayerInput::Enable()
extern void PlayerInput_Enable_m51F97ADF330547539E0B99A3FB8139ADD5266D93 (void);
// 0x0000000D System.Void PlayerInput::Disable()
extern void PlayerInput_Disable_m7E5A729CAA47FB37AF38169AED455C8350E6F68C (void);
// 0x0000000E PlayerInput/PlayerActions PlayerInput::get_Player()
extern void PlayerInput_get_Player_m18604B7BFF2979B66AE83701382A91B443478AEE (void);
// 0x0000000F PlayerInput/UIActions PlayerInput::get_UI()
extern void PlayerInput_get_UI_m01844472D946D17968818A9DEC67B59275FEE61F (void);
// 0x00000010 UnityEngine.InputSystem.InputControlScheme PlayerInput::get_KeyboardMouseScheme()
extern void PlayerInput_get_KeyboardMouseScheme_m6F89017A0ED98B6A2C94A6B75E4BB7933DDC8013 (void);
// 0x00000011 UnityEngine.InputSystem.InputControlScheme PlayerInput::get_GamepadScheme()
extern void PlayerInput_get_GamepadScheme_m10343193095A7E03C5F80FC4F78721DE8AE3CA0F (void);
// 0x00000012 UnityEngine.InputSystem.InputControlScheme PlayerInput::get_TouchScheme()
extern void PlayerInput_get_TouchScheme_m7087ABDB63E3ED31FC62E0191B757CD81741FC4D (void);
// 0x00000013 UnityEngine.InputSystem.InputControlScheme PlayerInput::get_JoystickScheme()
extern void PlayerInput_get_JoystickScheme_m3CC962C473A0E328628114C116A48EC33CAE4243 (void);
// 0x00000014 UnityEngine.InputSystem.InputControlScheme PlayerInput::get_XRScheme()
extern void PlayerInput_get_XRScheme_m1F640E895BCEA2DB8A2ECFFAF8338F24BB257401 (void);
// 0x00000015 System.Void ArrowSc::Start()
extern void ArrowSc_Start_m9E9D983300A7A1F4AB2A558B10B6FC2C66011A68 (void);
// 0x00000016 System.Collections.IEnumerator ArrowSc::BecomeVisible()
extern void ArrowSc_BecomeVisible_m607B52899DBF72D3CDFF374CDC77F54F19580BE0 (void);
// 0x00000017 System.Void ArrowSc::OnTriggerStay2D(UnityEngine.Collider2D)
extern void ArrowSc_OnTriggerStay2D_m05BCFEB0244DC0C2DFC39493003A86E5E6344D76 (void);
// 0x00000018 System.Void ArrowSc::.ctor()
extern void ArrowSc__ctor_mA422E3D011315EEAEAA5CB27F3A803633DEEC08C (void);
// 0x00000019 System.Void BOSS_0::Start()
extern void BOSS_0_Start_m8BED97B629B3ADBBBDB92ECE8CF182B4E67086FA (void);
// 0x0000001A System.Void BOSS_0::Update()
extern void BOSS_0_Update_m3D7063D2687E5EE5F18FCA9C613CC83032767E13 (void);
// 0x0000001B System.Void BOSS_0::.ctor()
extern void BOSS_0__ctor_m5253215D4889421E3D9F380C99B53C63A1702ABE (void);
// 0x0000001C System.Void BoulderSc::OnTRiggerEnter(UnityEngine.Collider)
extern void BoulderSc_OnTRiggerEnter_m34C131B4649107E34883E33B84433B09FFE77F3D (void);
// 0x0000001D System.Void BoulderSc::Update()
extern void BoulderSc_Update_m55931E3F3B21E700F52632D53D6CF2D5454D6C79 (void);
// 0x0000001E System.Void BoulderSc::.ctor()
extern void BoulderSc__ctor_m050573D3CC89045A62E2252034CBEF6026661D4B (void);
// 0x0000001F System.Void BoxScr::boxUp()
extern void BoxScr_boxUp_mC467181AFDA4F62BA95C03E18373153A961693C4 (void);
// 0x00000020 System.Void BoxScr::boxDown()
extern void BoxScr_boxDown_m521788419D0508321B2A25B75D5660FBE451EDCB (void);
// 0x00000021 System.Void BoxScr::Update()
extern void BoxScr_Update_m2EF84F1794DF4938DD4DD4F58891ACD8563B1D5C (void);
// 0x00000022 System.Collections.IEnumerator BoxScr::ups()
extern void BoxScr_ups_m29215AB1357DE8E47DEB8E2DC788DB33E32F6C42 (void);
// 0x00000023 System.Collections.IEnumerator BoxScr::waiter()
extern void BoxScr_waiter_m09F6F43F18DA8FD9CC30C6CEBDC13A8A95804335 (void);
// 0x00000024 System.Void BoxScr::OnCollisionEnter(UnityEngine.Collision)
extern void BoxScr_OnCollisionEnter_m6A7B1B6FCE7CF9D2598C11662D492760CBC7FA20 (void);
// 0x00000025 System.Void BoxScr::.ctor()
extern void BoxScr__ctor_mF7B446E20E8D26792537B1CBC665E23C004CC71D (void);
// 0x00000026 System.Void ButtonSc::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void ButtonSc_OnTriggerEnter2D_m9F0BAEDB17DF9C460F25AAD73AE7708870168D2B (void);
// 0x00000027 System.Void ButtonSc::OnCollisionEnter2D(UnityEngine.Collision2D)
extern void ButtonSc_OnCollisionEnter2D_m4BD57739A6BA92246E0627B745F3C3020265E089 (void);
// 0x00000028 System.Void ButtonSc::Start()
extern void ButtonSc_Start_mC8EC1EFE9360D8D308D8AAE954B8C9F5E72D49D4 (void);
// 0x00000029 System.Void ButtonSc::.ctor()
extern void ButtonSc__ctor_m143C1A3FD712CAB95732AE188190130CA900C59E (void);
// 0x0000002A System.Void CameraSc::Start()
extern void CameraSc_Start_m516A79399CE9523A9FD6CCDAF6936D7EA53A6400 (void);
// 0x0000002B System.Void CameraSc::FixedUpdate()
extern void CameraSc_FixedUpdate_m79E2BC8B177F02AF2AA48D99FD918DF3191C1FC6 (void);
// 0x0000002C System.Void CameraSc::.ctor()
extern void CameraSc__ctor_m5E12DD1E2F518495510434311F2816C6D00D920A (void);
// 0x0000002D System.Void CasetteSc::Start()
extern void CasetteSc_Start_m27337322FC8A555BA59BC1AA87E775CA6B38F3CB (void);
// 0x0000002E System.Void CasetteSc::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void CasetteSc_OnTriggerEnter2D_m6A99490E7087C0D598365C8F4FFB3F325768DFE8 (void);
// 0x0000002F System.Void CasetteSc::.ctor()
extern void CasetteSc__ctor_mD5BC88FD6DC0BD9E44B2A282068E2ACD05775086 (void);
// 0x00000030 System.Void CloudSc::Start()
extern void CloudSc_Start_mB7256E0E06134219FC0FD9B80BB2F65A6CAD88D3 (void);
// 0x00000031 System.Void CloudSc::Update()
extern void CloudSc_Update_m22F1B34C010067CEA72A0B5A15BC486AADC46D2A (void);
// 0x00000032 System.Void CloudSc::.ctor()
extern void CloudSc__ctor_m3A5612EECE8B11C73571C720848176A2A11A0FF5 (void);
// 0x00000033 System.Void DialogClass::.ctor()
extern void DialogClass__ctor_m0227510E78FF17BEBED70CFDE581B686D57EEF29 (void);
// 0x00000034 System.Void DoorSc::OpenDoor()
extern void DoorSc_OpenDoor_m358D28BB4086607F5656F56FE5F87C5F7F4C4226 (void);
// 0x00000035 System.Void DoorSc::.ctor()
extern void DoorSc__ctor_mC9A875CE2C54A6ED6733DF407277C94DBA444D71 (void);
// 0x00000036 System.Void ElectrSpawnerSc::Start()
extern void ElectrSpawnerSc_Start_m0F3F93A0933B092C9D52B4FF9DF224D81B016A02 (void);
// 0x00000037 System.Void ElectrSpawnerSc::Update()
extern void ElectrSpawnerSc_Update_mA847DC1E0AF6A14CD9064F02B4C0194D6994C772 (void);
// 0x00000038 System.Void ElectrSpawnerSc::.ctor()
extern void ElectrSpawnerSc__ctor_mDE9E23C61659DFC8CA2EF519EAC23A084FAF537C (void);
// 0x00000039 System.Void EndSc::Start()
extern void EndSc_Start_mD9D051BF13133222865E9D50D13771C4402334B5 (void);
// 0x0000003A System.Void EndSc::OnTriggerEnter()
extern void EndSc_OnTriggerEnter_m2327050344D4C2463C227A0C16F0793983254221 (void);
// 0x0000003B System.Void EndSc::tomenu()
extern void EndSc_tomenu_m26362070E402D0C350130AC8D3CBB13844388565 (void);
// 0x0000003C System.Void EndSc::.ctor()
extern void EndSc__ctor_m0A312E4B0C6982AD6A6CD50C23405F5F83C0D41F (void);
// 0x0000003D System.Void EnemyPathfindingSc::Start()
extern void EnemyPathfindingSc_Start_m4A6905D346FC00A2202A59D6FB60546B589C4E01 (void);
// 0x0000003E System.Void EnemyPathfindingSc::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void EnemyPathfindingSc_OnTriggerEnter2D_mEE70320011D3A7ED407BEE62D605D25BFE18B608 (void);
// 0x0000003F System.Void EnemyPathfindingSc::Update()
extern void EnemyPathfindingSc_Update_mF5AC17D9236078CFF8854215DA7DBCA95489CAC3 (void);
// 0x00000040 System.Void EnemyPathfindingSc::.ctor()
extern void EnemyPathfindingSc__ctor_m560259CC98ED686FF29616BFB1B47E4372162A33 (void);
// 0x00000041 System.Void EnemySc::Start()
extern void EnemySc_Start_m1404F2D572B6E646585EEDC27B10467BA0CD5125 (void);
// 0x00000042 System.Void EnemySc::OnTriggerStay2D(UnityEngine.Collider2D)
extern void EnemySc_OnTriggerStay2D_m6D87DD9C75D2E19DA74DA406A8DC7DE308C7805B (void);
// 0x00000043 System.Void EnemySc::OnTriggerExit2D(UnityEngine.Collider2D)
extern void EnemySc_OnTriggerExit2D_m03359A7924DF96E71A9BAE0D673800FCC1669D1F (void);
// 0x00000044 System.Void EnemySc::Update()
extern void EnemySc_Update_mBC73144AB4DF98F2592E25798D0D1759EB57820B (void);
// 0x00000045 System.Void EnemySc::.ctor()
extern void EnemySc__ctor_mB3A84D228C2250D330F3E6C747C4029DC1E587AC (void);
// 0x00000046 System.Void FPS_counterSC::Update()
extern void FPS_counterSC_Update_mD6102DD1D12AAFEDB1E0B2A854B2310BF269FFB3 (void);
// 0x00000047 System.Void FPS_counterSC::.ctor()
extern void FPS_counterSC__ctor_m72ACE900CE5395F07F6FF53E4ED12C43D0375B5E (void);
// 0x00000048 System.Void HPSc::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void HPSc_OnTriggerEnter2D_m47F605C9C4BF7F92D9CA12EE7E9E6F3709CC81EB (void);
// 0x00000049 System.Void HPSc::.ctor()
extern void HPSc__ctor_m67DEA251061B7A9FAEC8F072B61CEE3297A1CF4D (void);
// 0x0000004A System.Void JustDamageSc::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void JustDamageSc_OnTriggerEnter2D_m7AEC56362B362047F38031D6D3850AE1C297DF6E (void);
// 0x0000004B System.Void JustDamageSc::Explosion2D()
extern void JustDamageSc_Explosion2D_m8BF924B101B76F3D618852AC325833D690A75951 (void);
// 0x0000004C System.Void JustDamageSc::.ctor()
extern void JustDamageSc__ctor_mC782102A5CB82C85DE06C51DE84DC54277E8D488 (void);
// 0x0000004D Manager Manager::get_instance()
extern void Manager_get_instance_m16C2387DFC1CF5D61C4A5B613DFEC70E6F4DB3EC (void);
// 0x0000004E System.Void Manager::Awake()
extern void Manager_Awake_mC363EF8F87DCFA0409A492A299F31059706F425B (void);
// 0x0000004F System.Void Manager::SetVolume(System.Single)
extern void Manager_SetVolume_m406BC1666BFE409993E657AB6933744B8D09D565 (void);
// 0x00000050 System.Void Manager::restart()
extern void Manager_restart_m72E4C2908B1A7984F33861922B5B71EB24D97865 (void);
// 0x00000051 System.Void Manager::end()
extern void Manager_end_m1A031C140591F4BA544DB755847BE0961F626BF1 (void);
// 0x00000052 System.Collections.IEnumerator Manager::Waitsc()
extern void Manager_Waitsc_m3816352955CC93F6E795A7C74117D57203078E87 (void);
// 0x00000053 System.Void Manager::leave()
extern void Manager_leave_m9096705338FAB276F16CC16BBEDAA665D2B96B38 (void);
// 0x00000054 System.Boolean Manager::TryShoot()
extern void Manager_TryShoot_m83F64870E09B68CFE752A873C15A31A3F3933239 (void);
// 0x00000055 System.Void Manager::RestoreRocks()
extern void Manager_RestoreRocks_m80B3DE39C026365CC525C5D452B66DCDC2524BE7 (void);
// 0x00000056 System.Void Manager::getDMG()
extern void Manager_getDMG_m2292BB3F9E122669939CDA576F1370D681D6F8D3 (void);
// 0x00000057 System.Void Manager::Kill()
extern void Manager_Kill_mD63E2152C826A21F4640AAF0C9713203A13270E2 (void);
// 0x00000058 System.Void Manager::getHP()
extern void Manager_getHP_m0050B333DB0E55EB4F65DEEFB3E19B416C1391F5 (void);
// 0x00000059 System.Void Manager::Magnetize()
extern void Manager_Magnetize_m0A51DBB7DF5D97DADBDEC92B0CE70CC6C97A2CE8 (void);
// 0x0000005A System.Void Manager::AddSong(System.Int32)
extern void Manager_AddSong_mA3C19C86C9E1C4CD35D062ADB0A83CC9057CDF69 (void);
// 0x0000005B System.Void Manager::Update()
extern void Manager_Update_m75BF2DFC9C300743E190F02E9D8427F36DB70780 (void);
// 0x0000005C System.Void Manager::.ctor()
extern void Manager__ctor_m5B9F7AAE653DB0466943D59D3579FFCCFC32631E (void);
// 0x0000005D System.Void Manager::.cctor()
extern void Manager__cctor_m7514095565A4683A758C58B38A884559DDDD4609 (void);
// 0x0000005E System.Void MenuSc::SetVolume(System.Single)
extern void MenuSc_SetVolume_mA62B7A565EC3B9972479EB9E9B1177703DDCA9C5 (void);
// 0x0000005F System.Void MenuSc::Update()
extern void MenuSc_Update_m3D77170225FA09AC17984B5616DA0C9C9778D74D (void);
// 0x00000060 System.Void MenuSc::.ctor()
extern void MenuSc__ctor_mCAF59BB8937F35FF67CDBCCD8105EC9C0A823A78 (void);
// 0x00000061 System.Void MinibombSc::Start()
extern void MinibombSc_Start_m276096720A33D49EB04968701C7F84D6FAE65D55 (void);
// 0x00000062 System.Collections.IEnumerator MinibombSc::BecomeVisible()
extern void MinibombSc_BecomeVisible_mF343236546791E9BB70FECA4CCF5208F904A18EF (void);
// 0x00000063 System.Void MinibombSc::OnTriggerStay2D(UnityEngine.Collider2D)
extern void MinibombSc_OnTriggerStay2D_mE9895BC572A8CFD26952A246E2661FBA339691EA (void);
// 0x00000064 System.Void MinibombSc::Explosion2D()
extern void MinibombSc_Explosion2D_mCCFC12965992111F81F1DF14DC69FE7D77389828 (void);
// 0x00000065 System.Boolean MinibombSc::CanUse(UnityEngine.Vector3,UnityEngine.Rigidbody2D)
extern void MinibombSc_CanUse_m88CC37C2713A9DB763151479ACA491D5651C099B (void);
// 0x00000066 System.Void MinibombSc::.ctor()
extern void MinibombSc__ctor_mC9830F2A7DD8759304EFED032C7E72AF81975912 (void);
// 0x00000067 System.Void MoveHorSc::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void MoveHorSc_OnTriggerEnter2D_m9A1B4A62C414E0E02B832BBA6AD41B79C6726128 (void);
// 0x00000068 System.Void MoveHorSc::Update()
extern void MoveHorSc_Update_m9ED656D99A357616641EDE44567734FFE0B81BBE (void);
// 0x00000069 System.Void MoveHorSc::.ctor()
extern void MoveHorSc__ctor_mB8A8E76BDF8C439A31BF843385EA8B5D43657999 (void);
// 0x0000006A System.Void MovingPlatformSc::Start()
extern void MovingPlatformSc_Start_m003DE983DB317F5E07335755B70C533B2E7ADE67 (void);
// 0x0000006B System.Void MovingPlatformSc::FixedUpdate()
extern void MovingPlatformSc_FixedUpdate_mFC5CBDA538D7F52E206E680A7F02C53A19800231 (void);
// 0x0000006C System.Void MovingPlatformSc::.ctor()
extern void MovingPlatformSc__ctor_m6959AE80DA1815A97089698DB4FB40025E21F56C (void);
// 0x0000006D System.Void NPCSc::.ctor()
extern void NPCSc__ctor_m0149A666A067F8EE0D74DF54E8226C2483283577 (void);
// 0x0000006E System.Void NextLevelSc::Awake()
extern void NextLevelSc_Awake_m8714FA706AE38511071EC3A65B8A4DE7CA115778 (void);
// 0x0000006F System.Void NextLevelSc::Update()
extern void NextLevelSc_Update_m07EA610DE31486AA76FE3914853F612041B7B965 (void);
// 0x00000070 System.Void NextLevelSc::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void NextLevelSc_OnTriggerEnter2D_m40CB8D1F76C91445B62D2559616177305B73A146 (void);
// 0x00000071 System.Void NextLevelSc::nl()
extern void NextLevelSc_nl_m1BBC91707604B99B10AF944BEDD3C654F1B5B43E (void);
// 0x00000072 System.Void NextLevelSc::EndScene()
extern void NextLevelSc_EndScene_mBBCF920413B3E2C015D9A885EEF31B60822351A2 (void);
// 0x00000073 System.Void NextLevelSc::.ctor()
extern void NextLevelSc__ctor_m3A7150BEDEAD0081153EE54D7A307AE2DABFDC19 (void);
// 0x00000074 System.Void PikupMovementSc::Start()
extern void PikupMovementSc_Start_m596629E0900D7DBCF57E3B562B43DB0EF9321421 (void);
// 0x00000075 System.Void PikupMovementSc::FixedUpdate()
extern void PikupMovementSc_FixedUpdate_mA41FBB33A485FA438502486F50455F6B458EA9B0 (void);
// 0x00000076 System.Void PikupMovementSc::.ctor()
extern void PikupMovementSc__ctor_m839A68EEE3EE15F5CA484B1A2E0B61B8F3C7D7D5 (void);
// 0x00000077 System.Void PlayerController::Start()
extern void PlayerController_Start_m9531F30EC892BDD1758A2EEC724E86EFBDA150A3 (void);
// 0x00000078 System.Void PlayerController::CheckInputType()
extern void PlayerController_CheckInputType_m90D940EBE9D4D83B656351FC9537FBDFFCC08F83 (void);
// 0x00000079 System.Void PlayerController::OnEsc(UnityEngine.InputSystem.InputValue)
extern void PlayerController_OnEsc_m608F417068715935893741129C2F736D4501A0C0 (void);
// 0x0000007A System.Void PlayerController::quit()
extern void PlayerController_quit_m96D402569E2C6C272B440ECB6671C548B8693946 (void);
// 0x0000007B System.Void PlayerController::onofsound()
extern void PlayerController_onofsound_m8AC9900B9A577623F7485982F5CA6398E7FC0B7F (void);
// 0x0000007C System.Boolean PlayerController::IsPointerOverUIObject()
extern void PlayerController_IsPointerOverUIObject_mD3789DF8163DC67DE211849CE080201B71E372D9 (void);
// 0x0000007D System.Void PlayerController::OnMove(UnityEngine.InputSystem.InputValue)
extern void PlayerController_OnMove_mE981029D7E705952AA17D958FEB08C53D94A06C8 (void);
// 0x0000007E System.Void PlayerController::OnJump(UnityEngine.InputSystem.InputValue)
extern void PlayerController_OnJump_m706F49543A3371BDCECAD6408E3EF58886523DB1 (void);
// 0x0000007F System.Void PlayerController::OnUse(UnityEngine.InputSystem.InputValue)
extern void PlayerController_OnUse_mA9B6A47C9CD01A80D199F4AD5403F94BE88F7EE5 (void);
// 0x00000080 System.Void PlayerController::OnFire(UnityEngine.InputSystem.InputValue)
extern void PlayerController_OnFire_m0569A2B1F92FB45467BE777A3C92D78E11A188A7 (void);
// 0x00000081 System.Void PlayerController::OnPunch(UnityEngine.InputSystem.InputValue)
extern void PlayerController_OnPunch_m7712B091838DE934F0D9A0C4AC97F0F5C1BDF6EF (void);
// 0x00000082 System.Void PlayerController::Ground(System.String,System.Boolean)
extern void PlayerController_Ground_mD1A0E6AF9E43C756F6E908BD0C2627729635350C (void);
// 0x00000083 System.Void PlayerController::Gravity()
extern void PlayerController_Gravity_m23EB48D96BB5B1F6E0E43948A513371663C44C5E (void);
// 0x00000084 System.Boolean PlayerController::CheckMiddleRay()
extern void PlayerController_CheckMiddleRay_mEDC7579D270CE05585D9C101A32CD1886DB087B7 (void);
// 0x00000085 System.Void PlayerController::Update()
extern void PlayerController_Update_mB31159CAD7DD2329859472554BC9154A83D8E794 (void);
// 0x00000086 System.Void PlayerController::FixedUpdate()
extern void PlayerController_FixedUpdate_m54EE3ADAA7597303B1F69849B233D1A68D880B14 (void);
// 0x00000087 System.Collections.IEnumerator PlayerController::attack(System.Single)
extern void PlayerController_attack_m6625DF7921FD0F5078848321A05144E9EF01269B (void);
// 0x00000088 System.Void PlayerController::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void PlayerController_OnTriggerEnter2D_m1B1E3F94F29560C6CD4687C6556D74A092CC672E (void);
// 0x00000089 System.Void PlayerController::OnTriggerExit2D(UnityEngine.Collider2D)
extern void PlayerController_OnTriggerExit2D_mA3ABB40D86D202DA68BDB29AC4F7BA24ED1526B1 (void);
// 0x0000008A System.Void PlayerController::Interaction()
extern void PlayerController_Interaction_m01482BE30A868EAA42377E9F34282273EA7E3421 (void);
// 0x0000008B System.Void PlayerController::Dialog(DialogClass)
extern void PlayerController_Dialog_m4D8EF0B65C7812C95EB84FBCA8F57B11554FA09E (void);
// 0x0000008C System.Collections.IEnumerator PlayerController::Extext(System.String)
extern void PlayerController_Extext_m83F88BC3FA99C6EF14CA2CC0D962D9F5ECA3225C (void);
// 0x0000008D System.Void PlayerController::DialogEnd()
extern void PlayerController_DialogEnd_mFE5207AD04BA912E6F42DD7A26E381FBCF61B25F (void);
// 0x0000008E System.Void PlayerController::.ctor()
extern void PlayerController__ctor_mF30385729DAFDFCB895C4939F6051DCE6C0327FB (void);
// 0x0000008F System.Void RatSc::Start()
extern void RatSc_Start_mF7AD4FB51AFEAD41E6BAD2EF57460AB3347013DA (void);
// 0x00000090 System.Void RatSc::OnTriggerStay2D(UnityEngine.Collider2D)
extern void RatSc_OnTriggerStay2D_m1C5D300279E2CD5B46F4654848D2082ED6D2BF74 (void);
// 0x00000091 System.Void RatSc::OnTriggerExit2D(UnityEngine.Collider2D)
extern void RatSc_OnTriggerExit2D_mDA1A242B0EE2AF731D3E3427C1DC7A3DFC759388 (void);
// 0x00000092 System.Void RatSc::OnColliderEnter(UnityEngine.Collider)
extern void RatSc_OnColliderEnter_mDD6E4EF3BAD1C10CD9D8C688689AFD74A7BF3FE6 (void);
// 0x00000093 System.Void RatSc::Update()
extern void RatSc_Update_m17F8ED27F1D232BD1C3CCF717288B734695B3338 (void);
// 0x00000094 System.Void RatSc::.ctor()
extern void RatSc__ctor_mB53B2F32D8A64DF39AA714067F9BECC4EE9083BA (void);
// 0x00000095 System.Void RocksRestoreSc::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void RocksRestoreSc_OnTriggerEnter2D_m5289F48F839A4A3D4F72463373F1653D63E338EA (void);
// 0x00000096 System.Void RocksRestoreSc::.ctor()
extern void RocksRestoreSc__ctor_mD14DD37FE202CDA7B9210F7D73CADA56F60E26EC (void);
// 0x00000097 System.Void SawItselfSc::Start()
extern void SawItselfSc_Start_m022C0C5CDBEDFAEF4FFED65953A95083709B2A3F (void);
// 0x00000098 System.Void SawItselfSc::Update()
extern void SawItselfSc_Update_m479B342172A64BC518D411B48B1A6060D31EE795 (void);
// 0x00000099 System.Void SawItselfSc::.ctor()
extern void SawItselfSc__ctor_mD83FA52BB02E03FDAC93C440DEB50A503DBBE22D (void);
// 0x0000009A System.Void SawSc::Start()
extern void SawSc_Start_m8BFC7FD06C6C9676F72740D70FBFE724894FEE0B (void);
// 0x0000009B System.Void SawSc::OnTriggerStay2D(UnityEngine.Collider2D)
extern void SawSc_OnTriggerStay2D_m5F1A11B00C56F13252A1BFD08FCCD97B3D62B3F6 (void);
// 0x0000009C System.Void SawSc::.ctor()
extern void SawSc__ctor_m0F7E0673E8FEB58080BBE9431887BB4A522E4DF5 (void);
// 0x0000009D System.Void ShockSc::Start()
extern void ShockSc_Start_m82C2335110A1551E2B0D1CC3A6732DDB256F526D (void);
// 0x0000009E System.Void ShockSc::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void ShockSc_OnTriggerEnter2D_mE7BE06C3D64552F0393389D4D04D3EDA744A87F1 (void);
// 0x0000009F System.Void ShockSc::Update()
extern void ShockSc_Update_m5C6E24D16353FCBAF89DB6A1DD19E80C04336D83 (void);
// 0x000000A0 System.Void ShockSc::.ctor()
extern void ShockSc__ctor_m0E29D19FE5A2A468DCDF67D0A277C51968ACD5C6 (void);
// 0x000000A1 System.Void SpawnManagerSc::Start()
extern void SpawnManagerSc_Start_mFFF06B0832C3703C02BE07C06A36EEAD2D5721EC (void);
// 0x000000A2 System.Void SpawnManagerSc::Update()
extern void SpawnManagerSc_Update_m6C6B5FECAB513F97AE33A2B3AAB630870924D4D3 (void);
// 0x000000A3 System.Void SpawnManagerSc::.ctor()
extern void SpawnManagerSc__ctor_m44F344112772B48E92380C5D6460196C212F35C4 (void);
// 0x000000A4 System.Void SpeedTimerSc::Start()
extern void SpeedTimerSc_Start_m02A03C61A56744F278BD931D43AD7769A9EC3670 (void);
// 0x000000A5 System.Void SpeedTimerSc::Update()
extern void SpeedTimerSc_Update_mCDECAEA284AA3CBC1AD4A9C49207942060FD97EF (void);
// 0x000000A6 System.Void SpeedTimerSc::.ctor()
extern void SpeedTimerSc__ctor_m94552475EA860025AB917513D9CDEF576D2F209E (void);
// 0x000000A7 System.Void StartSc::Start()
extern void StartSc_Start_m3352D3C17CE7A4D5AC85DEBFEF9F052C5D9EF6B2 (void);
// 0x000000A8 System.Void StartSc::OnButton()
extern void StartSc_OnButton_m3611C33E77E73045DE59BAC4D3AE4BB33419FA5B (void);
// 0x000000A9 System.Void StartSc::OnExit()
extern void StartSc_OnExit_m90FC5AB3BCADDECD5C326BA1E95EC4058DAE4EC8 (void);
// 0x000000AA System.Void StartSc::OnTest()
extern void StartSc_OnTest_m8A338A81CAF7B11B3F58783F4176231BE17867BF (void);
// 0x000000AB System.Void StartSc::.ctor()
extern void StartSc__ctor_m78C766C67CAA567B28AD155F7823BBB9BE6A68A9 (void);
// 0x000000AC System.Void lighttowSC::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void lighttowSC_OnTriggerEnter2D_mCAE40405DE0CB7305078738238F403DB84562EAC (void);
// 0x000000AD System.Void lighttowSC::.ctor()
extern void lighttowSC__ctor_mE5A8CD2700CF3DF63B2814B884A3860F289DCE8C (void);
// 0x000000AE System.Void PlayerInput/PlayerActions::.ctor(PlayerInput)
extern void PlayerActions__ctor_mDA15093D50C03D89BFB62810506BD87E1C1CDA08_AdjustorThunk (void);
// 0x000000AF UnityEngine.InputSystem.InputAction PlayerInput/PlayerActions::get_Move()
extern void PlayerActions_get_Move_mF91BED7875BF9D3BE614EDFBCD1C14FB2431F10E_AdjustorThunk (void);
// 0x000000B0 UnityEngine.InputSystem.InputAction PlayerInput/PlayerActions::get_Look()
extern void PlayerActions_get_Look_mAB989AE5BBBF82253A915F4C81F379927447C848_AdjustorThunk (void);
// 0x000000B1 UnityEngine.InputSystem.InputAction PlayerInput/PlayerActions::get_MousePos()
extern void PlayerActions_get_MousePos_m916616B5CD02F7A1337E8D0D7F8003C6C6860FF2_AdjustorThunk (void);
// 0x000000B2 UnityEngine.InputSystem.InputAction PlayerInput/PlayerActions::get_Use()
extern void PlayerActions_get_Use_mCC7A2B943E49D464632DEB5A6311D31F59A5C7F3_AdjustorThunk (void);
// 0x000000B3 UnityEngine.InputSystem.InputAction PlayerInput/PlayerActions::get_Run()
extern void PlayerActions_get_Run_mFA537D51FAF3CFC32BA0E84957BF54F2C5848634_AdjustorThunk (void);
// 0x000000B4 UnityEngine.InputSystem.InputAction PlayerInput/PlayerActions::get_Jump()
extern void PlayerActions_get_Jump_mFFA322829A0819F940D6026CBAC4B68DB19A860E_AdjustorThunk (void);
// 0x000000B5 UnityEngine.InputSystem.InputAction PlayerInput/PlayerActions::get_Fire()
extern void PlayerActions_get_Fire_mF4B41EE01632AB5C7A137FE1A19AFB3817BF9CCD_AdjustorThunk (void);
// 0x000000B6 UnityEngine.InputSystem.InputAction PlayerInput/PlayerActions::get_Esc()
extern void PlayerActions_get_Esc_m8D541616552D3A53E3220AB61CB173525098EC4A_AdjustorThunk (void);
// 0x000000B7 UnityEngine.InputSystem.InputAction PlayerInput/PlayerActions::get_Punch()
extern void PlayerActions_get_Punch_m0C29529054EC7287CED799904F76F13942D35C85_AdjustorThunk (void);
// 0x000000B8 UnityEngine.InputSystem.InputActionMap PlayerInput/PlayerActions::Get()
extern void PlayerActions_Get_m6E35B23C5D816F82CC97D591B21C8397CB678F75_AdjustorThunk (void);
// 0x000000B9 System.Void PlayerInput/PlayerActions::Enable()
extern void PlayerActions_Enable_m51B290BB7FD000599545C598B84DD938DCB981F3_AdjustorThunk (void);
// 0x000000BA System.Void PlayerInput/PlayerActions::Disable()
extern void PlayerActions_Disable_m66DC5AAD57A6EDCC7439D543B4835A237FF736F4_AdjustorThunk (void);
// 0x000000BB System.Boolean PlayerInput/PlayerActions::get_enabled()
extern void PlayerActions_get_enabled_m884E842C6FFED45B5121E24B6212D0EB7F5D5E27_AdjustorThunk (void);
// 0x000000BC UnityEngine.InputSystem.InputActionMap PlayerInput/PlayerActions::op_Implicit(PlayerInput/PlayerActions)
extern void PlayerActions_op_Implicit_m05B3D81F858E7CB18C74134F290CAA78F7699C03 (void);
// 0x000000BD System.Void PlayerInput/PlayerActions::SetCallbacks(PlayerInput/IPlayerActions)
extern void PlayerActions_SetCallbacks_m4E6B64AF471E45A3EC7EEFA3FEE5919854E7CFCC_AdjustorThunk (void);
// 0x000000BE System.Void PlayerInput/UIActions::.ctor(PlayerInput)
extern void UIActions__ctor_m2109C97F9526A1C02DFCE5459D233C6582F7F531_AdjustorThunk (void);
// 0x000000BF UnityEngine.InputSystem.InputAction PlayerInput/UIActions::get_Navigate()
extern void UIActions_get_Navigate_m835C0B57A206CE85E31A0ECC391C5C9BDE4A37F6_AdjustorThunk (void);
// 0x000000C0 UnityEngine.InputSystem.InputAction PlayerInput/UIActions::get_Submit()
extern void UIActions_get_Submit_m08DDE67FA35F5596F83EDC9294D0D0BB960E8105_AdjustorThunk (void);
// 0x000000C1 UnityEngine.InputSystem.InputAction PlayerInput/UIActions::get_Cancel()
extern void UIActions_get_Cancel_m1F57F685312D55E6C8EF1AB89080CC4D55230BE3_AdjustorThunk (void);
// 0x000000C2 UnityEngine.InputSystem.InputAction PlayerInput/UIActions::get_Point()
extern void UIActions_get_Point_m9EE37892D5E17EBEB0C35D8352E7EAC130E67F34_AdjustorThunk (void);
// 0x000000C3 UnityEngine.InputSystem.InputAction PlayerInput/UIActions::get_Click()
extern void UIActions_get_Click_m0789853719BAA9F4447CAEBF9022E1A1DCF45521_AdjustorThunk (void);
// 0x000000C4 UnityEngine.InputSystem.InputAction PlayerInput/UIActions::get_ScrollWheel()
extern void UIActions_get_ScrollWheel_m91AFD151331FD99B2E361C7844472CC197375B49_AdjustorThunk (void);
// 0x000000C5 UnityEngine.InputSystem.InputAction PlayerInput/UIActions::get_MiddleClick()
extern void UIActions_get_MiddleClick_m1D0ACDA2A1412A63BDDBC122569F826A0841B6DE_AdjustorThunk (void);
// 0x000000C6 UnityEngine.InputSystem.InputAction PlayerInput/UIActions::get_RightClick()
extern void UIActions_get_RightClick_m7F2C8DED04B5FC90BAE78CB47FDECE6A3AC1461C_AdjustorThunk (void);
// 0x000000C7 UnityEngine.InputSystem.InputAction PlayerInput/UIActions::get_TrackedDevicePosition()
extern void UIActions_get_TrackedDevicePosition_m75D22A8ABDF111B3E85096BC6C230B166CA9C459_AdjustorThunk (void);
// 0x000000C8 UnityEngine.InputSystem.InputAction PlayerInput/UIActions::get_TrackedDeviceOrientation()
extern void UIActions_get_TrackedDeviceOrientation_m7CD1146BE63EDA5B46165DC6EDBECBD5E9A12B7E_AdjustorThunk (void);
// 0x000000C9 UnityEngine.InputSystem.InputActionMap PlayerInput/UIActions::Get()
extern void UIActions_Get_m5D731085792EC48E9E24F644DF0669B87B56C439_AdjustorThunk (void);
// 0x000000CA System.Void PlayerInput/UIActions::Enable()
extern void UIActions_Enable_m8FC1F13397654932695D048C6E579F63759BAFBF_AdjustorThunk (void);
// 0x000000CB System.Void PlayerInput/UIActions::Disable()
extern void UIActions_Disable_m3770A054DB2841B29C0DCADEF029A846C04A9EA6_AdjustorThunk (void);
// 0x000000CC System.Boolean PlayerInput/UIActions::get_enabled()
extern void UIActions_get_enabled_m378F4D557A015EDA519F9086F05288B6A0A8315C_AdjustorThunk (void);
// 0x000000CD UnityEngine.InputSystem.InputActionMap PlayerInput/UIActions::op_Implicit(PlayerInput/UIActions)
extern void UIActions_op_Implicit_m82CE45612E1F9E346B4A55451B57EAB223E032F1 (void);
// 0x000000CE System.Void PlayerInput/UIActions::SetCallbacks(PlayerInput/IUIActions)
extern void UIActions_SetCallbacks_mE23EB0929C87574749B8E268B227D5A4095E69CB_AdjustorThunk (void);
// 0x000000CF System.Void PlayerInput/IPlayerActions::OnMove(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000D0 System.Void PlayerInput/IPlayerActions::OnLook(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000D1 System.Void PlayerInput/IPlayerActions::OnMousePos(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000D2 System.Void PlayerInput/IPlayerActions::OnUse(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000D3 System.Void PlayerInput/IPlayerActions::OnRun(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000D4 System.Void PlayerInput/IPlayerActions::OnJump(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000D5 System.Void PlayerInput/IPlayerActions::OnFire(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000D6 System.Void PlayerInput/IPlayerActions::OnEsc(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000D7 System.Void PlayerInput/IPlayerActions::OnPunch(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000D8 System.Void PlayerInput/IUIActions::OnNavigate(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000D9 System.Void PlayerInput/IUIActions::OnSubmit(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000DA System.Void PlayerInput/IUIActions::OnCancel(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000DB System.Void PlayerInput/IUIActions::OnPoint(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000DC System.Void PlayerInput/IUIActions::OnClick(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000DD System.Void PlayerInput/IUIActions::OnScrollWheel(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000DE System.Void PlayerInput/IUIActions::OnMiddleClick(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000DF System.Void PlayerInput/IUIActions::OnRightClick(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000E0 System.Void PlayerInput/IUIActions::OnTrackedDevicePosition(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000E1 System.Void PlayerInput/IUIActions::OnTrackedDeviceOrientation(UnityEngine.InputSystem.InputAction/CallbackContext)
// 0x000000E2 System.Void ArrowSc/<BecomeVisible>d__6::.ctor(System.Int32)
extern void U3CBecomeVisibleU3Ed__6__ctor_m008DD3D75A27E0212F6ACED5BF297FD95A688048 (void);
// 0x000000E3 System.Void ArrowSc/<BecomeVisible>d__6::System.IDisposable.Dispose()
extern void U3CBecomeVisibleU3Ed__6_System_IDisposable_Dispose_m45C388D925DA2789E29C98E555C015FA8D61AECF (void);
// 0x000000E4 System.Boolean ArrowSc/<BecomeVisible>d__6::MoveNext()
extern void U3CBecomeVisibleU3Ed__6_MoveNext_m020E3F6850FEDC4758952F571EA16693C547FDDD (void);
// 0x000000E5 System.Object ArrowSc/<BecomeVisible>d__6::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CBecomeVisibleU3Ed__6_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB481DF40F18FF31835D53E21B1404CA63AB22B57 (void);
// 0x000000E6 System.Void ArrowSc/<BecomeVisible>d__6::System.Collections.IEnumerator.Reset()
extern void U3CBecomeVisibleU3Ed__6_System_Collections_IEnumerator_Reset_m07DA1A80686F43799E2768C6B24D7645D9645252 (void);
// 0x000000E7 System.Object ArrowSc/<BecomeVisible>d__6::System.Collections.IEnumerator.get_Current()
extern void U3CBecomeVisibleU3Ed__6_System_Collections_IEnumerator_get_Current_m9E9DAA3578E9207E343E50075BF4A2C10DF2D865 (void);
// 0x000000E8 System.Void BoxScr/<ups>d__11::.ctor(System.Int32)
extern void U3CupsU3Ed__11__ctor_m68A129467AF39B673771EC217C6F1DF2D1CC1A94 (void);
// 0x000000E9 System.Void BoxScr/<ups>d__11::System.IDisposable.Dispose()
extern void U3CupsU3Ed__11_System_IDisposable_Dispose_m9A1BC42932B8C1AD8D26F3DAF07266AE2567CC73 (void);
// 0x000000EA System.Boolean BoxScr/<ups>d__11::MoveNext()
extern void U3CupsU3Ed__11_MoveNext_mEE3F561A48712F0622A8541EBDF7C8EC575FE3A1 (void);
// 0x000000EB System.Object BoxScr/<ups>d__11::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CupsU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m4C5A897962CFE198AA5CAA81FB65281008D153D0 (void);
// 0x000000EC System.Void BoxScr/<ups>d__11::System.Collections.IEnumerator.Reset()
extern void U3CupsU3Ed__11_System_Collections_IEnumerator_Reset_m0A7CF0A0615FED3FF89919FF4723C2775433F4AD (void);
// 0x000000ED System.Object BoxScr/<ups>d__11::System.Collections.IEnumerator.get_Current()
extern void U3CupsU3Ed__11_System_Collections_IEnumerator_get_Current_m2BA074127D9A622DF1B193884113435B31616A7C (void);
// 0x000000EE System.Void BoxScr/<waiter>d__12::.ctor(System.Int32)
extern void U3CwaiterU3Ed__12__ctor_m53429CE291B1B331A6EF2386EDF7EC885F06EFC0 (void);
// 0x000000EF System.Void BoxScr/<waiter>d__12::System.IDisposable.Dispose()
extern void U3CwaiterU3Ed__12_System_IDisposable_Dispose_m285159F0C8A10DC82F6ACF681EFB194253580E17 (void);
// 0x000000F0 System.Boolean BoxScr/<waiter>d__12::MoveNext()
extern void U3CwaiterU3Ed__12_MoveNext_m545B749080E1DE0FAE584ABD3F0E19511E014FB6 (void);
// 0x000000F1 System.Object BoxScr/<waiter>d__12::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CwaiterU3Ed__12_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m55A62BF1DFCE3D2DF8E795747F6C13C5AF772AE4 (void);
// 0x000000F2 System.Void BoxScr/<waiter>d__12::System.Collections.IEnumerator.Reset()
extern void U3CwaiterU3Ed__12_System_Collections_IEnumerator_Reset_m15004F57EC6373BA9FBB7470C5BBA78B7EA713DA (void);
// 0x000000F3 System.Object BoxScr/<waiter>d__12::System.Collections.IEnumerator.get_Current()
extern void U3CwaiterU3Ed__12_System_Collections_IEnumerator_get_Current_m74B86D9C0F29B66DE2FAD5C4C7FDB5EBBCE4B634 (void);
// 0x000000F4 System.Void Manager/<Waitsc>d__25::.ctor(System.Int32)
extern void U3CWaitscU3Ed__25__ctor_mB538B843BCB22D63AA4791C37025A8314A29610F (void);
// 0x000000F5 System.Void Manager/<Waitsc>d__25::System.IDisposable.Dispose()
extern void U3CWaitscU3Ed__25_System_IDisposable_Dispose_m15A1DD2B870C96F5F88A851164E5BD785DAAC914 (void);
// 0x000000F6 System.Boolean Manager/<Waitsc>d__25::MoveNext()
extern void U3CWaitscU3Ed__25_MoveNext_m5BDB922C8ED0AE91F48218A2E6F5CA66FB3B4E01 (void);
// 0x000000F7 System.Object Manager/<Waitsc>d__25::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CWaitscU3Ed__25_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mEA60A29FA1D752861984824B2F0FE6DCD589C18C (void);
// 0x000000F8 System.Void Manager/<Waitsc>d__25::System.Collections.IEnumerator.Reset()
extern void U3CWaitscU3Ed__25_System_Collections_IEnumerator_Reset_m24E1DE875935E8EA6EE2E63E6B671F98441F2CCA (void);
// 0x000000F9 System.Object Manager/<Waitsc>d__25::System.Collections.IEnumerator.get_Current()
extern void U3CWaitscU3Ed__25_System_Collections_IEnumerator_get_Current_m6EE00C73C3FA60D3A0EEB8FD387692B06CEB5364 (void);
// 0x000000FA System.Void MinibombSc/<BecomeVisible>d__13::.ctor(System.Int32)
extern void U3CBecomeVisibleU3Ed__13__ctor_m1CDE93E44F3EB501928163C38E2C8AB172B50316 (void);
// 0x000000FB System.Void MinibombSc/<BecomeVisible>d__13::System.IDisposable.Dispose()
extern void U3CBecomeVisibleU3Ed__13_System_IDisposable_Dispose_mE5B9501E02E34B017A45B5FE08E09C06C345FE51 (void);
// 0x000000FC System.Boolean MinibombSc/<BecomeVisible>d__13::MoveNext()
extern void U3CBecomeVisibleU3Ed__13_MoveNext_m8FECC69F36D3F53EF4574CCD0252F272E6E47A6A (void);
// 0x000000FD System.Object MinibombSc/<BecomeVisible>d__13::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CBecomeVisibleU3Ed__13_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m46C07AF63C36012AFB868E2FE303528F3CB8AC88 (void);
// 0x000000FE System.Void MinibombSc/<BecomeVisible>d__13::System.Collections.IEnumerator.Reset()
extern void U3CBecomeVisibleU3Ed__13_System_Collections_IEnumerator_Reset_mC567CC726B93DAD584FEE93248E0591A67FA2D27 (void);
// 0x000000FF System.Object MinibombSc/<BecomeVisible>d__13::System.Collections.IEnumerator.get_Current()
extern void U3CBecomeVisibleU3Ed__13_System_Collections_IEnumerator_get_Current_m6387C9619ED42AC6F03A1D0D4DA44A209F0BB3B9 (void);
// 0x00000100 System.Void PlayerController/<attack>d__82::.ctor(System.Int32)
extern void U3CattackU3Ed__82__ctor_mA3B4E8B939BD2EB29E4C5AE0BCA071CBEDF60802 (void);
// 0x00000101 System.Void PlayerController/<attack>d__82::System.IDisposable.Dispose()
extern void U3CattackU3Ed__82_System_IDisposable_Dispose_m410583EECEAF48C1753D1B15EE0FCEEAA5153F29 (void);
// 0x00000102 System.Boolean PlayerController/<attack>d__82::MoveNext()
extern void U3CattackU3Ed__82_MoveNext_mAE353A548F870C35DFA2F78C6A0EB2A432730454 (void);
// 0x00000103 System.Object PlayerController/<attack>d__82::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CattackU3Ed__82_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m2BFFE6B6110DC18C3A89B77EFAD781738946DF11 (void);
// 0x00000104 System.Void PlayerController/<attack>d__82::System.Collections.IEnumerator.Reset()
extern void U3CattackU3Ed__82_System_Collections_IEnumerator_Reset_mBDBFD7C488BE11470BD227FFF202B44B02034988 (void);
// 0x00000105 System.Object PlayerController/<attack>d__82::System.Collections.IEnumerator.get_Current()
extern void U3CattackU3Ed__82_System_Collections_IEnumerator_get_Current_mAF50D991A3BF2ED2A4536183CDFAA971D53A9861 (void);
// 0x00000106 System.Void PlayerController/<Extext>d__87::.ctor(System.Int32)
extern void U3CExtextU3Ed__87__ctor_m1F38698DE40FF2C6653D23EB07E68C922CE529E3 (void);
// 0x00000107 System.Void PlayerController/<Extext>d__87::System.IDisposable.Dispose()
extern void U3CExtextU3Ed__87_System_IDisposable_Dispose_mD0BF3138642129FF3F6A475E5DBE68D9A82C1861 (void);
// 0x00000108 System.Boolean PlayerController/<Extext>d__87::MoveNext()
extern void U3CExtextU3Ed__87_MoveNext_m42B703FBBDE4BCC9FF4E801DD167A3B1B1627135 (void);
// 0x00000109 System.Object PlayerController/<Extext>d__87::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CExtextU3Ed__87_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB6B321FB5A266B7E336EF2CF9F1A35778E9C9167 (void);
// 0x0000010A System.Void PlayerController/<Extext>d__87::System.Collections.IEnumerator.Reset()
extern void U3CExtextU3Ed__87_System_Collections_IEnumerator_Reset_mA34F804C0B677883B556B17DA22A6DB99B6F4A70 (void);
// 0x0000010B System.Object PlayerController/<Extext>d__87::System.Collections.IEnumerator.get_Current()
extern void U3CExtextU3Ed__87_System_Collections_IEnumerator_get_Current_mAE41389F2D9D417D40001DBF01B96A13C062102A (void);
static Il2CppMethodPointer s_methodPointers[267] = 
{
	PlayerInput_get_asset_mC78B60CC7CCB2D77F076FE53BEB9B265241123DE,
	PlayerInput__ctor_m84EAB041CD5C8D268A3C5741EC3A70B5F1E47B20,
	PlayerInput_Dispose_m560794A2B84F1C6308F607BF82B1E4A1EDF38E21,
	PlayerInput_get_bindingMask_m83EC78F082519231793D2384AE79AD073326D42D,
	PlayerInput_set_bindingMask_m9921F2BADFADAC2E62F410BCB79DD0D2D512D629,
	PlayerInput_get_devices_mAA2B0EE7E5CD6C60BB63F582828D00B6E80DA125,
	PlayerInput_set_devices_mC8B1B8AE41EEB805BD39504612A6540ADF0A0F22,
	PlayerInput_get_controlSchemes_m8E11232C93DD0644BBD67AEB9FEA9E503AE7F4FB,
	PlayerInput_Contains_m0CDC3D9D39D268FC1F77854CA7C164F996E78B69,
	PlayerInput_GetEnumerator_m4CC727A8CC35520DB0BCC60C684C305C8D4CD45E,
	PlayerInput_System_Collections_IEnumerable_GetEnumerator_mC4FB5A6DEF54DCC127F7710AE1CE80BFAE93E46A,
	PlayerInput_Enable_m51F97ADF330547539E0B99A3FB8139ADD5266D93,
	PlayerInput_Disable_m7E5A729CAA47FB37AF38169AED455C8350E6F68C,
	PlayerInput_get_Player_m18604B7BFF2979B66AE83701382A91B443478AEE,
	PlayerInput_get_UI_m01844472D946D17968818A9DEC67B59275FEE61F,
	PlayerInput_get_KeyboardMouseScheme_m6F89017A0ED98B6A2C94A6B75E4BB7933DDC8013,
	PlayerInput_get_GamepadScheme_m10343193095A7E03C5F80FC4F78721DE8AE3CA0F,
	PlayerInput_get_TouchScheme_m7087ABDB63E3ED31FC62E0191B757CD81741FC4D,
	PlayerInput_get_JoystickScheme_m3CC962C473A0E328628114C116A48EC33CAE4243,
	PlayerInput_get_XRScheme_m1F640E895BCEA2DB8A2ECFFAF8338F24BB257401,
	ArrowSc_Start_m9E9D983300A7A1F4AB2A558B10B6FC2C66011A68,
	ArrowSc_BecomeVisible_m607B52899DBF72D3CDFF374CDC77F54F19580BE0,
	ArrowSc_OnTriggerStay2D_m05BCFEB0244DC0C2DFC39493003A86E5E6344D76,
	ArrowSc__ctor_mA422E3D011315EEAEAA5CB27F3A803633DEEC08C,
	BOSS_0_Start_m8BED97B629B3ADBBBDB92ECE8CF182B4E67086FA,
	BOSS_0_Update_m3D7063D2687E5EE5F18FCA9C613CC83032767E13,
	BOSS_0__ctor_m5253215D4889421E3D9F380C99B53C63A1702ABE,
	BoulderSc_OnTRiggerEnter_m34C131B4649107E34883E33B84433B09FFE77F3D,
	BoulderSc_Update_m55931E3F3B21E700F52632D53D6CF2D5454D6C79,
	BoulderSc__ctor_m050573D3CC89045A62E2252034CBEF6026661D4B,
	BoxScr_boxUp_mC467181AFDA4F62BA95C03E18373153A961693C4,
	BoxScr_boxDown_m521788419D0508321B2A25B75D5660FBE451EDCB,
	BoxScr_Update_m2EF84F1794DF4938DD4DD4F58891ACD8563B1D5C,
	BoxScr_ups_m29215AB1357DE8E47DEB8E2DC788DB33E32F6C42,
	BoxScr_waiter_m09F6F43F18DA8FD9CC30C6CEBDC13A8A95804335,
	BoxScr_OnCollisionEnter_m6A7B1B6FCE7CF9D2598C11662D492760CBC7FA20,
	BoxScr__ctor_mF7B446E20E8D26792537B1CBC665E23C004CC71D,
	ButtonSc_OnTriggerEnter2D_m9F0BAEDB17DF9C460F25AAD73AE7708870168D2B,
	ButtonSc_OnCollisionEnter2D_m4BD57739A6BA92246E0627B745F3C3020265E089,
	ButtonSc_Start_mC8EC1EFE9360D8D308D8AAE954B8C9F5E72D49D4,
	ButtonSc__ctor_m143C1A3FD712CAB95732AE188190130CA900C59E,
	CameraSc_Start_m516A79399CE9523A9FD6CCDAF6936D7EA53A6400,
	CameraSc_FixedUpdate_m79E2BC8B177F02AF2AA48D99FD918DF3191C1FC6,
	CameraSc__ctor_m5E12DD1E2F518495510434311F2816C6D00D920A,
	CasetteSc_Start_m27337322FC8A555BA59BC1AA87E775CA6B38F3CB,
	CasetteSc_OnTriggerEnter2D_m6A99490E7087C0D598365C8F4FFB3F325768DFE8,
	CasetteSc__ctor_mD5BC88FD6DC0BD9E44B2A282068E2ACD05775086,
	CloudSc_Start_mB7256E0E06134219FC0FD9B80BB2F65A6CAD88D3,
	CloudSc_Update_m22F1B34C010067CEA72A0B5A15BC486AADC46D2A,
	CloudSc__ctor_m3A5612EECE8B11C73571C720848176A2A11A0FF5,
	DialogClass__ctor_m0227510E78FF17BEBED70CFDE581B686D57EEF29,
	DoorSc_OpenDoor_m358D28BB4086607F5656F56FE5F87C5F7F4C4226,
	DoorSc__ctor_mC9A875CE2C54A6ED6733DF407277C94DBA444D71,
	ElectrSpawnerSc_Start_m0F3F93A0933B092C9D52B4FF9DF224D81B016A02,
	ElectrSpawnerSc_Update_mA847DC1E0AF6A14CD9064F02B4C0194D6994C772,
	ElectrSpawnerSc__ctor_mDE9E23C61659DFC8CA2EF519EAC23A084FAF537C,
	EndSc_Start_mD9D051BF13133222865E9D50D13771C4402334B5,
	EndSc_OnTriggerEnter_m2327050344D4C2463C227A0C16F0793983254221,
	EndSc_tomenu_m26362070E402D0C350130AC8D3CBB13844388565,
	EndSc__ctor_m0A312E4B0C6982AD6A6CD50C23405F5F83C0D41F,
	EnemyPathfindingSc_Start_m4A6905D346FC00A2202A59D6FB60546B589C4E01,
	EnemyPathfindingSc_OnTriggerEnter2D_mEE70320011D3A7ED407BEE62D605D25BFE18B608,
	EnemyPathfindingSc_Update_mF5AC17D9236078CFF8854215DA7DBCA95489CAC3,
	EnemyPathfindingSc__ctor_m560259CC98ED686FF29616BFB1B47E4372162A33,
	EnemySc_Start_m1404F2D572B6E646585EEDC27B10467BA0CD5125,
	EnemySc_OnTriggerStay2D_m6D87DD9C75D2E19DA74DA406A8DC7DE308C7805B,
	EnemySc_OnTriggerExit2D_m03359A7924DF96E71A9BAE0D673800FCC1669D1F,
	EnemySc_Update_mBC73144AB4DF98F2592E25798D0D1759EB57820B,
	EnemySc__ctor_mB3A84D228C2250D330F3E6C747C4029DC1E587AC,
	FPS_counterSC_Update_mD6102DD1D12AAFEDB1E0B2A854B2310BF269FFB3,
	FPS_counterSC__ctor_m72ACE900CE5395F07F6FF53E4ED12C43D0375B5E,
	HPSc_OnTriggerEnter2D_m47F605C9C4BF7F92D9CA12EE7E9E6F3709CC81EB,
	HPSc__ctor_m67DEA251061B7A9FAEC8F072B61CEE3297A1CF4D,
	JustDamageSc_OnTriggerEnter2D_m7AEC56362B362047F38031D6D3850AE1C297DF6E,
	JustDamageSc_Explosion2D_m8BF924B101B76F3D618852AC325833D690A75951,
	JustDamageSc__ctor_mC782102A5CB82C85DE06C51DE84DC54277E8D488,
	Manager_get_instance_m16C2387DFC1CF5D61C4A5B613DFEC70E6F4DB3EC,
	Manager_Awake_mC363EF8F87DCFA0409A492A299F31059706F425B,
	Manager_SetVolume_m406BC1666BFE409993E657AB6933744B8D09D565,
	Manager_restart_m72E4C2908B1A7984F33861922B5B71EB24D97865,
	Manager_end_m1A031C140591F4BA544DB755847BE0961F626BF1,
	Manager_Waitsc_m3816352955CC93F6E795A7C74117D57203078E87,
	Manager_leave_m9096705338FAB276F16CC16BBEDAA665D2B96B38,
	Manager_TryShoot_m83F64870E09B68CFE752A873C15A31A3F3933239,
	Manager_RestoreRocks_m80B3DE39C026365CC525C5D452B66DCDC2524BE7,
	Manager_getDMG_m2292BB3F9E122669939CDA576F1370D681D6F8D3,
	Manager_Kill_mD63E2152C826A21F4640AAF0C9713203A13270E2,
	Manager_getHP_m0050B333DB0E55EB4F65DEEFB3E19B416C1391F5,
	Manager_Magnetize_m0A51DBB7DF5D97DADBDEC92B0CE70CC6C97A2CE8,
	Manager_AddSong_mA3C19C86C9E1C4CD35D062ADB0A83CC9057CDF69,
	Manager_Update_m75BF2DFC9C300743E190F02E9D8427F36DB70780,
	Manager__ctor_m5B9F7AAE653DB0466943D59D3579FFCCFC32631E,
	Manager__cctor_m7514095565A4683A758C58B38A884559DDDD4609,
	MenuSc_SetVolume_mA62B7A565EC3B9972479EB9E9B1177703DDCA9C5,
	MenuSc_Update_m3D77170225FA09AC17984B5616DA0C9C9778D74D,
	MenuSc__ctor_mCAF59BB8937F35FF67CDBCCD8105EC9C0A823A78,
	MinibombSc_Start_m276096720A33D49EB04968701C7F84D6FAE65D55,
	MinibombSc_BecomeVisible_mF343236546791E9BB70FECA4CCF5208F904A18EF,
	MinibombSc_OnTriggerStay2D_mE9895BC572A8CFD26952A246E2661FBA339691EA,
	MinibombSc_Explosion2D_mCCFC12965992111F81F1DF14DC69FE7D77389828,
	MinibombSc_CanUse_m88CC37C2713A9DB763151479ACA491D5651C099B,
	MinibombSc__ctor_mC9830F2A7DD8759304EFED032C7E72AF81975912,
	MoveHorSc_OnTriggerEnter2D_m9A1B4A62C414E0E02B832BBA6AD41B79C6726128,
	MoveHorSc_Update_m9ED656D99A357616641EDE44567734FFE0B81BBE,
	MoveHorSc__ctor_mB8A8E76BDF8C439A31BF843385EA8B5D43657999,
	MovingPlatformSc_Start_m003DE983DB317F5E07335755B70C533B2E7ADE67,
	MovingPlatformSc_FixedUpdate_mFC5CBDA538D7F52E206E680A7F02C53A19800231,
	MovingPlatformSc__ctor_m6959AE80DA1815A97089698DB4FB40025E21F56C,
	NPCSc__ctor_m0149A666A067F8EE0D74DF54E8226C2483283577,
	NextLevelSc_Awake_m8714FA706AE38511071EC3A65B8A4DE7CA115778,
	NextLevelSc_Update_m07EA610DE31486AA76FE3914853F612041B7B965,
	NextLevelSc_OnTriggerEnter2D_m40CB8D1F76C91445B62D2559616177305B73A146,
	NextLevelSc_nl_m1BBC91707604B99B10AF944BEDD3C654F1B5B43E,
	NextLevelSc_EndScene_mBBCF920413B3E2C015D9A885EEF31B60822351A2,
	NextLevelSc__ctor_m3A7150BEDEAD0081153EE54D7A307AE2DABFDC19,
	PikupMovementSc_Start_m596629E0900D7DBCF57E3B562B43DB0EF9321421,
	PikupMovementSc_FixedUpdate_mA41FBB33A485FA438502486F50455F6B458EA9B0,
	PikupMovementSc__ctor_m839A68EEE3EE15F5CA484B1A2E0B61B8F3C7D7D5,
	PlayerController_Start_m9531F30EC892BDD1758A2EEC724E86EFBDA150A3,
	PlayerController_CheckInputType_m90D940EBE9D4D83B656351FC9537FBDFFCC08F83,
	PlayerController_OnEsc_m608F417068715935893741129C2F736D4501A0C0,
	PlayerController_quit_m96D402569E2C6C272B440ECB6671C548B8693946,
	PlayerController_onofsound_m8AC9900B9A577623F7485982F5CA6398E7FC0B7F,
	PlayerController_IsPointerOverUIObject_mD3789DF8163DC67DE211849CE080201B71E372D9,
	PlayerController_OnMove_mE981029D7E705952AA17D958FEB08C53D94A06C8,
	PlayerController_OnJump_m706F49543A3371BDCECAD6408E3EF58886523DB1,
	PlayerController_OnUse_mA9B6A47C9CD01A80D199F4AD5403F94BE88F7EE5,
	PlayerController_OnFire_m0569A2B1F92FB45467BE777A3C92D78E11A188A7,
	PlayerController_OnPunch_m7712B091838DE934F0D9A0C4AC97F0F5C1BDF6EF,
	PlayerController_Ground_mD1A0E6AF9E43C756F6E908BD0C2627729635350C,
	PlayerController_Gravity_m23EB48D96BB5B1F6E0E43948A513371663C44C5E,
	PlayerController_CheckMiddleRay_mEDC7579D270CE05585D9C101A32CD1886DB087B7,
	PlayerController_Update_mB31159CAD7DD2329859472554BC9154A83D8E794,
	PlayerController_FixedUpdate_m54EE3ADAA7597303B1F69849B233D1A68D880B14,
	PlayerController_attack_m6625DF7921FD0F5078848321A05144E9EF01269B,
	PlayerController_OnTriggerEnter2D_m1B1E3F94F29560C6CD4687C6556D74A092CC672E,
	PlayerController_OnTriggerExit2D_mA3ABB40D86D202DA68BDB29AC4F7BA24ED1526B1,
	PlayerController_Interaction_m01482BE30A868EAA42377E9F34282273EA7E3421,
	PlayerController_Dialog_m4D8EF0B65C7812C95EB84FBCA8F57B11554FA09E,
	PlayerController_Extext_m83F88BC3FA99C6EF14CA2CC0D962D9F5ECA3225C,
	PlayerController_DialogEnd_mFE5207AD04BA912E6F42DD7A26E381FBCF61B25F,
	PlayerController__ctor_mF30385729DAFDFCB895C4939F6051DCE6C0327FB,
	RatSc_Start_mF7AD4FB51AFEAD41E6BAD2EF57460AB3347013DA,
	RatSc_OnTriggerStay2D_m1C5D300279E2CD5B46F4654848D2082ED6D2BF74,
	RatSc_OnTriggerExit2D_mDA1A242B0EE2AF731D3E3427C1DC7A3DFC759388,
	RatSc_OnColliderEnter_mDD6E4EF3BAD1C10CD9D8C688689AFD74A7BF3FE6,
	RatSc_Update_m17F8ED27F1D232BD1C3CCF717288B734695B3338,
	RatSc__ctor_mB53B2F32D8A64DF39AA714067F9BECC4EE9083BA,
	RocksRestoreSc_OnTriggerEnter2D_m5289F48F839A4A3D4F72463373F1653D63E338EA,
	RocksRestoreSc__ctor_mD14DD37FE202CDA7B9210F7D73CADA56F60E26EC,
	SawItselfSc_Start_m022C0C5CDBEDFAEF4FFED65953A95083709B2A3F,
	SawItselfSc_Update_m479B342172A64BC518D411B48B1A6060D31EE795,
	SawItselfSc__ctor_mD83FA52BB02E03FDAC93C440DEB50A503DBBE22D,
	SawSc_Start_m8BFC7FD06C6C9676F72740D70FBFE724894FEE0B,
	SawSc_OnTriggerStay2D_m5F1A11B00C56F13252A1BFD08FCCD97B3D62B3F6,
	SawSc__ctor_m0F7E0673E8FEB58080BBE9431887BB4A522E4DF5,
	ShockSc_Start_m82C2335110A1551E2B0D1CC3A6732DDB256F526D,
	ShockSc_OnTriggerEnter2D_mE7BE06C3D64552F0393389D4D04D3EDA744A87F1,
	ShockSc_Update_m5C6E24D16353FCBAF89DB6A1DD19E80C04336D83,
	ShockSc__ctor_m0E29D19FE5A2A468DCDF67D0A277C51968ACD5C6,
	SpawnManagerSc_Start_mFFF06B0832C3703C02BE07C06A36EEAD2D5721EC,
	SpawnManagerSc_Update_m6C6B5FECAB513F97AE33A2B3AAB630870924D4D3,
	SpawnManagerSc__ctor_m44F344112772B48E92380C5D6460196C212F35C4,
	SpeedTimerSc_Start_m02A03C61A56744F278BD931D43AD7769A9EC3670,
	SpeedTimerSc_Update_mCDECAEA284AA3CBC1AD4A9C49207942060FD97EF,
	SpeedTimerSc__ctor_m94552475EA860025AB917513D9CDEF576D2F209E,
	StartSc_Start_m3352D3C17CE7A4D5AC85DEBFEF9F052C5D9EF6B2,
	StartSc_OnButton_m3611C33E77E73045DE59BAC4D3AE4BB33419FA5B,
	StartSc_OnExit_m90FC5AB3BCADDECD5C326BA1E95EC4058DAE4EC8,
	StartSc_OnTest_m8A338A81CAF7B11B3F58783F4176231BE17867BF,
	StartSc__ctor_m78C766C67CAA567B28AD155F7823BBB9BE6A68A9,
	lighttowSC_OnTriggerEnter2D_mCAE40405DE0CB7305078738238F403DB84562EAC,
	lighttowSC__ctor_mE5A8CD2700CF3DF63B2814B884A3860F289DCE8C,
	PlayerActions__ctor_mDA15093D50C03D89BFB62810506BD87E1C1CDA08_AdjustorThunk,
	PlayerActions_get_Move_mF91BED7875BF9D3BE614EDFBCD1C14FB2431F10E_AdjustorThunk,
	PlayerActions_get_Look_mAB989AE5BBBF82253A915F4C81F379927447C848_AdjustorThunk,
	PlayerActions_get_MousePos_m916616B5CD02F7A1337E8D0D7F8003C6C6860FF2_AdjustorThunk,
	PlayerActions_get_Use_mCC7A2B943E49D464632DEB5A6311D31F59A5C7F3_AdjustorThunk,
	PlayerActions_get_Run_mFA537D51FAF3CFC32BA0E84957BF54F2C5848634_AdjustorThunk,
	PlayerActions_get_Jump_mFFA322829A0819F940D6026CBAC4B68DB19A860E_AdjustorThunk,
	PlayerActions_get_Fire_mF4B41EE01632AB5C7A137FE1A19AFB3817BF9CCD_AdjustorThunk,
	PlayerActions_get_Esc_m8D541616552D3A53E3220AB61CB173525098EC4A_AdjustorThunk,
	PlayerActions_get_Punch_m0C29529054EC7287CED799904F76F13942D35C85_AdjustorThunk,
	PlayerActions_Get_m6E35B23C5D816F82CC97D591B21C8397CB678F75_AdjustorThunk,
	PlayerActions_Enable_m51B290BB7FD000599545C598B84DD938DCB981F3_AdjustorThunk,
	PlayerActions_Disable_m66DC5AAD57A6EDCC7439D543B4835A237FF736F4_AdjustorThunk,
	PlayerActions_get_enabled_m884E842C6FFED45B5121E24B6212D0EB7F5D5E27_AdjustorThunk,
	PlayerActions_op_Implicit_m05B3D81F858E7CB18C74134F290CAA78F7699C03,
	PlayerActions_SetCallbacks_m4E6B64AF471E45A3EC7EEFA3FEE5919854E7CFCC_AdjustorThunk,
	UIActions__ctor_m2109C97F9526A1C02DFCE5459D233C6582F7F531_AdjustorThunk,
	UIActions_get_Navigate_m835C0B57A206CE85E31A0ECC391C5C9BDE4A37F6_AdjustorThunk,
	UIActions_get_Submit_m08DDE67FA35F5596F83EDC9294D0D0BB960E8105_AdjustorThunk,
	UIActions_get_Cancel_m1F57F685312D55E6C8EF1AB89080CC4D55230BE3_AdjustorThunk,
	UIActions_get_Point_m9EE37892D5E17EBEB0C35D8352E7EAC130E67F34_AdjustorThunk,
	UIActions_get_Click_m0789853719BAA9F4447CAEBF9022E1A1DCF45521_AdjustorThunk,
	UIActions_get_ScrollWheel_m91AFD151331FD99B2E361C7844472CC197375B49_AdjustorThunk,
	UIActions_get_MiddleClick_m1D0ACDA2A1412A63BDDBC122569F826A0841B6DE_AdjustorThunk,
	UIActions_get_RightClick_m7F2C8DED04B5FC90BAE78CB47FDECE6A3AC1461C_AdjustorThunk,
	UIActions_get_TrackedDevicePosition_m75D22A8ABDF111B3E85096BC6C230B166CA9C459_AdjustorThunk,
	UIActions_get_TrackedDeviceOrientation_m7CD1146BE63EDA5B46165DC6EDBECBD5E9A12B7E_AdjustorThunk,
	UIActions_Get_m5D731085792EC48E9E24F644DF0669B87B56C439_AdjustorThunk,
	UIActions_Enable_m8FC1F13397654932695D048C6E579F63759BAFBF_AdjustorThunk,
	UIActions_Disable_m3770A054DB2841B29C0DCADEF029A846C04A9EA6_AdjustorThunk,
	UIActions_get_enabled_m378F4D557A015EDA519F9086F05288B6A0A8315C_AdjustorThunk,
	UIActions_op_Implicit_m82CE45612E1F9E346B4A55451B57EAB223E032F1,
	UIActions_SetCallbacks_mE23EB0929C87574749B8E268B227D5A4095E69CB_AdjustorThunk,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	U3CBecomeVisibleU3Ed__6__ctor_m008DD3D75A27E0212F6ACED5BF297FD95A688048,
	U3CBecomeVisibleU3Ed__6_System_IDisposable_Dispose_m45C388D925DA2789E29C98E555C015FA8D61AECF,
	U3CBecomeVisibleU3Ed__6_MoveNext_m020E3F6850FEDC4758952F571EA16693C547FDDD,
	U3CBecomeVisibleU3Ed__6_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB481DF40F18FF31835D53E21B1404CA63AB22B57,
	U3CBecomeVisibleU3Ed__6_System_Collections_IEnumerator_Reset_m07DA1A80686F43799E2768C6B24D7645D9645252,
	U3CBecomeVisibleU3Ed__6_System_Collections_IEnumerator_get_Current_m9E9DAA3578E9207E343E50075BF4A2C10DF2D865,
	U3CupsU3Ed__11__ctor_m68A129467AF39B673771EC217C6F1DF2D1CC1A94,
	U3CupsU3Ed__11_System_IDisposable_Dispose_m9A1BC42932B8C1AD8D26F3DAF07266AE2567CC73,
	U3CupsU3Ed__11_MoveNext_mEE3F561A48712F0622A8541EBDF7C8EC575FE3A1,
	U3CupsU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m4C5A897962CFE198AA5CAA81FB65281008D153D0,
	U3CupsU3Ed__11_System_Collections_IEnumerator_Reset_m0A7CF0A0615FED3FF89919FF4723C2775433F4AD,
	U3CupsU3Ed__11_System_Collections_IEnumerator_get_Current_m2BA074127D9A622DF1B193884113435B31616A7C,
	U3CwaiterU3Ed__12__ctor_m53429CE291B1B331A6EF2386EDF7EC885F06EFC0,
	U3CwaiterU3Ed__12_System_IDisposable_Dispose_m285159F0C8A10DC82F6ACF681EFB194253580E17,
	U3CwaiterU3Ed__12_MoveNext_m545B749080E1DE0FAE584ABD3F0E19511E014FB6,
	U3CwaiterU3Ed__12_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m55A62BF1DFCE3D2DF8E795747F6C13C5AF772AE4,
	U3CwaiterU3Ed__12_System_Collections_IEnumerator_Reset_m15004F57EC6373BA9FBB7470C5BBA78B7EA713DA,
	U3CwaiterU3Ed__12_System_Collections_IEnumerator_get_Current_m74B86D9C0F29B66DE2FAD5C4C7FDB5EBBCE4B634,
	U3CWaitscU3Ed__25__ctor_mB538B843BCB22D63AA4791C37025A8314A29610F,
	U3CWaitscU3Ed__25_System_IDisposable_Dispose_m15A1DD2B870C96F5F88A851164E5BD785DAAC914,
	U3CWaitscU3Ed__25_MoveNext_m5BDB922C8ED0AE91F48218A2E6F5CA66FB3B4E01,
	U3CWaitscU3Ed__25_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mEA60A29FA1D752861984824B2F0FE6DCD589C18C,
	U3CWaitscU3Ed__25_System_Collections_IEnumerator_Reset_m24E1DE875935E8EA6EE2E63E6B671F98441F2CCA,
	U3CWaitscU3Ed__25_System_Collections_IEnumerator_get_Current_m6EE00C73C3FA60D3A0EEB8FD387692B06CEB5364,
	U3CBecomeVisibleU3Ed__13__ctor_m1CDE93E44F3EB501928163C38E2C8AB172B50316,
	U3CBecomeVisibleU3Ed__13_System_IDisposable_Dispose_mE5B9501E02E34B017A45B5FE08E09C06C345FE51,
	U3CBecomeVisibleU3Ed__13_MoveNext_m8FECC69F36D3F53EF4574CCD0252F272E6E47A6A,
	U3CBecomeVisibleU3Ed__13_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m46C07AF63C36012AFB868E2FE303528F3CB8AC88,
	U3CBecomeVisibleU3Ed__13_System_Collections_IEnumerator_Reset_mC567CC726B93DAD584FEE93248E0591A67FA2D27,
	U3CBecomeVisibleU3Ed__13_System_Collections_IEnumerator_get_Current_m6387C9619ED42AC6F03A1D0D4DA44A209F0BB3B9,
	U3CattackU3Ed__82__ctor_mA3B4E8B939BD2EB29E4C5AE0BCA071CBEDF60802,
	U3CattackU3Ed__82_System_IDisposable_Dispose_m410583EECEAF48C1753D1B15EE0FCEEAA5153F29,
	U3CattackU3Ed__82_MoveNext_mAE353A548F870C35DFA2F78C6A0EB2A432730454,
	U3CattackU3Ed__82_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m2BFFE6B6110DC18C3A89B77EFAD781738946DF11,
	U3CattackU3Ed__82_System_Collections_IEnumerator_Reset_mBDBFD7C488BE11470BD227FFF202B44B02034988,
	U3CattackU3Ed__82_System_Collections_IEnumerator_get_Current_mAF50D991A3BF2ED2A4536183CDFAA971D53A9861,
	U3CExtextU3Ed__87__ctor_m1F38698DE40FF2C6653D23EB07E68C922CE529E3,
	U3CExtextU3Ed__87_System_IDisposable_Dispose_mD0BF3138642129FF3F6A475E5DBE68D9A82C1861,
	U3CExtextU3Ed__87_MoveNext_m42B703FBBDE4BCC9FF4E801DD167A3B1B1627135,
	U3CExtextU3Ed__87_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB6B321FB5A266B7E336EF2CF9F1A35778E9C9167,
	U3CExtextU3Ed__87_System_Collections_IEnumerator_Reset_mA34F804C0B677883B556B17DA22A6DB99B6F4A70,
	U3CExtextU3Ed__87_System_Collections_IEnumerator_get_Current_mAE41389F2D9D417D40001DBF01B96A13C062102A,
};
static const int32_t s_InvokerIndices[267] = 
{
	3119,
	3180,
	3180,
	3020,
	2491,
	3018,
	2489,
	3029,
	2212,
	3119,
	3119,
	3180,
	3180,
	3241,
	3242,
	3092,
	3092,
	3092,
	3092,
	3092,
	3180,
	3119,
	2574,
	3180,
	3180,
	3180,
	3180,
	2574,
	3180,
	3180,
	3180,
	3180,
	3180,
	3119,
	3119,
	2574,
	3180,
	2574,
	2574,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	2574,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	2574,
	3180,
	3180,
	3180,
	2574,
	2574,
	3180,
	3180,
	3180,
	3180,
	2574,
	3180,
	2574,
	3180,
	3180,
	5057,
	3180,
	2610,
	3180,
	3180,
	3119,
	3180,
	3148,
	3180,
	3180,
	3180,
	3180,
	3180,
	2558,
	3180,
	3180,
	5092,
	2610,
	3180,
	3180,
	3180,
	3119,
	2574,
	3180,
	1170,
	3180,
	2574,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	2574,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	2574,
	3180,
	3180,
	3148,
	2574,
	2574,
	2574,
	2574,
	2574,
	1492,
	3180,
	3148,
	3180,
	3180,
	1987,
	2574,
	2574,
	3180,
	2574,
	1984,
	3180,
	3180,
	3180,
	2574,
	2574,
	2574,
	3180,
	3180,
	2574,
	3180,
	3180,
	3180,
	3180,
	3180,
	2574,
	3180,
	3180,
	2574,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	3180,
	2574,
	3180,
	2574,
	3119,
	3119,
	3119,
	3119,
	3119,
	3119,
	3119,
	3119,
	3119,
	3119,
	3180,
	3180,
	3148,
	4875,
	2574,
	2574,
	3119,
	3119,
	3119,
	3119,
	3119,
	3119,
	3119,
	3119,
	3119,
	3119,
	3119,
	3180,
	3180,
	3148,
	4876,
	2574,
	2660,
	2660,
	2660,
	2660,
	2660,
	2660,
	2660,
	2660,
	2660,
	2660,
	2660,
	2660,
	2660,
	2660,
	2660,
	2660,
	2660,
	2660,
	2660,
	2558,
	3180,
	3148,
	3119,
	3180,
	3119,
	2558,
	3180,
	3148,
	3119,
	3180,
	3119,
	2558,
	3180,
	3148,
	3119,
	3180,
	3119,
	2558,
	3180,
	3148,
	3119,
	3180,
	3119,
	2558,
	3180,
	3148,
	3119,
	3180,
	3119,
	2558,
	3180,
	3148,
	3119,
	3180,
	3119,
	2558,
	3180,
	3148,
	3119,
	3180,
	3119,
};
extern const CustomAttributesCacheGenerator g_AssemblyU2DCSharp_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule = 
{
	"Assembly-CSharp.dll",
	267,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_AssemblyU2DCSharp_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
