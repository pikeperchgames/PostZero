﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <limits>
#include <stdint.h>


struct VirtActionInvoker0
{
	typedef void (*Action)(void*, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		((Action)invokeData.methodPtr)(obj, invokeData.method);
	}
};
struct InterfaceActionInvoker0
{
	typedef void (*Action)(void*, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		((Action)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename R>
struct InterfaceFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};

// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>
struct Dictionary_2_tDEF8A5BB0503C6EA9F96F292391AFCF18B07DEF3;
// System.Func`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,System.Boolean>
struct Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863;
// System.Func`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,UnityEngine.InputSystem.Utilities.InternedString>
struct Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9;
// System.Func`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,System.Object>
struct Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE;
// System.Func`2<UnityEngine.Color,System.Boolean>
struct Func_2_t3985FFDAB0D05F8E97E8EA849D5A24F16EFFC4FD;
// System.Func`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,System.Boolean>
struct Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A;
// System.Func`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Color>
struct Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64;
// System.Func`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Vector3>
struct Func_2_tA55660D7B36BC919063457215A12594F309CFDF1;
// System.Func`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,Unity.Mathematics.float3>
struct Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C;
// System.Func`2<System.Int32,System.Boolean>
struct Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274;
// System.Func`2<System.Int32,System.Int32>
struct Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA;
// System.Func`2<UnityEngine.InputSystem.Utilities.InternedString,System.Boolean>
struct Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17;
// System.Func`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString>
struct Func_2_tEE37498C122C43E9F0D581326B5464292A55F235;
// System.Func`2<UnityEngine.InputSystem.Utilities.InternedString,System.Object>
struct Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720;
// System.Func`2<UnityEngine.InputSystem.Utilities.NameAndParameters,System.Boolean>
struct Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082;
// System.Func`2<UnityEngine.InputSystem.Utilities.NameAndParameters,UnityEngine.InputSystem.Utilities.InternedString>
struct Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2;
// System.Func`2<UnityEngine.InputSystem.Utilities.NameAndParameters,System.Object>
struct Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F;
// System.Func`2<UnityEngine.InputSystem.Utilities.NamedValue,System.Boolean>
struct Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8;
// System.Func`2<UnityEngine.InputSystem.Utilities.NamedValue,UnityEngine.InputSystem.Utilities.InternedString>
struct Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D;
// System.Func`2<UnityEngine.InputSystem.Utilities.NamedValue,System.Object>
struct Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54;
// System.Func`2<System.Object,System.Boolean>
struct Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8;
// System.Func`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>
struct Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93;
// System.Func`2<System.Object,System.Object>
struct Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436;
// System.Func`2<UnityEngine.Vector3,System.Boolean>
struct Func_2_t3041FD3183D19FE8416AE2E43A6398B2C06B7269;
// System.Func`2<UnityEngine.Vector3Int,System.Boolean>
struct Func_2_tB3AD6A340F9ED708E8459C7912C86F7504161867;
// System.Func`2<Unity.Mathematics.float3,System.Boolean>
struct Func_2_t43355C55B1BBA93635101F6AF90867509812D7E5;
// System.Func`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,System.Boolean>
struct Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C;
// System.Func`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,UnityEngine.Vector3Int>
struct Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A;
// System.Func`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Boolean>
struct Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747;
// System.Func`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,UnityEngine.InputSystem.Utilities.InternedString>
struct Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C;
// System.Func`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Object>
struct Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64;
// System.Collections.Generic.IEnumerable`1<UnityEngine.Color>
struct IEnumerable_1_tABC441119E42D460CA5B9DED9C1D1A2BD8C836DD;
// System.Collections.Generic.IEnumerable`1<System.Int32>
struct IEnumerable_1_t60929E1AA80B46746F987B99A4EBD004FD72D370;
// System.Collections.Generic.IEnumerable`1<UnityEngine.InputSystem.Utilities.InternedString>
struct IEnumerable_1_tD7F25ACD2C758889E454AD7BF73E0D0E7D423786;
// System.Collections.Generic.IEnumerable`1<System.Object>
struct IEnumerable_1_t52B1AC8D9E5E1ED28DF6C46A37C9A1B00B394F9D;
// System.Collections.Generic.IEnumerable`1<UnityEngine.Vector3>
struct IEnumerable_1_tDBC849B8248C833C53F1762E771EFC477EB8AF18;
// System.Collections.Generic.IEnumerable`1<UnityEngine.Vector3Int>
struct IEnumerable_1_tC910BA619DCAF8AAD81D8365FB14CEED59EE5085;
// System.Collections.Generic.IEnumerable`1<Unity.Mathematics.float3>
struct IEnumerable_1_tE6FE2A92BEFC9DD4F45302076646BA0D6F4807D9;
// System.Collections.Generic.IEnumerable`1<UnityEngine.Tilemaps.GridInformation/GridInformationKey>
struct IEnumerable_1_tBD980F8E029D685F176D4A033C785E848D27A399;
// System.Collections.Generic.IEnumerable`1<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>
struct IEnumerable_1_t75EA08B352EE0D82523A674F20CE1F6A77DE8D94;
// System.Collections.Generic.IEnumerator`1<UnityEngine.Color>
struct IEnumerator_1_t02C24C8A9AB2516412261243B17D8239575F3E86;
// System.Collections.Generic.IEnumerator`1<System.Int32>
struct IEnumerator_1_t72AB4B40AF5290B386215B0BFADC8919D394DCAB;
// System.Collections.Generic.IEnumerator`1<UnityEngine.InputSystem.Utilities.InternedString>
struct IEnumerator_1_tF783BCDC6ABEF5FD64332A72FC8E52A7BB65825A;
// System.Collections.Generic.IEnumerator`1<System.Object>
struct IEnumerator_1_t2DC97C7D486BF9E077C2BC2E517E434F393AA76E;
// System.Collections.Generic.IEnumerator`1<UnityEngine.Vector3>
struct IEnumerator_1_t9C426231952B863270D78D88F9DB5B4E9A16CC6A;
// System.Collections.Generic.IEnumerator`1<UnityEngine.Vector3Int>
struct IEnumerator_1_tC3864263C0D1A413B9892958D671C924368B4B3E;
// System.Collections.Generic.IEnumerator`1<Unity.Mathematics.float3>
struct IEnumerator_1_tB485EF79267D439DD3A02E073C24196FEC5EDD52;
// System.Collections.Generic.IEnumerator`1<UnityEngine.Tilemaps.GridInformation/GridInformationKey>
struct IEnumerator_1_t7DE334B57382702FA91F5B0005EEBADE51545230;
// System.Collections.Generic.IEnumerator`1<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>
struct IEnumerator_1_tDECDFD66FD2C0E184320E779D39F753B263E60C9;
// System.Linq.Enumerable/Iterator`1<UnityEngine.Color>
struct Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76;
// System.Linq.Enumerable/Iterator`1<System.Int32>
struct Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379;
// System.Linq.Enumerable/Iterator`1<UnityEngine.InputSystem.Utilities.InternedString>
struct Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94;
// System.Linq.Enumerable/Iterator`1<System.Object>
struct Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279;
// System.Linq.Enumerable/Iterator`1<UnityEngine.Vector3>
struct Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF;
// System.Linq.Enumerable/Iterator`1<UnityEngine.Vector3Int>
struct Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1;
// System.Linq.Enumerable/Iterator`1<Unity.Mathematics.float3>
struct Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A;
// System.Collections.Generic.List`1<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>>
struct List_1_tA904E5F65F2154445E86287BD8613DCB85340206;
// System.Collections.Generic.List`1<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex>
struct List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C;
// System.Collections.Generic.List`1<System.Int32>
struct List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7;
// System.Collections.Generic.List`1<UnityEngine.InputSystem.Utilities.InternedString>
struct List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49;
// System.Collections.Generic.List`1<UnityEngine.InputSystem.Utilities.NameAndParameters>
struct List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D;
// System.Collections.Generic.List`1<UnityEngine.InputSystem.Utilities.NamedValue>
struct List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774;
// System.Collections.Generic.List`1<System.Object>
struct List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5;
// System.Collections.Generic.List`1<UnityEngine.Tilemaps.GridInformation/GridInformationKey>
struct List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0;
// System.Collections.Generic.List`1<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>
struct List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45;
// System.Linq.Enumerable/WhereSelectEnumerableIterator`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>
struct WhereSelectEnumerableIterator_2_t2F210EE4B2CBE5E1F6A887A375170AD9D3066C6C;
// System.Linq.Enumerable/WhereSelectEnumerableIterator`2<System.Object,System.Object>
struct WhereSelectEnumerableIterator_2_tDAA8BFBEA68F81670F3F51C6200EBD26D7A8FBAB;
// System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,UnityEngine.Vector3Int>
struct WhereSelectEnumerableIterator_2_tE7217C6271607DE91640E1C70700D8EAC5C79632;
// System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,UnityEngine.InputSystem.Utilities.InternedString>
struct WhereSelectEnumerableIterator_2_t2EF803FE6198D12622AB2AC13CC544D3382A753D;
// System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Object>
struct WhereSelectEnumerableIterator_2_tD966222D4DA5DCD2B3C06136FF40DAEF9F631D37;
// System.Linq.Enumerable/WhereSelectListIterator`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,UnityEngine.InputSystem.Utilities.InternedString>
struct WhereSelectListIterator_2_t252DD2ECAA2598C5A96C9D96F81661DB7E55BBD5;
// System.Linq.Enumerable/WhereSelectListIterator`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,System.Object>
struct WhereSelectListIterator_2_tEC5F4A5D3B70CD5D957FD6B731AFBD8925501168;
// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Color>
struct WhereSelectListIterator_2_t08B768B4AD54F201B800C51471E1C1C5FD1A8E8C;
// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Vector3>
struct WhereSelectListIterator_2_t94F415FEA624816E42FAE1274A4EC29F5D5C1625;
// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,Unity.Mathematics.float3>
struct WhereSelectListIterator_2_t8005F348CC0B870A84DE3E85429A840305201D6E;
// System.Linq.Enumerable/WhereSelectListIterator`2<System.Int32,System.Int32>
struct WhereSelectListIterator_2_t4CC3FE3A35610DC6F761EE7DB863B845957AD325;
// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString>
struct WhereSelectListIterator_2_tAEAF0881ED609445F03C4E5691A27493B13F5D3E;
// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.InternedString,System.Object>
struct WhereSelectListIterator_2_t65F4408766820863D04329D21B3BDFB6FD5625B8;
// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NameAndParameters,UnityEngine.InputSystem.Utilities.InternedString>
struct WhereSelectListIterator_2_t9D660598407BAACFC571EA8D5994C24416E7EF72;
// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NameAndParameters,System.Object>
struct WhereSelectListIterator_2_tA136D27DBB78E46ED7DC60EC99A376E9D816FC6A;
// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NamedValue,UnityEngine.InputSystem.Utilities.InternedString>
struct WhereSelectListIterator_2_tDDA7D42453A9A6E14983F2A64F835CA82FB5C3D4;
// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NamedValue,System.Object>
struct WhereSelectListIterator_2_t8DFCE6669BD07F0F7FD9461FACD9D83AAF9F8EE3;
// System.Linq.Enumerable/WhereSelectListIterator`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>
struct WhereSelectListIterator_2_t8E02B4908AA9B882EBD941ADBA2D45EAEA8BF72B;
// System.Linq.Enumerable/WhereSelectListIterator`2<System.Object,System.Object>
struct WhereSelectListIterator_2_t85B78DFF0573BC95A62C79D6088FA39DFEBE1AF2;
// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,UnityEngine.Vector3Int>
struct WhereSelectListIterator_2_t61A00440D82A40FF5366588862F077D31BB2B86D;
// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,UnityEngine.InputSystem.Utilities.InternedString>
struct WhereSelectListIterator_2_t8F78416238F9681ED8DD6A1888291B25087ADB48;
// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Object>
struct WhereSelectListIterator_2_t7BD313142193815CBBFF1CDEAB29F9EAF147B7AA;
// System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>[]
struct KeyValuePair_2U5BU5D_tBA197353C5BF093D63D51F0CE45C73B5033A3ED3;
// System.Char[]
struct CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34;
// UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex[]
struct ContourVertexU5BU5D_tD78F2EA3E732B8F5B5201FA2D894087C252E6F36;
// System.Delegate[]
struct DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8;
// System.Int32[]
struct Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32;
// UnityEngine.InputSystem.Utilities.InternedString[]
struct InternedStringU5BU5D_tFE2B6500E17E6339377CAEF5288CCC0FEDD10AF4;
// UnityEngine.InputSystem.Utilities.NameAndParameters[]
struct NameAndParametersU5BU5D_t15A0C450EE4BA7C09E8F0754AC99B6B4D51303E3;
// UnityEngine.InputSystem.Utilities.NamedValue[]
struct NamedValueU5BU5D_tDF90709375F7673D520D286CEDCE83C4EF7F71B0;
// System.Object[]
struct ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE;
// UnityEngine.Tilemaps.GridInformation/GridInformationKey[]
struct GridInformationKeyU5BU5D_tB2C8C5C2D9FCAA6F837F8B1798436C702969A441;
// UnityEngine.InputSystem.Utilities.JsonParser/JsonValue[]
struct JsonValueU5BU5D_tBD79BB5F11B6DE180CD3184A61491BD668FBC70D;
// System.AsyncCallback
struct AsyncCallback_tA7921BEF974919C46FF8F9D9867C567B200BB0EA;
// System.DelegateData
struct DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288;
// System.IAsyncResult
struct IAsyncResult_tC9F97BF36FCF122D29D3101D80642278297BF370;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.String
struct String_t;
// System.Void
struct Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5;

IL2CPP_EXTERN_C RuntimeClass* IDisposable_t099785737FC6A1E3699919A94109383715A8D807_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* IEnumerator_t5956F3AFB7ECF1117E3BC5890E7FC7B7F7A04105_il2cpp_TypeInfo_var;
struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;


IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object


// System.Linq.Enumerable/Iterator`1<System.Int32>
struct  Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379  : public RuntimeObject
{
public:
	// System.Int32 System.Linq.Enumerable/Iterator`1::threadId
	int32_t ___threadId_0;
	// System.Int32 System.Linq.Enumerable/Iterator`1::state
	int32_t ___state_1;
	// TSource System.Linq.Enumerable/Iterator`1::current
	int32_t ___current_2;

public:
	inline static int32_t get_offset_of_threadId_0() { return static_cast<int32_t>(offsetof(Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379, ___threadId_0)); }
	inline int32_t get_threadId_0() const { return ___threadId_0; }
	inline int32_t* get_address_of_threadId_0() { return &___threadId_0; }
	inline void set_threadId_0(int32_t value)
	{
		___threadId_0 = value;
	}

	inline static int32_t get_offset_of_state_1() { return static_cast<int32_t>(offsetof(Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379, ___state_1)); }
	inline int32_t get_state_1() const { return ___state_1; }
	inline int32_t* get_address_of_state_1() { return &___state_1; }
	inline void set_state_1(int32_t value)
	{
		___state_1 = value;
	}

	inline static int32_t get_offset_of_current_2() { return static_cast<int32_t>(offsetof(Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379, ___current_2)); }
	inline int32_t get_current_2() const { return ___current_2; }
	inline int32_t* get_address_of_current_2() { return &___current_2; }
	inline void set_current_2(int32_t value)
	{
		___current_2 = value;
	}
};


// System.Linq.Enumerable/Iterator`1<System.Object>
struct  Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279  : public RuntimeObject
{
public:
	// System.Int32 System.Linq.Enumerable/Iterator`1::threadId
	int32_t ___threadId_0;
	// System.Int32 System.Linq.Enumerable/Iterator`1::state
	int32_t ___state_1;
	// TSource System.Linq.Enumerable/Iterator`1::current
	RuntimeObject * ___current_2;

public:
	inline static int32_t get_offset_of_threadId_0() { return static_cast<int32_t>(offsetof(Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279, ___threadId_0)); }
	inline int32_t get_threadId_0() const { return ___threadId_0; }
	inline int32_t* get_address_of_threadId_0() { return &___threadId_0; }
	inline void set_threadId_0(int32_t value)
	{
		___threadId_0 = value;
	}

	inline static int32_t get_offset_of_state_1() { return static_cast<int32_t>(offsetof(Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279, ___state_1)); }
	inline int32_t get_state_1() const { return ___state_1; }
	inline int32_t* get_address_of_state_1() { return &___state_1; }
	inline void set_state_1(int32_t value)
	{
		___state_1 = value;
	}

	inline static int32_t get_offset_of_current_2() { return static_cast<int32_t>(offsetof(Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279, ___current_2)); }
	inline RuntimeObject * get_current_2() const { return ___current_2; }
	inline RuntimeObject ** get_address_of_current_2() { return &___current_2; }
	inline void set_current_2(RuntimeObject * value)
	{
		___current_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___current_2), (void*)value);
	}
};


// System.Collections.Generic.List`1<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>>
struct  List_1_tA904E5F65F2154445E86287BD8613DCB85340206  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	KeyValuePair_2U5BU5D_tBA197353C5BF093D63D51F0CE45C73B5033A3ED3* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_tA904E5F65F2154445E86287BD8613DCB85340206, ____items_1)); }
	inline KeyValuePair_2U5BU5D_tBA197353C5BF093D63D51F0CE45C73B5033A3ED3* get__items_1() const { return ____items_1; }
	inline KeyValuePair_2U5BU5D_tBA197353C5BF093D63D51F0CE45C73B5033A3ED3** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(KeyValuePair_2U5BU5D_tBA197353C5BF093D63D51F0CE45C73B5033A3ED3* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_tA904E5F65F2154445E86287BD8613DCB85340206, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_tA904E5F65F2154445E86287BD8613DCB85340206, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_tA904E5F65F2154445E86287BD8613DCB85340206, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_tA904E5F65F2154445E86287BD8613DCB85340206_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	KeyValuePair_2U5BU5D_tBA197353C5BF093D63D51F0CE45C73B5033A3ED3* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_tA904E5F65F2154445E86287BD8613DCB85340206_StaticFields, ____emptyArray_5)); }
	inline KeyValuePair_2U5BU5D_tBA197353C5BF093D63D51F0CE45C73B5033A3ED3* get__emptyArray_5() const { return ____emptyArray_5; }
	inline KeyValuePair_2U5BU5D_tBA197353C5BF093D63D51F0CE45C73B5033A3ED3** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(KeyValuePair_2U5BU5D_tBA197353C5BF093D63D51F0CE45C73B5033A3ED3* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.Collections.Generic.List`1<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex>
struct  List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	ContourVertexU5BU5D_tD78F2EA3E732B8F5B5201FA2D894087C252E6F36* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C, ____items_1)); }
	inline ContourVertexU5BU5D_tD78F2EA3E732B8F5B5201FA2D894087C252E6F36* get__items_1() const { return ____items_1; }
	inline ContourVertexU5BU5D_tD78F2EA3E732B8F5B5201FA2D894087C252E6F36** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(ContourVertexU5BU5D_tD78F2EA3E732B8F5B5201FA2D894087C252E6F36* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	ContourVertexU5BU5D_tD78F2EA3E732B8F5B5201FA2D894087C252E6F36* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C_StaticFields, ____emptyArray_5)); }
	inline ContourVertexU5BU5D_tD78F2EA3E732B8F5B5201FA2D894087C252E6F36* get__emptyArray_5() const { return ____emptyArray_5; }
	inline ContourVertexU5BU5D_tD78F2EA3E732B8F5B5201FA2D894087C252E6F36** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(ContourVertexU5BU5D_tD78F2EA3E732B8F5B5201FA2D894087C252E6F36* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.Collections.Generic.List`1<System.Int32>
struct  List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7, ____items_1)); }
	inline Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32* get__items_1() const { return ____items_1; }
	inline Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7_StaticFields, ____emptyArray_5)); }
	inline Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32* get__emptyArray_5() const { return ____emptyArray_5; }
	inline Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.Collections.Generic.List`1<UnityEngine.InputSystem.Utilities.InternedString>
struct  List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	InternedStringU5BU5D_tFE2B6500E17E6339377CAEF5288CCC0FEDD10AF4* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49, ____items_1)); }
	inline InternedStringU5BU5D_tFE2B6500E17E6339377CAEF5288CCC0FEDD10AF4* get__items_1() const { return ____items_1; }
	inline InternedStringU5BU5D_tFE2B6500E17E6339377CAEF5288CCC0FEDD10AF4** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(InternedStringU5BU5D_tFE2B6500E17E6339377CAEF5288CCC0FEDD10AF4* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	InternedStringU5BU5D_tFE2B6500E17E6339377CAEF5288CCC0FEDD10AF4* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49_StaticFields, ____emptyArray_5)); }
	inline InternedStringU5BU5D_tFE2B6500E17E6339377CAEF5288CCC0FEDD10AF4* get__emptyArray_5() const { return ____emptyArray_5; }
	inline InternedStringU5BU5D_tFE2B6500E17E6339377CAEF5288CCC0FEDD10AF4** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(InternedStringU5BU5D_tFE2B6500E17E6339377CAEF5288CCC0FEDD10AF4* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.Collections.Generic.List`1<UnityEngine.InputSystem.Utilities.NameAndParameters>
struct  List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	NameAndParametersU5BU5D_t15A0C450EE4BA7C09E8F0754AC99B6B4D51303E3* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D, ____items_1)); }
	inline NameAndParametersU5BU5D_t15A0C450EE4BA7C09E8F0754AC99B6B4D51303E3* get__items_1() const { return ____items_1; }
	inline NameAndParametersU5BU5D_t15A0C450EE4BA7C09E8F0754AC99B6B4D51303E3** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(NameAndParametersU5BU5D_t15A0C450EE4BA7C09E8F0754AC99B6B4D51303E3* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	NameAndParametersU5BU5D_t15A0C450EE4BA7C09E8F0754AC99B6B4D51303E3* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D_StaticFields, ____emptyArray_5)); }
	inline NameAndParametersU5BU5D_t15A0C450EE4BA7C09E8F0754AC99B6B4D51303E3* get__emptyArray_5() const { return ____emptyArray_5; }
	inline NameAndParametersU5BU5D_t15A0C450EE4BA7C09E8F0754AC99B6B4D51303E3** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(NameAndParametersU5BU5D_t15A0C450EE4BA7C09E8F0754AC99B6B4D51303E3* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.Collections.Generic.List`1<UnityEngine.InputSystem.Utilities.NamedValue>
struct  List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	NamedValueU5BU5D_tDF90709375F7673D520D286CEDCE83C4EF7F71B0* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774, ____items_1)); }
	inline NamedValueU5BU5D_tDF90709375F7673D520D286CEDCE83C4EF7F71B0* get__items_1() const { return ____items_1; }
	inline NamedValueU5BU5D_tDF90709375F7673D520D286CEDCE83C4EF7F71B0** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(NamedValueU5BU5D_tDF90709375F7673D520D286CEDCE83C4EF7F71B0* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	NamedValueU5BU5D_tDF90709375F7673D520D286CEDCE83C4EF7F71B0* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774_StaticFields, ____emptyArray_5)); }
	inline NamedValueU5BU5D_tDF90709375F7673D520D286CEDCE83C4EF7F71B0* get__emptyArray_5() const { return ____emptyArray_5; }
	inline NamedValueU5BU5D_tDF90709375F7673D520D286CEDCE83C4EF7F71B0** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(NamedValueU5BU5D_tDF90709375F7673D520D286CEDCE83C4EF7F71B0* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.Collections.Generic.List`1<System.Object>
struct  List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5, ____items_1)); }
	inline ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* get__items_1() const { return ____items_1; }
	inline ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5_StaticFields, ____emptyArray_5)); }
	inline ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* get__emptyArray_5() const { return ____emptyArray_5; }
	inline ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.Collections.Generic.List`1<UnityEngine.Tilemaps.GridInformation/GridInformationKey>
struct  List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	GridInformationKeyU5BU5D_tB2C8C5C2D9FCAA6F837F8B1798436C702969A441* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0, ____items_1)); }
	inline GridInformationKeyU5BU5D_tB2C8C5C2D9FCAA6F837F8B1798436C702969A441* get__items_1() const { return ____items_1; }
	inline GridInformationKeyU5BU5D_tB2C8C5C2D9FCAA6F837F8B1798436C702969A441** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(GridInformationKeyU5BU5D_tB2C8C5C2D9FCAA6F837F8B1798436C702969A441* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	GridInformationKeyU5BU5D_tB2C8C5C2D9FCAA6F837F8B1798436C702969A441* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0_StaticFields, ____emptyArray_5)); }
	inline GridInformationKeyU5BU5D_tB2C8C5C2D9FCAA6F837F8B1798436C702969A441* get__emptyArray_5() const { return ____emptyArray_5; }
	inline GridInformationKeyU5BU5D_tB2C8C5C2D9FCAA6F837F8B1798436C702969A441** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(GridInformationKeyU5BU5D_tB2C8C5C2D9FCAA6F837F8B1798436C702969A441* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.Collections.Generic.List`1<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>
struct  List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	JsonValueU5BU5D_tBD79BB5F11B6DE180CD3184A61491BD668FBC70D* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45, ____items_1)); }
	inline JsonValueU5BU5D_tBD79BB5F11B6DE180CD3184A61491BD668FBC70D* get__items_1() const { return ____items_1; }
	inline JsonValueU5BU5D_tBD79BB5F11B6DE180CD3184A61491BD668FBC70D** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(JsonValueU5BU5D_tBD79BB5F11B6DE180CD3184A61491BD668FBC70D* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	JsonValueU5BU5D_tBD79BB5F11B6DE180CD3184A61491BD668FBC70D* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45_StaticFields, ____emptyArray_5)); }
	inline JsonValueU5BU5D_tBD79BB5F11B6DE180CD3184A61491BD668FBC70D* get__emptyArray_5() const { return ____emptyArray_5; }
	inline JsonValueU5BU5D_tBD79BB5F11B6DE180CD3184A61491BD668FBC70D** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(JsonValueU5BU5D_tBD79BB5F11B6DE180CD3184A61491BD668FBC70D* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};

struct Il2CppArrayBounds;

// System.Array


// System.ValueType
struct  ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52  : public RuntimeObject
{
public:

public:
};

// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_com
{
};

// System.Collections.Generic.List`1/Enumerator<System.Int32>
struct  Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::list
	List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 * ___list_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::index
	int32_t ___index_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::version
	int32_t ___version_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	int32_t ___current_3;

public:
	inline static int32_t get_offset_of_list_0() { return static_cast<int32_t>(offsetof(Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C, ___list_0)); }
	inline List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 * get_list_0() const { return ___list_0; }
	inline List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 ** get_address_of_list_0() { return &___list_0; }
	inline void set_list_0(List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 * value)
	{
		___list_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___list_0), (void*)value);
	}

	inline static int32_t get_offset_of_index_1() { return static_cast<int32_t>(offsetof(Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C, ___index_1)); }
	inline int32_t get_index_1() const { return ___index_1; }
	inline int32_t* get_address_of_index_1() { return &___index_1; }
	inline void set_index_1(int32_t value)
	{
		___index_1 = value;
	}

	inline static int32_t get_offset_of_version_2() { return static_cast<int32_t>(offsetof(Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C, ___version_2)); }
	inline int32_t get_version_2() const { return ___version_2; }
	inline int32_t* get_address_of_version_2() { return &___version_2; }
	inline void set_version_2(int32_t value)
	{
		___version_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C, ___current_3)); }
	inline int32_t get_current_3() const { return ___current_3; }
	inline int32_t* get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(int32_t value)
	{
		___current_3 = value;
	}
};


// System.Collections.Generic.List`1/Enumerator<System.Object>
struct  Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::list
	List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * ___list_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::index
	int32_t ___index_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::version
	int32_t ___version_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	RuntimeObject * ___current_3;

public:
	inline static int32_t get_offset_of_list_0() { return static_cast<int32_t>(offsetof(Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6, ___list_0)); }
	inline List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * get_list_0() const { return ___list_0; }
	inline List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 ** get_address_of_list_0() { return &___list_0; }
	inline void set_list_0(List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * value)
	{
		___list_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___list_0), (void*)value);
	}

	inline static int32_t get_offset_of_index_1() { return static_cast<int32_t>(offsetof(Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6, ___index_1)); }
	inline int32_t get_index_1() const { return ___index_1; }
	inline int32_t* get_address_of_index_1() { return &___index_1; }
	inline void set_index_1(int32_t value)
	{
		___index_1 = value;
	}

	inline static int32_t get_offset_of_version_2() { return static_cast<int32_t>(offsetof(Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6, ___version_2)); }
	inline int32_t get_version_2() const { return ___version_2; }
	inline int32_t* get_address_of_version_2() { return &___version_2; }
	inline void set_version_2(int32_t value)
	{
		___version_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6, ___current_3)); }
	inline RuntimeObject * get_current_3() const { return ___current_3; }
	inline RuntimeObject ** get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(RuntimeObject * value)
	{
		___current_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___current_3), (void*)value);
	}
};


// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.NamedValue>
struct  ReadOnlyArray_1_t0E4793FE3B663B5A6022E32DA0988B6C435F7AB2 
{
public:
	// TValue[] UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_Array
	NamedValueU5BU5D_tDF90709375F7673D520D286CEDCE83C4EF7F71B0* ___m_Array_0;
	// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_StartIndex
	int32_t ___m_StartIndex_1;
	// System.Int32 UnityEngine.InputSystem.Utilities.ReadOnlyArray`1::m_Length
	int32_t ___m_Length_2;

public:
	inline static int32_t get_offset_of_m_Array_0() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_t0E4793FE3B663B5A6022E32DA0988B6C435F7AB2, ___m_Array_0)); }
	inline NamedValueU5BU5D_tDF90709375F7673D520D286CEDCE83C4EF7F71B0* get_m_Array_0() const { return ___m_Array_0; }
	inline NamedValueU5BU5D_tDF90709375F7673D520D286CEDCE83C4EF7F71B0** get_address_of_m_Array_0() { return &___m_Array_0; }
	inline void set_m_Array_0(NamedValueU5BU5D_tDF90709375F7673D520D286CEDCE83C4EF7F71B0* value)
	{
		___m_Array_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Array_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_StartIndex_1() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_t0E4793FE3B663B5A6022E32DA0988B6C435F7AB2, ___m_StartIndex_1)); }
	inline int32_t get_m_StartIndex_1() const { return ___m_StartIndex_1; }
	inline int32_t* get_address_of_m_StartIndex_1() { return &___m_StartIndex_1; }
	inline void set_m_StartIndex_1(int32_t value)
	{
		___m_StartIndex_1 = value;
	}

	inline static int32_t get_offset_of_m_Length_2() { return static_cast<int32_t>(offsetof(ReadOnlyArray_1_t0E4793FE3B663B5A6022E32DA0988B6C435F7AB2, ___m_Length_2)); }
	inline int32_t get_m_Length_2() const { return ___m_Length_2; }
	inline int32_t* get_address_of_m_Length_2() { return &___m_Length_2; }
	inline void set_m_Length_2(int32_t value)
	{
		___m_Length_2 = value;
	}
};


// System.Linq.Enumerable/WhereEnumerableIterator`1<System.Int32>
struct  WhereEnumerableIterator_1_t9F4DDC70173BABD72AEC7AA00D62F4FAE2613CEA  : public Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379
{
public:
	// System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable/WhereEnumerableIterator`1::source
	RuntimeObject* ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereEnumerableIterator`1::predicate
	Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 * ___predicate_4;
	// System.Collections.Generic.IEnumerator`1<TSource> System.Linq.Enumerable/WhereEnumerableIterator`1::enumerator
	RuntimeObject* ___enumerator_5;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_t9F4DDC70173BABD72AEC7AA00D62F4FAE2613CEA, ___source_3)); }
	inline RuntimeObject* get_source_3() const { return ___source_3; }
	inline RuntimeObject** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(RuntimeObject* value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_t9F4DDC70173BABD72AEC7AA00D62F4FAE2613CEA, ___predicate_4)); }
	inline Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_5() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_t9F4DDC70173BABD72AEC7AA00D62F4FAE2613CEA, ___enumerator_5)); }
	inline RuntimeObject* get_enumerator_5() const { return ___enumerator_5; }
	inline RuntimeObject** get_address_of_enumerator_5() { return &___enumerator_5; }
	inline void set_enumerator_5(RuntimeObject* value)
	{
		___enumerator_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumerator_5), (void*)value);
	}
};


// System.Linq.Enumerable/WhereEnumerableIterator`1<System.Object>
struct  WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0  : public Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279
{
public:
	// System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable/WhereEnumerableIterator`1::source
	RuntimeObject* ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereEnumerableIterator`1::predicate
	Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate_4;
	// System.Collections.Generic.IEnumerator`1<TSource> System.Linq.Enumerable/WhereEnumerableIterator`1::enumerator
	RuntimeObject* ___enumerator_5;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0, ___source_3)); }
	inline RuntimeObject* get_source_3() const { return ___source_3; }
	inline RuntimeObject** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(RuntimeObject* value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0, ___predicate_4)); }
	inline Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_5() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0, ___enumerator_5)); }
	inline RuntimeObject* get_enumerator_5() const { return ___enumerator_5; }
	inline RuntimeObject** get_address_of_enumerator_5() { return &___enumerator_5; }
	inline void set_enumerator_5(RuntimeObject* value)
	{
		___enumerator_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumerator_5), (void*)value);
	}
};


// System.Linq.Enumerable/WhereSelectEnumerableIterator`2<System.Object,System.Object>
struct  WhereSelectEnumerableIterator_2_tDAA8BFBEA68F81670F3F51C6200EBD26D7A8FBAB  : public Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279
{
public:
	// System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::source
	RuntimeObject* ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::predicate
	Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::selector
	Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 * ___selector_5;
	// System.Collections.Generic.IEnumerator`1<TSource> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::enumerator
	RuntimeObject* ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_tDAA8BFBEA68F81670F3F51C6200EBD26D7A8FBAB, ___source_3)); }
	inline RuntimeObject* get_source_3() const { return ___source_3; }
	inline RuntimeObject** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(RuntimeObject* value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_tDAA8BFBEA68F81670F3F51C6200EBD26D7A8FBAB, ___predicate_4)); }
	inline Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_tDAA8BFBEA68F81670F3F51C6200EBD26D7A8FBAB, ___selector_5)); }
	inline Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 * get_selector_5() const { return ___selector_5; }
	inline Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_tDAA8BFBEA68F81670F3F51C6200EBD26D7A8FBAB, ___enumerator_6)); }
	inline RuntimeObject* get_enumerator_6() const { return ___enumerator_6; }
	inline RuntimeObject** get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(RuntimeObject* value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumerator_6), (void*)value);
	}
};


// System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Object>
struct  WhereSelectEnumerableIterator_2_tD966222D4DA5DCD2B3C06136FF40DAEF9F631D37  : public Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279
{
public:
	// System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::source
	RuntimeObject* ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::predicate
	Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::selector
	Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 * ___selector_5;
	// System.Collections.Generic.IEnumerator`1<TSource> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::enumerator
	RuntimeObject* ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_tD966222D4DA5DCD2B3C06136FF40DAEF9F631D37, ___source_3)); }
	inline RuntimeObject* get_source_3() const { return ___source_3; }
	inline RuntimeObject** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(RuntimeObject* value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_tD966222D4DA5DCD2B3C06136FF40DAEF9F631D37, ___predicate_4)); }
	inline Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_tD966222D4DA5DCD2B3C06136FF40DAEF9F631D37, ___selector_5)); }
	inline Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 * get_selector_5() const { return ___selector_5; }
	inline Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_tD966222D4DA5DCD2B3C06136FF40DAEF9F631D37, ___enumerator_6)); }
	inline RuntimeObject* get_enumerator_6() const { return ___enumerator_6; }
	inline RuntimeObject** get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(RuntimeObject* value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumerator_6), (void*)value);
	}
};


// System.Boolean
struct  Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37, ___m_value_0)); }
	inline bool get_m_value_0() const { return ___m_value_0; }
	inline bool* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(bool value)
	{
		___m_value_0 = value;
	}
};

struct Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields
{
public:
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;

public:
	inline static int32_t get_offset_of_TrueString_5() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields, ___TrueString_5)); }
	inline String_t* get_TrueString_5() const { return ___TrueString_5; }
	inline String_t** get_address_of_TrueString_5() { return &___TrueString_5; }
	inline void set_TrueString_5(String_t* value)
	{
		___TrueString_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TrueString_5), (void*)value);
	}

	inline static int32_t get_offset_of_FalseString_6() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields, ___FalseString_6)); }
	inline String_t* get_FalseString_6() const { return ___FalseString_6; }
	inline String_t** get_address_of_FalseString_6() { return &___FalseString_6; }
	inline void set_FalseString_6(String_t* value)
	{
		___FalseString_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FalseString_6), (void*)value);
	}
};


// UnityEngine.Color
struct  Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659 
{
public:
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;

public:
	inline static int32_t get_offset_of_r_0() { return static_cast<int32_t>(offsetof(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659, ___r_0)); }
	inline float get_r_0() const { return ___r_0; }
	inline float* get_address_of_r_0() { return &___r_0; }
	inline void set_r_0(float value)
	{
		___r_0 = value;
	}

	inline static int32_t get_offset_of_g_1() { return static_cast<int32_t>(offsetof(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659, ___g_1)); }
	inline float get_g_1() const { return ___g_1; }
	inline float* get_address_of_g_1() { return &___g_1; }
	inline void set_g_1(float value)
	{
		___g_1 = value;
	}

	inline static int32_t get_offset_of_b_2() { return static_cast<int32_t>(offsetof(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659, ___b_2)); }
	inline float get_b_2() const { return ___b_2; }
	inline float* get_address_of_b_2() { return &___b_2; }
	inline void set_b_2(float value)
	{
		___b_2 = value;
	}

	inline static int32_t get_offset_of_a_3() { return static_cast<int32_t>(offsetof(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659, ___a_3)); }
	inline float get_a_3() const { return ___a_3; }
	inline float* get_address_of_a_3() { return &___a_3; }
	inline void set_a_3(float value)
	{
		___a_3 = value;
	}
};


// System.Enum
struct  Enum_t23B90B40F60E677A8025267341651C94AE079CDA  : public ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52
{
public:

public:
};

struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t23B90B40F60E677A8025267341651C94AE079CDA_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumSeperatorCharArray_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_marshaled_com
{
};

// System.Int32
struct  Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};


// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};


// UnityEngine.InputSystem.Utilities.InternedString
struct  InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D 
{
public:
	// System.String UnityEngine.InputSystem.Utilities.InternedString::m_StringOriginalCase
	String_t* ___m_StringOriginalCase_0;
	// System.String UnityEngine.InputSystem.Utilities.InternedString::m_StringLowerCase
	String_t* ___m_StringLowerCase_1;

public:
	inline static int32_t get_offset_of_m_StringOriginalCase_0() { return static_cast<int32_t>(offsetof(InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D, ___m_StringOriginalCase_0)); }
	inline String_t* get_m_StringOriginalCase_0() const { return ___m_StringOriginalCase_0; }
	inline String_t** get_address_of_m_StringOriginalCase_0() { return &___m_StringOriginalCase_0; }
	inline void set_m_StringOriginalCase_0(String_t* value)
	{
		___m_StringOriginalCase_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_StringOriginalCase_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_StringLowerCase_1() { return static_cast<int32_t>(offsetof(InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D, ___m_StringLowerCase_1)); }
	inline String_t* get_m_StringLowerCase_1() const { return ___m_StringLowerCase_1; }
	inline String_t** get_address_of_m_StringLowerCase_1() { return &___m_StringLowerCase_1; }
	inline void set_m_StringLowerCase_1(String_t* value)
	{
		___m_StringLowerCase_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_StringLowerCase_1), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Utilities.InternedString
struct InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D_marshaled_pinvoke
{
	char* ___m_StringOriginalCase_0;
	char* ___m_StringLowerCase_1;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Utilities.InternedString
struct InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D_marshaled_com
{
	Il2CppChar* ___m_StringOriginalCase_0;
	Il2CppChar* ___m_StringLowerCase_1;
};

// UnityEngine.InputSystem.Utilities.Substring
struct  Substring_t1B63EC71C55D91EDAFFBDBD246A839EC23B88A2B 
{
public:
	// System.String UnityEngine.InputSystem.Utilities.Substring::m_String
	String_t* ___m_String_0;
	// System.Int32 UnityEngine.InputSystem.Utilities.Substring::m_Index
	int32_t ___m_Index_1;
	// System.Int32 UnityEngine.InputSystem.Utilities.Substring::m_Length
	int32_t ___m_Length_2;

public:
	inline static int32_t get_offset_of_m_String_0() { return static_cast<int32_t>(offsetof(Substring_t1B63EC71C55D91EDAFFBDBD246A839EC23B88A2B, ___m_String_0)); }
	inline String_t* get_m_String_0() const { return ___m_String_0; }
	inline String_t** get_address_of_m_String_0() { return &___m_String_0; }
	inline void set_m_String_0(String_t* value)
	{
		___m_String_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_String_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_Index_1() { return static_cast<int32_t>(offsetof(Substring_t1B63EC71C55D91EDAFFBDBD246A839EC23B88A2B, ___m_Index_1)); }
	inline int32_t get_m_Index_1() const { return ___m_Index_1; }
	inline int32_t* get_address_of_m_Index_1() { return &___m_Index_1; }
	inline void set_m_Index_1(int32_t value)
	{
		___m_Index_1 = value;
	}

	inline static int32_t get_offset_of_m_Length_2() { return static_cast<int32_t>(offsetof(Substring_t1B63EC71C55D91EDAFFBDBD246A839EC23B88A2B, ___m_Length_2)); }
	inline int32_t get_m_Length_2() const { return ___m_Length_2; }
	inline int32_t* get_address_of_m_Length_2() { return &___m_Length_2; }
	inline void set_m_Length_2(int32_t value)
	{
		___m_Length_2 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Utilities.Substring
struct Substring_t1B63EC71C55D91EDAFFBDBD246A839EC23B88A2B_marshaled_pinvoke
{
	char* ___m_String_0;
	int32_t ___m_Index_1;
	int32_t ___m_Length_2;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Utilities.Substring
struct Substring_t1B63EC71C55D91EDAFFBDBD246A839EC23B88A2B_marshaled_com
{
	Il2CppChar* ___m_String_0;
	int32_t ___m_Index_1;
	int32_t ___m_Length_2;
};

// UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.Vec3
struct  Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1 
{
public:
	// System.Single UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.Vec3::X
	float ___X_1;
	// System.Single UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.Vec3::Y
	float ___Y_2;
	// System.Single UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.Vec3::Z
	float ___Z_3;

public:
	inline static int32_t get_offset_of_X_1() { return static_cast<int32_t>(offsetof(Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1, ___X_1)); }
	inline float get_X_1() const { return ___X_1; }
	inline float* get_address_of_X_1() { return &___X_1; }
	inline void set_X_1(float value)
	{
		___X_1 = value;
	}

	inline static int32_t get_offset_of_Y_2() { return static_cast<int32_t>(offsetof(Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1, ___Y_2)); }
	inline float get_Y_2() const { return ___Y_2; }
	inline float* get_address_of_Y_2() { return &___Y_2; }
	inline void set_Y_2(float value)
	{
		___Y_2 = value;
	}

	inline static int32_t get_offset_of_Z_3() { return static_cast<int32_t>(offsetof(Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1, ___Z_3)); }
	inline float get_Z_3() const { return ___Z_3; }
	inline float* get_address_of_Z_3() { return &___Z_3; }
	inline void set_Z_3(float value)
	{
		___Z_3 = value;
	}
};

struct Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1_StaticFields
{
public:
	// UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.Vec3 UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.Vec3::Zero
	Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1  ___Zero_0;

public:
	inline static int32_t get_offset_of_Zero_0() { return static_cast<int32_t>(offsetof(Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1_StaticFields, ___Zero_0)); }
	inline Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1  get_Zero_0() const { return ___Zero_0; }
	inline Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1 * get_address_of_Zero_0() { return &___Zero_0; }
	inline void set_Zero_0(Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1  value)
	{
		___Zero_0 = value;
	}
};


// UnityEngine.Vector3
struct  Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E 
{
public:
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;

public:
	inline static int32_t get_offset_of_x_2() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E, ___x_2)); }
	inline float get_x_2() const { return ___x_2; }
	inline float* get_address_of_x_2() { return &___x_2; }
	inline void set_x_2(float value)
	{
		___x_2 = value;
	}

	inline static int32_t get_offset_of_y_3() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E, ___y_3)); }
	inline float get_y_3() const { return ___y_3; }
	inline float* get_address_of_y_3() { return &___y_3; }
	inline void set_y_3(float value)
	{
		___y_3 = value;
	}

	inline static int32_t get_offset_of_z_4() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E, ___z_4)); }
	inline float get_z_4() const { return ___z_4; }
	inline float* get_address_of_z_4() { return &___z_4; }
	inline void set_z_4(float value)
	{
		___z_4 = value;
	}
};

struct Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields
{
public:
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___negativeInfinityVector_14;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___zeroVector_5)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___oneVector_6)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_upVector_7() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___upVector_7)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_upVector_7() const { return ___upVector_7; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_upVector_7() { return &___upVector_7; }
	inline void set_upVector_7(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___upVector_7 = value;
	}

	inline static int32_t get_offset_of_downVector_8() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___downVector_8)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_downVector_8() const { return ___downVector_8; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_downVector_8() { return &___downVector_8; }
	inline void set_downVector_8(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___downVector_8 = value;
	}

	inline static int32_t get_offset_of_leftVector_9() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___leftVector_9)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_leftVector_9() const { return ___leftVector_9; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_leftVector_9() { return &___leftVector_9; }
	inline void set_leftVector_9(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___leftVector_9 = value;
	}

	inline static int32_t get_offset_of_rightVector_10() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___rightVector_10)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_rightVector_10() const { return ___rightVector_10; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_rightVector_10() { return &___rightVector_10; }
	inline void set_rightVector_10(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___rightVector_10 = value;
	}

	inline static int32_t get_offset_of_forwardVector_11() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___forwardVector_11)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_forwardVector_11() const { return ___forwardVector_11; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_forwardVector_11() { return &___forwardVector_11; }
	inline void set_forwardVector_11(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___forwardVector_11 = value;
	}

	inline static int32_t get_offset_of_backVector_12() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___backVector_12)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_backVector_12() const { return ___backVector_12; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_backVector_12() { return &___backVector_12; }
	inline void set_backVector_12(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___backVector_12 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_13() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___positiveInfinityVector_13)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_positiveInfinityVector_13() const { return ___positiveInfinityVector_13; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_positiveInfinityVector_13() { return &___positiveInfinityVector_13; }
	inline void set_positiveInfinityVector_13(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___positiveInfinityVector_13 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_14() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___negativeInfinityVector_14)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_negativeInfinityVector_14() const { return ___negativeInfinityVector_14; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_negativeInfinityVector_14() { return &___negativeInfinityVector_14; }
	inline void set_negativeInfinityVector_14(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___negativeInfinityVector_14 = value;
	}
};


// UnityEngine.Vector3Int
struct  Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA 
{
public:
	// System.Int32 UnityEngine.Vector3Int::m_X
	int32_t ___m_X_0;
	// System.Int32 UnityEngine.Vector3Int::m_Y
	int32_t ___m_Y_1;
	// System.Int32 UnityEngine.Vector3Int::m_Z
	int32_t ___m_Z_2;

public:
	inline static int32_t get_offset_of_m_X_0() { return static_cast<int32_t>(offsetof(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA, ___m_X_0)); }
	inline int32_t get_m_X_0() const { return ___m_X_0; }
	inline int32_t* get_address_of_m_X_0() { return &___m_X_0; }
	inline void set_m_X_0(int32_t value)
	{
		___m_X_0 = value;
	}

	inline static int32_t get_offset_of_m_Y_1() { return static_cast<int32_t>(offsetof(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA, ___m_Y_1)); }
	inline int32_t get_m_Y_1() const { return ___m_Y_1; }
	inline int32_t* get_address_of_m_Y_1() { return &___m_Y_1; }
	inline void set_m_Y_1(int32_t value)
	{
		___m_Y_1 = value;
	}

	inline static int32_t get_offset_of_m_Z_2() { return static_cast<int32_t>(offsetof(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA, ___m_Z_2)); }
	inline int32_t get_m_Z_2() const { return ___m_Z_2; }
	inline int32_t* get_address_of_m_Z_2() { return &___m_Z_2; }
	inline void set_m_Z_2(int32_t value)
	{
		___m_Z_2 = value;
	}
};

struct Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA_StaticFields
{
public:
	// UnityEngine.Vector3Int UnityEngine.Vector3Int::s_Zero
	Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  ___s_Zero_3;
	// UnityEngine.Vector3Int UnityEngine.Vector3Int::s_One
	Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  ___s_One_4;
	// UnityEngine.Vector3Int UnityEngine.Vector3Int::s_Up
	Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  ___s_Up_5;
	// UnityEngine.Vector3Int UnityEngine.Vector3Int::s_Down
	Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  ___s_Down_6;
	// UnityEngine.Vector3Int UnityEngine.Vector3Int::s_Left
	Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  ___s_Left_7;
	// UnityEngine.Vector3Int UnityEngine.Vector3Int::s_Right
	Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  ___s_Right_8;
	// UnityEngine.Vector3Int UnityEngine.Vector3Int::s_Forward
	Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  ___s_Forward_9;
	// UnityEngine.Vector3Int UnityEngine.Vector3Int::s_Back
	Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  ___s_Back_10;

public:
	inline static int32_t get_offset_of_s_Zero_3() { return static_cast<int32_t>(offsetof(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA_StaticFields, ___s_Zero_3)); }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  get_s_Zero_3() const { return ___s_Zero_3; }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA * get_address_of_s_Zero_3() { return &___s_Zero_3; }
	inline void set_s_Zero_3(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  value)
	{
		___s_Zero_3 = value;
	}

	inline static int32_t get_offset_of_s_One_4() { return static_cast<int32_t>(offsetof(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA_StaticFields, ___s_One_4)); }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  get_s_One_4() const { return ___s_One_4; }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA * get_address_of_s_One_4() { return &___s_One_4; }
	inline void set_s_One_4(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  value)
	{
		___s_One_4 = value;
	}

	inline static int32_t get_offset_of_s_Up_5() { return static_cast<int32_t>(offsetof(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA_StaticFields, ___s_Up_5)); }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  get_s_Up_5() const { return ___s_Up_5; }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA * get_address_of_s_Up_5() { return &___s_Up_5; }
	inline void set_s_Up_5(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  value)
	{
		___s_Up_5 = value;
	}

	inline static int32_t get_offset_of_s_Down_6() { return static_cast<int32_t>(offsetof(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA_StaticFields, ___s_Down_6)); }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  get_s_Down_6() const { return ___s_Down_6; }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA * get_address_of_s_Down_6() { return &___s_Down_6; }
	inline void set_s_Down_6(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  value)
	{
		___s_Down_6 = value;
	}

	inline static int32_t get_offset_of_s_Left_7() { return static_cast<int32_t>(offsetof(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA_StaticFields, ___s_Left_7)); }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  get_s_Left_7() const { return ___s_Left_7; }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA * get_address_of_s_Left_7() { return &___s_Left_7; }
	inline void set_s_Left_7(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  value)
	{
		___s_Left_7 = value;
	}

	inline static int32_t get_offset_of_s_Right_8() { return static_cast<int32_t>(offsetof(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA_StaticFields, ___s_Right_8)); }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  get_s_Right_8() const { return ___s_Right_8; }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA * get_address_of_s_Right_8() { return &___s_Right_8; }
	inline void set_s_Right_8(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  value)
	{
		___s_Right_8 = value;
	}

	inline static int32_t get_offset_of_s_Forward_9() { return static_cast<int32_t>(offsetof(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA_StaticFields, ___s_Forward_9)); }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  get_s_Forward_9() const { return ___s_Forward_9; }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA * get_address_of_s_Forward_9() { return &___s_Forward_9; }
	inline void set_s_Forward_9(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  value)
	{
		___s_Forward_9 = value;
	}

	inline static int32_t get_offset_of_s_Back_10() { return static_cast<int32_t>(offsetof(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA_StaticFields, ___s_Back_10)); }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  get_s_Back_10() const { return ___s_Back_10; }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA * get_address_of_s_Back_10() { return &___s_Back_10; }
	inline void set_s_Back_10(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  value)
	{
		___s_Back_10 = value;
	}
};


// System.Void
struct  Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5__padding[1];
	};

public:
};


// Unity.Mathematics.float3
struct  float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D 
{
public:
	// System.Single Unity.Mathematics.float3::x
	float ___x_0;
	// System.Single Unity.Mathematics.float3::y
	float ___y_1;
	// System.Single Unity.Mathematics.float3::z
	float ___z_2;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}

	inline static int32_t get_offset_of_z_2() { return static_cast<int32_t>(offsetof(float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D, ___z_2)); }
	inline float get_z_2() const { return ___z_2; }
	inline float* get_address_of_z_2() { return &___z_2; }
	inline void set_z_2(float value)
	{
		___z_2 = value;
	}
};

struct float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D_StaticFields
{
public:
	// Unity.Mathematics.float3 Unity.Mathematics.float3::zero
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___zero_3;

public:
	inline static int32_t get_offset_of_zero_3() { return static_cast<int32_t>(offsetof(float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D_StaticFields, ___zero_3)); }
	inline float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  get_zero_3() const { return ___zero_3; }
	inline float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * get_address_of_zero_3() { return &___zero_3; }
	inline void set_zero_3(float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  value)
	{
		___zero_3 = value;
	}
};


// System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.InternedString>
struct  Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::list
	List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * ___list_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::index
	int32_t ___index_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::version
	int32_t ___version_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  ___current_3;

public:
	inline static int32_t get_offset_of_list_0() { return static_cast<int32_t>(offsetof(Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72, ___list_0)); }
	inline List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * get_list_0() const { return ___list_0; }
	inline List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 ** get_address_of_list_0() { return &___list_0; }
	inline void set_list_0(List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * value)
	{
		___list_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___list_0), (void*)value);
	}

	inline static int32_t get_offset_of_index_1() { return static_cast<int32_t>(offsetof(Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72, ___index_1)); }
	inline int32_t get_index_1() const { return ___index_1; }
	inline int32_t* get_address_of_index_1() { return &___index_1; }
	inline void set_index_1(int32_t value)
	{
		___index_1 = value;
	}

	inline static int32_t get_offset_of_version_2() { return static_cast<int32_t>(offsetof(Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72, ___version_2)); }
	inline int32_t get_version_2() const { return ___version_2; }
	inline int32_t* get_address_of_version_2() { return &___version_2; }
	inline void set_version_2(int32_t value)
	{
		___version_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72, ___current_3)); }
	inline InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  get_current_3() const { return ___current_3; }
	inline InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  value)
	{
		___current_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___current_3))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___current_3))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}
};


// System.Linq.Enumerable/Iterator`1<UnityEngine.Color>
struct  Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76  : public RuntimeObject
{
public:
	// System.Int32 System.Linq.Enumerable/Iterator`1::threadId
	int32_t ___threadId_0;
	// System.Int32 System.Linq.Enumerable/Iterator`1::state
	int32_t ___state_1;
	// TSource System.Linq.Enumerable/Iterator`1::current
	Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  ___current_2;

public:
	inline static int32_t get_offset_of_threadId_0() { return static_cast<int32_t>(offsetof(Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76, ___threadId_0)); }
	inline int32_t get_threadId_0() const { return ___threadId_0; }
	inline int32_t* get_address_of_threadId_0() { return &___threadId_0; }
	inline void set_threadId_0(int32_t value)
	{
		___threadId_0 = value;
	}

	inline static int32_t get_offset_of_state_1() { return static_cast<int32_t>(offsetof(Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76, ___state_1)); }
	inline int32_t get_state_1() const { return ___state_1; }
	inline int32_t* get_address_of_state_1() { return &___state_1; }
	inline void set_state_1(int32_t value)
	{
		___state_1 = value;
	}

	inline static int32_t get_offset_of_current_2() { return static_cast<int32_t>(offsetof(Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76, ___current_2)); }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  get_current_2() const { return ___current_2; }
	inline Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659 * get_address_of_current_2() { return &___current_2; }
	inline void set_current_2(Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  value)
	{
		___current_2 = value;
	}
};


// System.Linq.Enumerable/Iterator`1<UnityEngine.InputSystem.Utilities.InternedString>
struct  Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94  : public RuntimeObject
{
public:
	// System.Int32 System.Linq.Enumerable/Iterator`1::threadId
	int32_t ___threadId_0;
	// System.Int32 System.Linq.Enumerable/Iterator`1::state
	int32_t ___state_1;
	// TSource System.Linq.Enumerable/Iterator`1::current
	InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  ___current_2;

public:
	inline static int32_t get_offset_of_threadId_0() { return static_cast<int32_t>(offsetof(Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94, ___threadId_0)); }
	inline int32_t get_threadId_0() const { return ___threadId_0; }
	inline int32_t* get_address_of_threadId_0() { return &___threadId_0; }
	inline void set_threadId_0(int32_t value)
	{
		___threadId_0 = value;
	}

	inline static int32_t get_offset_of_state_1() { return static_cast<int32_t>(offsetof(Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94, ___state_1)); }
	inline int32_t get_state_1() const { return ___state_1; }
	inline int32_t* get_address_of_state_1() { return &___state_1; }
	inline void set_state_1(int32_t value)
	{
		___state_1 = value;
	}

	inline static int32_t get_offset_of_current_2() { return static_cast<int32_t>(offsetof(Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94, ___current_2)); }
	inline InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  get_current_2() const { return ___current_2; }
	inline InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D * get_address_of_current_2() { return &___current_2; }
	inline void set_current_2(InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  value)
	{
		___current_2 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___current_2))->___m_StringOriginalCase_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___current_2))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}
};


// System.Linq.Enumerable/Iterator`1<UnityEngine.Vector3>
struct  Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF  : public RuntimeObject
{
public:
	// System.Int32 System.Linq.Enumerable/Iterator`1::threadId
	int32_t ___threadId_0;
	// System.Int32 System.Linq.Enumerable/Iterator`1::state
	int32_t ___state_1;
	// TSource System.Linq.Enumerable/Iterator`1::current
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___current_2;

public:
	inline static int32_t get_offset_of_threadId_0() { return static_cast<int32_t>(offsetof(Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF, ___threadId_0)); }
	inline int32_t get_threadId_0() const { return ___threadId_0; }
	inline int32_t* get_address_of_threadId_0() { return &___threadId_0; }
	inline void set_threadId_0(int32_t value)
	{
		___threadId_0 = value;
	}

	inline static int32_t get_offset_of_state_1() { return static_cast<int32_t>(offsetof(Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF, ___state_1)); }
	inline int32_t get_state_1() const { return ___state_1; }
	inline int32_t* get_address_of_state_1() { return &___state_1; }
	inline void set_state_1(int32_t value)
	{
		___state_1 = value;
	}

	inline static int32_t get_offset_of_current_2() { return static_cast<int32_t>(offsetof(Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF, ___current_2)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_current_2() const { return ___current_2; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_current_2() { return &___current_2; }
	inline void set_current_2(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___current_2 = value;
	}
};


// System.Linq.Enumerable/Iterator`1<UnityEngine.Vector3Int>
struct  Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1  : public RuntimeObject
{
public:
	// System.Int32 System.Linq.Enumerable/Iterator`1::threadId
	int32_t ___threadId_0;
	// System.Int32 System.Linq.Enumerable/Iterator`1::state
	int32_t ___state_1;
	// TSource System.Linq.Enumerable/Iterator`1::current
	Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  ___current_2;

public:
	inline static int32_t get_offset_of_threadId_0() { return static_cast<int32_t>(offsetof(Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1, ___threadId_0)); }
	inline int32_t get_threadId_0() const { return ___threadId_0; }
	inline int32_t* get_address_of_threadId_0() { return &___threadId_0; }
	inline void set_threadId_0(int32_t value)
	{
		___threadId_0 = value;
	}

	inline static int32_t get_offset_of_state_1() { return static_cast<int32_t>(offsetof(Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1, ___state_1)); }
	inline int32_t get_state_1() const { return ___state_1; }
	inline int32_t* get_address_of_state_1() { return &___state_1; }
	inline void set_state_1(int32_t value)
	{
		___state_1 = value;
	}

	inline static int32_t get_offset_of_current_2() { return static_cast<int32_t>(offsetof(Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1, ___current_2)); }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  get_current_2() const { return ___current_2; }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA * get_address_of_current_2() { return &___current_2; }
	inline void set_current_2(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  value)
	{
		___current_2 = value;
	}
};


// System.Linq.Enumerable/Iterator`1<Unity.Mathematics.float3>
struct  Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A  : public RuntimeObject
{
public:
	// System.Int32 System.Linq.Enumerable/Iterator`1::threadId
	int32_t ___threadId_0;
	// System.Int32 System.Linq.Enumerable/Iterator`1::state
	int32_t ___state_1;
	// TSource System.Linq.Enumerable/Iterator`1::current
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___current_2;

public:
	inline static int32_t get_offset_of_threadId_0() { return static_cast<int32_t>(offsetof(Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A, ___threadId_0)); }
	inline int32_t get_threadId_0() const { return ___threadId_0; }
	inline int32_t* get_address_of_threadId_0() { return &___threadId_0; }
	inline void set_threadId_0(int32_t value)
	{
		___threadId_0 = value;
	}

	inline static int32_t get_offset_of_state_1() { return static_cast<int32_t>(offsetof(Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A, ___state_1)); }
	inline int32_t get_state_1() const { return ___state_1; }
	inline int32_t* get_address_of_state_1() { return &___state_1; }
	inline void set_state_1(int32_t value)
	{
		___state_1 = value;
	}

	inline static int32_t get_offset_of_current_2() { return static_cast<int32_t>(offsetof(Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A, ___current_2)); }
	inline float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  get_current_2() const { return ___current_2; }
	inline float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * get_address_of_current_2() { return &___current_2; }
	inline void set_current_2(float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  value)
	{
		___current_2 = value;
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<System.Int32,System.Int32>
struct  WhereSelectListIterator_2_t4CC3FE3A35610DC6F761EE7DB863B845957AD325  : public Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t4CC3FE3A35610DC6F761EE7DB863B845957AD325, ___source_3)); }
	inline List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 * get_source_3() const { return ___source_3; }
	inline List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t4CC3FE3A35610DC6F761EE7DB863B845957AD325, ___predicate_4)); }
	inline Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t4CC3FE3A35610DC6F761EE7DB863B845957AD325, ___selector_5)); }
	inline Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA * get_selector_5() const { return ___selector_5; }
	inline Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t4CC3FE3A35610DC6F761EE7DB863B845957AD325, ___enumerator_6)); }
	inline Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<System.Object,System.Object>
struct  WhereSelectListIterator_2_t85B78DFF0573BC95A62C79D6088FA39DFEBE1AF2  : public Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t85B78DFF0573BC95A62C79D6088FA39DFEBE1AF2, ___source_3)); }
	inline List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * get_source_3() const { return ___source_3; }
	inline List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t85B78DFF0573BC95A62C79D6088FA39DFEBE1AF2, ___predicate_4)); }
	inline Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t85B78DFF0573BC95A62C79D6088FA39DFEBE1AF2, ___selector_5)); }
	inline Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 * get_selector_5() const { return ___selector_5; }
	inline Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t85B78DFF0573BC95A62C79D6088FA39DFEBE1AF2, ___enumerator_6)); }
	inline Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___current_3), (void*)NULL);
		#endif
	}
};


// UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex
struct  ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 
{
public:
	// UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.Vec3 UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex::Position
	Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1  ___Position_0;
	// System.Object UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex::Data
	RuntimeObject * ___Data_1;

public:
	inline static int32_t get_offset_of_Position_0() { return static_cast<int32_t>(offsetof(ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536, ___Position_0)); }
	inline Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1  get_Position_0() const { return ___Position_0; }
	inline Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1 * get_address_of_Position_0() { return &___Position_0; }
	inline void set_Position_0(Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1  value)
	{
		___Position_0 = value;
	}

	inline static int32_t get_offset_of_Data_1() { return static_cast<int32_t>(offsetof(ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536, ___Data_1)); }
	inline RuntimeObject * get_Data_1() const { return ___Data_1; }
	inline RuntimeObject ** get_address_of_Data_1() { return &___Data_1; }
	inline void set_Data_1(RuntimeObject * value)
	{
		___Data_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Data_1), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex
struct ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536_marshaled_pinvoke
{
	Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1  ___Position_0;
	Il2CppIUnknown* ___Data_1;
};
// Native definition for COM marshalling of UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex
struct ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536_marshaled_com
{
	Vec3_tDD913B31171F6A37E61E4625FEA6C7901A6B1BC1  ___Position_0;
	Il2CppIUnknown* ___Data_1;
};

// System.Delegate
struct  Delegate_t  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::extra_arg
	intptr_t ___extra_arg_5;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_6;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_7;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_8;
	// System.DelegateData System.Delegate::data
	DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 * ___data_9;
	// System.Boolean System.Delegate::method_is_virtual
	bool ___method_is_virtual_10;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_target_2), (void*)value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_extra_arg_5() { return static_cast<int32_t>(offsetof(Delegate_t, ___extra_arg_5)); }
	inline intptr_t get_extra_arg_5() const { return ___extra_arg_5; }
	inline intptr_t* get_address_of_extra_arg_5() { return &___extra_arg_5; }
	inline void set_extra_arg_5(intptr_t value)
	{
		___extra_arg_5 = value;
	}

	inline static int32_t get_offset_of_method_code_6() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_code_6)); }
	inline intptr_t get_method_code_6() const { return ___method_code_6; }
	inline intptr_t* get_address_of_method_code_6() { return &___method_code_6; }
	inline void set_method_code_6(intptr_t value)
	{
		___method_code_6 = value;
	}

	inline static int32_t get_offset_of_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_info_7)); }
	inline MethodInfo_t * get_method_info_7() const { return ___method_info_7; }
	inline MethodInfo_t ** get_address_of_method_info_7() { return &___method_info_7; }
	inline void set_method_info_7(MethodInfo_t * value)
	{
		___method_info_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___method_info_7), (void*)value);
	}

	inline static int32_t get_offset_of_original_method_info_8() { return static_cast<int32_t>(offsetof(Delegate_t, ___original_method_info_8)); }
	inline MethodInfo_t * get_original_method_info_8() const { return ___original_method_info_8; }
	inline MethodInfo_t ** get_address_of_original_method_info_8() { return &___original_method_info_8; }
	inline void set_original_method_info_8(MethodInfo_t * value)
	{
		___original_method_info_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___original_method_info_8), (void*)value);
	}

	inline static int32_t get_offset_of_data_9() { return static_cast<int32_t>(offsetof(Delegate_t, ___data_9)); }
	inline DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 * get_data_9() const { return ___data_9; }
	inline DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 ** get_address_of_data_9() { return &___data_9; }
	inline void set_data_9(DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 * value)
	{
		___data_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___data_9), (void*)value);
	}

	inline static int32_t get_offset_of_method_is_virtual_10() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_is_virtual_10)); }
	inline bool get_method_is_virtual_10() const { return ___method_is_virtual_10; }
	inline bool* get_address_of_method_is_virtual_10() { return &___method_is_virtual_10; }
	inline void set_method_is_virtual_10(bool value)
	{
		___method_is_virtual_10 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Delegate
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 * ___data_9;
	int32_t ___method_is_virtual_10;
};
// Native definition for COM marshalling of System.Delegate
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 * ___data_9;
	int32_t ___method_is_virtual_10;
};

// UnityEngine.InputSystem.Utilities.NameAndParameters
struct  NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344 
{
public:
	// System.String UnityEngine.InputSystem.Utilities.NameAndParameters::<name>k__BackingField
	String_t* ___U3CnameU3Ek__BackingField_0;
	// UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Utilities.NamedValue> UnityEngine.InputSystem.Utilities.NameAndParameters::<parameters>k__BackingField
	ReadOnlyArray_1_t0E4793FE3B663B5A6022E32DA0988B6C435F7AB2  ___U3CparametersU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CnameU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344, ___U3CnameU3Ek__BackingField_0)); }
	inline String_t* get_U3CnameU3Ek__BackingField_0() const { return ___U3CnameU3Ek__BackingField_0; }
	inline String_t** get_address_of_U3CnameU3Ek__BackingField_0() { return &___U3CnameU3Ek__BackingField_0; }
	inline void set_U3CnameU3Ek__BackingField_0(String_t* value)
	{
		___U3CnameU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CnameU3Ek__BackingField_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CparametersU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344, ___U3CparametersU3Ek__BackingField_1)); }
	inline ReadOnlyArray_1_t0E4793FE3B663B5A6022E32DA0988B6C435F7AB2  get_U3CparametersU3Ek__BackingField_1() const { return ___U3CparametersU3Ek__BackingField_1; }
	inline ReadOnlyArray_1_t0E4793FE3B663B5A6022E32DA0988B6C435F7AB2 * get_address_of_U3CparametersU3Ek__BackingField_1() { return &___U3CparametersU3Ek__BackingField_1; }
	inline void set_U3CparametersU3Ek__BackingField_1(ReadOnlyArray_1_t0E4793FE3B663B5A6022E32DA0988B6C435F7AB2  value)
	{
		___U3CparametersU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CparametersU3Ek__BackingField_1))->___m_Array_0), (void*)NULL);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Utilities.NameAndParameters
struct NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344_marshaled_pinvoke
{
	char* ___U3CnameU3Ek__BackingField_0;
	ReadOnlyArray_1_t0E4793FE3B663B5A6022E32DA0988B6C435F7AB2  ___U3CparametersU3Ek__BackingField_1;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Utilities.NameAndParameters
struct NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344_marshaled_com
{
	Il2CppChar* ___U3CnameU3Ek__BackingField_0;
	ReadOnlyArray_1_t0E4793FE3B663B5A6022E32DA0988B6C435F7AB2  ___U3CparametersU3Ek__BackingField_1;
};

// System.TypeCode
struct  TypeCode_tCB39BAB5CFB7A1E0BCB521413E3C46B81C31AA7C 
{
public:
	// System.Int32 System.TypeCode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(TypeCode_tCB39BAB5CFB7A1E0BCB521413E3C46B81C31AA7C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.Tilemaps.GridInformation/GridInformationKey
struct  GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941 
{
public:
	// UnityEngine.Vector3Int UnityEngine.Tilemaps.GridInformation/GridInformationKey::position
	Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  ___position_0;
	// System.String UnityEngine.Tilemaps.GridInformation/GridInformationKey::name
	String_t* ___name_1;

public:
	inline static int32_t get_offset_of_position_0() { return static_cast<int32_t>(offsetof(GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941, ___position_0)); }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  get_position_0() const { return ___position_0; }
	inline Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA * get_address_of_position_0() { return &___position_0; }
	inline void set_position_0(Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  value)
	{
		___position_0 = value;
	}

	inline static int32_t get_offset_of_name_1() { return static_cast<int32_t>(offsetof(GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941, ___name_1)); }
	inline String_t* get_name_1() const { return ___name_1; }
	inline String_t** get_address_of_name_1() { return &___name_1; }
	inline void set_name_1(String_t* value)
	{
		___name_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___name_1), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.Tilemaps.GridInformation/GridInformationKey
struct GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941_marshaled_pinvoke
{
	Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  ___position_0;
	char* ___name_1;
};
// Native definition for COM marshalling of UnityEngine.Tilemaps.GridInformation/GridInformationKey
struct GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941_marshaled_com
{
	Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  ___position_0;
	Il2CppChar* ___name_1;
};

// UnityEngine.InputSystem.Utilities.JsonParser/JsonString
struct  JsonString_tE3B4CC7543FEB24BCB9662EA44ACE137F9203F0E 
{
public:
	// UnityEngine.InputSystem.Utilities.Substring UnityEngine.InputSystem.Utilities.JsonParser/JsonString::text
	Substring_t1B63EC71C55D91EDAFFBDBD246A839EC23B88A2B  ___text_0;
	// System.Boolean UnityEngine.InputSystem.Utilities.JsonParser/JsonString::hasEscapes
	bool ___hasEscapes_1;

public:
	inline static int32_t get_offset_of_text_0() { return static_cast<int32_t>(offsetof(JsonString_tE3B4CC7543FEB24BCB9662EA44ACE137F9203F0E, ___text_0)); }
	inline Substring_t1B63EC71C55D91EDAFFBDBD246A839EC23B88A2B  get_text_0() const { return ___text_0; }
	inline Substring_t1B63EC71C55D91EDAFFBDBD246A839EC23B88A2B * get_address_of_text_0() { return &___text_0; }
	inline void set_text_0(Substring_t1B63EC71C55D91EDAFFBDBD246A839EC23B88A2B  value)
	{
		___text_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___text_0))->___m_String_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_hasEscapes_1() { return static_cast<int32_t>(offsetof(JsonString_tE3B4CC7543FEB24BCB9662EA44ACE137F9203F0E, ___hasEscapes_1)); }
	inline bool get_hasEscapes_1() const { return ___hasEscapes_1; }
	inline bool* get_address_of_hasEscapes_1() { return &___hasEscapes_1; }
	inline void set_hasEscapes_1(bool value)
	{
		___hasEscapes_1 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Utilities.JsonParser/JsonString
struct JsonString_tE3B4CC7543FEB24BCB9662EA44ACE137F9203F0E_marshaled_pinvoke
{
	Substring_t1B63EC71C55D91EDAFFBDBD246A839EC23B88A2B_marshaled_pinvoke ___text_0;
	int32_t ___hasEscapes_1;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Utilities.JsonParser/JsonString
struct JsonString_tE3B4CC7543FEB24BCB9662EA44ACE137F9203F0E_marshaled_com
{
	Substring_t1B63EC71C55D91EDAFFBDBD246A839EC23B88A2B_marshaled_com ___text_0;
	int32_t ___hasEscapes_1;
};

// UnityEngine.InputSystem.Utilities.JsonParser/JsonValueType
struct  JsonValueType_t11367DC86C6B6643B98975A13CBC32CE44342B67 
{
public:
	// System.Int32 UnityEngine.InputSystem.Utilities.JsonParser/JsonValueType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(JsonValueType_t11367DC86C6B6643B98975A13CBC32CE44342B67, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Collections.Generic.List`1/Enumerator<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex>
struct  Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::list
	List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * ___list_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::index
	int32_t ___index_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::version
	int32_t ___version_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  ___current_3;

public:
	inline static int32_t get_offset_of_list_0() { return static_cast<int32_t>(offsetof(Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11, ___list_0)); }
	inline List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * get_list_0() const { return ___list_0; }
	inline List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C ** get_address_of_list_0() { return &___list_0; }
	inline void set_list_0(List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * value)
	{
		___list_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___list_0), (void*)value);
	}

	inline static int32_t get_offset_of_index_1() { return static_cast<int32_t>(offsetof(Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11, ___index_1)); }
	inline int32_t get_index_1() const { return ___index_1; }
	inline int32_t* get_address_of_index_1() { return &___index_1; }
	inline void set_index_1(int32_t value)
	{
		___index_1 = value;
	}

	inline static int32_t get_offset_of_version_2() { return static_cast<int32_t>(offsetof(Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11, ___version_2)); }
	inline int32_t get_version_2() const { return ___version_2; }
	inline int32_t* get_address_of_version_2() { return &___version_2; }
	inline void set_version_2(int32_t value)
	{
		___version_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11, ___current_3)); }
	inline ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  get_current_3() const { return ___current_3; }
	inline ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  value)
	{
		___current_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___current_3))->___Data_1), (void*)NULL);
	}
};


// System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.NameAndParameters>
struct  Enumerator_t3F22A2E619D662922F996C766D960AF285909004 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::list
	List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * ___list_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::index
	int32_t ___index_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::version
	int32_t ___version_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  ___current_3;

public:
	inline static int32_t get_offset_of_list_0() { return static_cast<int32_t>(offsetof(Enumerator_t3F22A2E619D662922F996C766D960AF285909004, ___list_0)); }
	inline List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * get_list_0() const { return ___list_0; }
	inline List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D ** get_address_of_list_0() { return &___list_0; }
	inline void set_list_0(List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * value)
	{
		___list_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___list_0), (void*)value);
	}

	inline static int32_t get_offset_of_index_1() { return static_cast<int32_t>(offsetof(Enumerator_t3F22A2E619D662922F996C766D960AF285909004, ___index_1)); }
	inline int32_t get_index_1() const { return ___index_1; }
	inline int32_t* get_address_of_index_1() { return &___index_1; }
	inline void set_index_1(int32_t value)
	{
		___index_1 = value;
	}

	inline static int32_t get_offset_of_version_2() { return static_cast<int32_t>(offsetof(Enumerator_t3F22A2E619D662922F996C766D960AF285909004, ___version_2)); }
	inline int32_t get_version_2() const { return ___version_2; }
	inline int32_t* get_address_of_version_2() { return &___version_2; }
	inline void set_version_2(int32_t value)
	{
		___version_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t3F22A2E619D662922F996C766D960AF285909004, ___current_3)); }
	inline NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  get_current_3() const { return ___current_3; }
	inline NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344 * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  value)
	{
		___current_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___current_3))->___U3CnameU3Ek__BackingField_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___current_3))->___U3CparametersU3Ek__BackingField_1))->___m_Array_0), (void*)NULL);
		#endif
	}
};


// System.Collections.Generic.List`1/Enumerator<UnityEngine.Tilemaps.GridInformation/GridInformationKey>
struct  Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::list
	List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 * ___list_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::index
	int32_t ___index_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::version
	int32_t ___version_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  ___current_3;

public:
	inline static int32_t get_offset_of_list_0() { return static_cast<int32_t>(offsetof(Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502, ___list_0)); }
	inline List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 * get_list_0() const { return ___list_0; }
	inline List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 ** get_address_of_list_0() { return &___list_0; }
	inline void set_list_0(List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 * value)
	{
		___list_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___list_0), (void*)value);
	}

	inline static int32_t get_offset_of_index_1() { return static_cast<int32_t>(offsetof(Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502, ___index_1)); }
	inline int32_t get_index_1() const { return ___index_1; }
	inline int32_t* get_address_of_index_1() { return &___index_1; }
	inline void set_index_1(int32_t value)
	{
		___index_1 = value;
	}

	inline static int32_t get_offset_of_version_2() { return static_cast<int32_t>(offsetof(Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502, ___version_2)); }
	inline int32_t get_version_2() const { return ___version_2; }
	inline int32_t* get_address_of_version_2() { return &___version_2; }
	inline void set_version_2(int32_t value)
	{
		___version_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502, ___current_3)); }
	inline GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  get_current_3() const { return ___current_3; }
	inline GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941 * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  value)
	{
		___current_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___current_3))->___name_1), (void*)NULL);
	}
};


// System.Linq.Enumerable/WhereEnumerableIterator`1<UnityEngine.Color>
struct  WhereEnumerableIterator_1_tEDD9A2C48D1FE8BE0706121F2B6C8A796196FFF2  : public Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76
{
public:
	// System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable/WhereEnumerableIterator`1::source
	RuntimeObject* ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereEnumerableIterator`1::predicate
	Func_2_t3985FFDAB0D05F8E97E8EA849D5A24F16EFFC4FD * ___predicate_4;
	// System.Collections.Generic.IEnumerator`1<TSource> System.Linq.Enumerable/WhereEnumerableIterator`1::enumerator
	RuntimeObject* ___enumerator_5;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_tEDD9A2C48D1FE8BE0706121F2B6C8A796196FFF2, ___source_3)); }
	inline RuntimeObject* get_source_3() const { return ___source_3; }
	inline RuntimeObject** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(RuntimeObject* value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_tEDD9A2C48D1FE8BE0706121F2B6C8A796196FFF2, ___predicate_4)); }
	inline Func_2_t3985FFDAB0D05F8E97E8EA849D5A24F16EFFC4FD * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t3985FFDAB0D05F8E97E8EA849D5A24F16EFFC4FD ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t3985FFDAB0D05F8E97E8EA849D5A24F16EFFC4FD * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_5() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_tEDD9A2C48D1FE8BE0706121F2B6C8A796196FFF2, ___enumerator_5)); }
	inline RuntimeObject* get_enumerator_5() const { return ___enumerator_5; }
	inline RuntimeObject** get_address_of_enumerator_5() { return &___enumerator_5; }
	inline void set_enumerator_5(RuntimeObject* value)
	{
		___enumerator_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumerator_5), (void*)value);
	}
};


// System.Linq.Enumerable/WhereEnumerableIterator`1<UnityEngine.InputSystem.Utilities.InternedString>
struct  WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59  : public Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94
{
public:
	// System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable/WhereEnumerableIterator`1::source
	RuntimeObject* ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereEnumerableIterator`1::predicate
	Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * ___predicate_4;
	// System.Collections.Generic.IEnumerator`1<TSource> System.Linq.Enumerable/WhereEnumerableIterator`1::enumerator
	RuntimeObject* ___enumerator_5;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59, ___source_3)); }
	inline RuntimeObject* get_source_3() const { return ___source_3; }
	inline RuntimeObject** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(RuntimeObject* value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59, ___predicate_4)); }
	inline Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_5() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59, ___enumerator_5)); }
	inline RuntimeObject* get_enumerator_5() const { return ___enumerator_5; }
	inline RuntimeObject** get_address_of_enumerator_5() { return &___enumerator_5; }
	inline void set_enumerator_5(RuntimeObject* value)
	{
		___enumerator_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumerator_5), (void*)value);
	}
};


// System.Linq.Enumerable/WhereEnumerableIterator`1<UnityEngine.Vector3>
struct  WhereEnumerableIterator_1_t0E01F06572EA26BE9E79530811037753CF6B3BF8  : public Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF
{
public:
	// System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable/WhereEnumerableIterator`1::source
	RuntimeObject* ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereEnumerableIterator`1::predicate
	Func_2_t3041FD3183D19FE8416AE2E43A6398B2C06B7269 * ___predicate_4;
	// System.Collections.Generic.IEnumerator`1<TSource> System.Linq.Enumerable/WhereEnumerableIterator`1::enumerator
	RuntimeObject* ___enumerator_5;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_t0E01F06572EA26BE9E79530811037753CF6B3BF8, ___source_3)); }
	inline RuntimeObject* get_source_3() const { return ___source_3; }
	inline RuntimeObject** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(RuntimeObject* value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_t0E01F06572EA26BE9E79530811037753CF6B3BF8, ___predicate_4)); }
	inline Func_2_t3041FD3183D19FE8416AE2E43A6398B2C06B7269 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t3041FD3183D19FE8416AE2E43A6398B2C06B7269 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t3041FD3183D19FE8416AE2E43A6398B2C06B7269 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_5() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_t0E01F06572EA26BE9E79530811037753CF6B3BF8, ___enumerator_5)); }
	inline RuntimeObject* get_enumerator_5() const { return ___enumerator_5; }
	inline RuntimeObject** get_address_of_enumerator_5() { return &___enumerator_5; }
	inline void set_enumerator_5(RuntimeObject* value)
	{
		___enumerator_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumerator_5), (void*)value);
	}
};


// System.Linq.Enumerable/WhereEnumerableIterator`1<UnityEngine.Vector3Int>
struct  WhereEnumerableIterator_1_tD2CF2E617E3FFF17EDE787C942514D3A3E76A8A2  : public Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1
{
public:
	// System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable/WhereEnumerableIterator`1::source
	RuntimeObject* ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereEnumerableIterator`1::predicate
	Func_2_tB3AD6A340F9ED708E8459C7912C86F7504161867 * ___predicate_4;
	// System.Collections.Generic.IEnumerator`1<TSource> System.Linq.Enumerable/WhereEnumerableIterator`1::enumerator
	RuntimeObject* ___enumerator_5;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_tD2CF2E617E3FFF17EDE787C942514D3A3E76A8A2, ___source_3)); }
	inline RuntimeObject* get_source_3() const { return ___source_3; }
	inline RuntimeObject** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(RuntimeObject* value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_tD2CF2E617E3FFF17EDE787C942514D3A3E76A8A2, ___predicate_4)); }
	inline Func_2_tB3AD6A340F9ED708E8459C7912C86F7504161867 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_tB3AD6A340F9ED708E8459C7912C86F7504161867 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_tB3AD6A340F9ED708E8459C7912C86F7504161867 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_5() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_tD2CF2E617E3FFF17EDE787C942514D3A3E76A8A2, ___enumerator_5)); }
	inline RuntimeObject* get_enumerator_5() const { return ___enumerator_5; }
	inline RuntimeObject** get_address_of_enumerator_5() { return &___enumerator_5; }
	inline void set_enumerator_5(RuntimeObject* value)
	{
		___enumerator_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumerator_5), (void*)value);
	}
};


// System.Linq.Enumerable/WhereEnumerableIterator`1<Unity.Mathematics.float3>
struct  WhereEnumerableIterator_1_t3450D7A9CB5BBEE711BB0ADD51AC530BD969D13F  : public Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A
{
public:
	// System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable/WhereEnumerableIterator`1::source
	RuntimeObject* ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereEnumerableIterator`1::predicate
	Func_2_t43355C55B1BBA93635101F6AF90867509812D7E5 * ___predicate_4;
	// System.Collections.Generic.IEnumerator`1<TSource> System.Linq.Enumerable/WhereEnumerableIterator`1::enumerator
	RuntimeObject* ___enumerator_5;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_t3450D7A9CB5BBEE711BB0ADD51AC530BD969D13F, ___source_3)); }
	inline RuntimeObject* get_source_3() const { return ___source_3; }
	inline RuntimeObject** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(RuntimeObject* value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_t3450D7A9CB5BBEE711BB0ADD51AC530BD969D13F, ___predicate_4)); }
	inline Func_2_t43355C55B1BBA93635101F6AF90867509812D7E5 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t43355C55B1BBA93635101F6AF90867509812D7E5 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t43355C55B1BBA93635101F6AF90867509812D7E5 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_5() { return static_cast<int32_t>(offsetof(WhereEnumerableIterator_1_t3450D7A9CB5BBEE711BB0ADD51AC530BD969D13F, ___enumerator_5)); }
	inline RuntimeObject* get_enumerator_5() const { return ___enumerator_5; }
	inline RuntimeObject** get_address_of_enumerator_5() { return &___enumerator_5; }
	inline void set_enumerator_5(RuntimeObject* value)
	{
		___enumerator_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumerator_5), (void*)value);
	}
};


// System.Linq.Enumerable/WhereSelectEnumerableIterator`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>
struct  WhereSelectEnumerableIterator_2_t2F210EE4B2CBE5E1F6A887A375170AD9D3066C6C  : public Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94
{
public:
	// System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::source
	RuntimeObject* ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::predicate
	Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::selector
	Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 * ___selector_5;
	// System.Collections.Generic.IEnumerator`1<TSource> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::enumerator
	RuntimeObject* ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_t2F210EE4B2CBE5E1F6A887A375170AD9D3066C6C, ___source_3)); }
	inline RuntimeObject* get_source_3() const { return ___source_3; }
	inline RuntimeObject** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(RuntimeObject* value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_t2F210EE4B2CBE5E1F6A887A375170AD9D3066C6C, ___predicate_4)); }
	inline Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_t2F210EE4B2CBE5E1F6A887A375170AD9D3066C6C, ___selector_5)); }
	inline Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 * get_selector_5() const { return ___selector_5; }
	inline Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_t2F210EE4B2CBE5E1F6A887A375170AD9D3066C6C, ___enumerator_6)); }
	inline RuntimeObject* get_enumerator_6() const { return ___enumerator_6; }
	inline RuntimeObject** get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(RuntimeObject* value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumerator_6), (void*)value);
	}
};


// System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,UnityEngine.Vector3Int>
struct  WhereSelectEnumerableIterator_2_tE7217C6271607DE91640E1C70700D8EAC5C79632  : public Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1
{
public:
	// System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::source
	RuntimeObject* ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::predicate
	Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::selector
	Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A * ___selector_5;
	// System.Collections.Generic.IEnumerator`1<TSource> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::enumerator
	RuntimeObject* ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_tE7217C6271607DE91640E1C70700D8EAC5C79632, ___source_3)); }
	inline RuntimeObject* get_source_3() const { return ___source_3; }
	inline RuntimeObject** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(RuntimeObject* value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_tE7217C6271607DE91640E1C70700D8EAC5C79632, ___predicate_4)); }
	inline Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_tE7217C6271607DE91640E1C70700D8EAC5C79632, ___selector_5)); }
	inline Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A * get_selector_5() const { return ___selector_5; }
	inline Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_tE7217C6271607DE91640E1C70700D8EAC5C79632, ___enumerator_6)); }
	inline RuntimeObject* get_enumerator_6() const { return ___enumerator_6; }
	inline RuntimeObject** get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(RuntimeObject* value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumerator_6), (void*)value);
	}
};


// System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,UnityEngine.InputSystem.Utilities.InternedString>
struct  WhereSelectEnumerableIterator_2_t2EF803FE6198D12622AB2AC13CC544D3382A753D  : public Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94
{
public:
	// System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::source
	RuntimeObject* ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::predicate
	Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::selector
	Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C * ___selector_5;
	// System.Collections.Generic.IEnumerator`1<TSource> System.Linq.Enumerable/WhereSelectEnumerableIterator`2::enumerator
	RuntimeObject* ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_t2EF803FE6198D12622AB2AC13CC544D3382A753D, ___source_3)); }
	inline RuntimeObject* get_source_3() const { return ___source_3; }
	inline RuntimeObject** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(RuntimeObject* value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_t2EF803FE6198D12622AB2AC13CC544D3382A753D, ___predicate_4)); }
	inline Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_t2EF803FE6198D12622AB2AC13CC544D3382A753D, ___selector_5)); }
	inline Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C * get_selector_5() const { return ___selector_5; }
	inline Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectEnumerableIterator_2_t2EF803FE6198D12622AB2AC13CC544D3382A753D, ___enumerator_6)); }
	inline RuntimeObject* get_enumerator_6() const { return ___enumerator_6; }
	inline RuntimeObject** get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(RuntimeObject* value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumerator_6), (void*)value);
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString>
struct  WhereSelectListIterator_2_tAEAF0881ED609445F03C4E5691A27493B13F5D3E  : public Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_tEE37498C122C43E9F0D581326B5464292A55F235 * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tAEAF0881ED609445F03C4E5691A27493B13F5D3E, ___source_3)); }
	inline List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * get_source_3() const { return ___source_3; }
	inline List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tAEAF0881ED609445F03C4E5691A27493B13F5D3E, ___predicate_4)); }
	inline Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tAEAF0881ED609445F03C4E5691A27493B13F5D3E, ___selector_5)); }
	inline Func_2_tEE37498C122C43E9F0D581326B5464292A55F235 * get_selector_5() const { return ___selector_5; }
	inline Func_2_tEE37498C122C43E9F0D581326B5464292A55F235 ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_tEE37498C122C43E9F0D581326B5464292A55F235 * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tAEAF0881ED609445F03C4E5691A27493B13F5D3E, ___enumerator_6)); }
	inline Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___m_StringOriginalCase_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.InternedString,System.Object>
struct  WhereSelectListIterator_2_t65F4408766820863D04329D21B3BDFB6FD5625B8  : public Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720 * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t65F4408766820863D04329D21B3BDFB6FD5625B8, ___source_3)); }
	inline List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * get_source_3() const { return ___source_3; }
	inline List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t65F4408766820863D04329D21B3BDFB6FD5625B8, ___predicate_4)); }
	inline Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t65F4408766820863D04329D21B3BDFB6FD5625B8, ___selector_5)); }
	inline Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720 * get_selector_5() const { return ___selector_5; }
	inline Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720 ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720 * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t65F4408766820863D04329D21B3BDFB6FD5625B8, ___enumerator_6)); }
	inline Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___m_StringOriginalCase_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___m_StringLowerCase_1), (void*)NULL);
		#endif
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>
struct  WhereSelectListIterator_2_t8E02B4908AA9B882EBD941ADBA2D45EAEA8BF72B  : public Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8E02B4908AA9B882EBD941ADBA2D45EAEA8BF72B, ___source_3)); }
	inline List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * get_source_3() const { return ___source_3; }
	inline List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8E02B4908AA9B882EBD941ADBA2D45EAEA8BF72B, ___predicate_4)); }
	inline Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8E02B4908AA9B882EBD941ADBA2D45EAEA8BF72B, ___selector_5)); }
	inline Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 * get_selector_5() const { return ___selector_5; }
	inline Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8E02B4908AA9B882EBD941ADBA2D45EAEA8BF72B, ___enumerator_6)); }
	inline Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___current_3), (void*)NULL);
		#endif
	}
};


// System.MulticastDelegate
struct  MulticastDelegate_t  : public Delegate_t
{
public:
	// System.Delegate[] System.MulticastDelegate::delegates
	DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8* ___delegates_11;

public:
	inline static int32_t get_offset_of_delegates_11() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___delegates_11)); }
	inline DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8* get_delegates_11() const { return ___delegates_11; }
	inline DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8** get_address_of_delegates_11() { return &___delegates_11; }
	inline void set_delegates_11(DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8* value)
	{
		___delegates_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___delegates_11), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates_11;
};
// Native definition for COM marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates_11;
};

// UnityEngine.InputSystem.Utilities.PrimitiveValue
struct  PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8 
{
public:
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			// System.TypeCode UnityEngine.InputSystem.Utilities.PrimitiveValue::m_Type
			int32_t ___m_Type_0;
		};
		#pragma pack(pop, tp)
		struct
		{
			int32_t ___m_Type_0_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_BoolValue_1_OffsetPadding[4];
			// System.Boolean UnityEngine.InputSystem.Utilities.PrimitiveValue::m_BoolValue
			bool ___m_BoolValue_1;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_BoolValue_1_OffsetPadding_forAlignmentOnly[4];
			bool ___m_BoolValue_1_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_CharValue_2_OffsetPadding[4];
			// System.Char UnityEngine.InputSystem.Utilities.PrimitiveValue::m_CharValue
			Il2CppChar ___m_CharValue_2;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_CharValue_2_OffsetPadding_forAlignmentOnly[4];
			Il2CppChar ___m_CharValue_2_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ByteValue_3_OffsetPadding[4];
			// System.Byte UnityEngine.InputSystem.Utilities.PrimitiveValue::m_ByteValue
			uint8_t ___m_ByteValue_3;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ByteValue_3_OffsetPadding_forAlignmentOnly[4];
			uint8_t ___m_ByteValue_3_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_SByteValue_4_OffsetPadding[4];
			// System.SByte UnityEngine.InputSystem.Utilities.PrimitiveValue::m_SByteValue
			int8_t ___m_SByteValue_4;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_SByteValue_4_OffsetPadding_forAlignmentOnly[4];
			int8_t ___m_SByteValue_4_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ShortValue_5_OffsetPadding[4];
			// System.Int16 UnityEngine.InputSystem.Utilities.PrimitiveValue::m_ShortValue
			int16_t ___m_ShortValue_5;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ShortValue_5_OffsetPadding_forAlignmentOnly[4];
			int16_t ___m_ShortValue_5_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_UShortValue_6_OffsetPadding[4];
			// System.UInt16 UnityEngine.InputSystem.Utilities.PrimitiveValue::m_UShortValue
			uint16_t ___m_UShortValue_6;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_UShortValue_6_OffsetPadding_forAlignmentOnly[4];
			uint16_t ___m_UShortValue_6_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_IntValue_7_OffsetPadding[4];
			// System.Int32 UnityEngine.InputSystem.Utilities.PrimitiveValue::m_IntValue
			int32_t ___m_IntValue_7;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_IntValue_7_OffsetPadding_forAlignmentOnly[4];
			int32_t ___m_IntValue_7_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_UIntValue_8_OffsetPadding[4];
			// System.UInt32 UnityEngine.InputSystem.Utilities.PrimitiveValue::m_UIntValue
			uint32_t ___m_UIntValue_8;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_UIntValue_8_OffsetPadding_forAlignmentOnly[4];
			uint32_t ___m_UIntValue_8_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_LongValue_9_OffsetPadding[4];
			// System.Int64 UnityEngine.InputSystem.Utilities.PrimitiveValue::m_LongValue
			int64_t ___m_LongValue_9;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_LongValue_9_OffsetPadding_forAlignmentOnly[4];
			int64_t ___m_LongValue_9_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ULongValue_10_OffsetPadding[4];
			// System.UInt64 UnityEngine.InputSystem.Utilities.PrimitiveValue::m_ULongValue
			uint64_t ___m_ULongValue_10;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ULongValue_10_OffsetPadding_forAlignmentOnly[4];
			uint64_t ___m_ULongValue_10_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_FloatValue_11_OffsetPadding[4];
			// System.Single UnityEngine.InputSystem.Utilities.PrimitiveValue::m_FloatValue
			float ___m_FloatValue_11;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_FloatValue_11_OffsetPadding_forAlignmentOnly[4];
			float ___m_FloatValue_11_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_DoubleValue_12_OffsetPadding[4];
			// System.Double UnityEngine.InputSystem.Utilities.PrimitiveValue::m_DoubleValue
			double ___m_DoubleValue_12;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_DoubleValue_12_OffsetPadding_forAlignmentOnly[4];
			double ___m_DoubleValue_12_forAlignmentOnly;
		};
	};

public:
	inline static int32_t get_offset_of_m_Type_0() { return static_cast<int32_t>(offsetof(PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8, ___m_Type_0)); }
	inline int32_t get_m_Type_0() const { return ___m_Type_0; }
	inline int32_t* get_address_of_m_Type_0() { return &___m_Type_0; }
	inline void set_m_Type_0(int32_t value)
	{
		___m_Type_0 = value;
	}

	inline static int32_t get_offset_of_m_BoolValue_1() { return static_cast<int32_t>(offsetof(PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8, ___m_BoolValue_1)); }
	inline bool get_m_BoolValue_1() const { return ___m_BoolValue_1; }
	inline bool* get_address_of_m_BoolValue_1() { return &___m_BoolValue_1; }
	inline void set_m_BoolValue_1(bool value)
	{
		___m_BoolValue_1 = value;
	}

	inline static int32_t get_offset_of_m_CharValue_2() { return static_cast<int32_t>(offsetof(PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8, ___m_CharValue_2)); }
	inline Il2CppChar get_m_CharValue_2() const { return ___m_CharValue_2; }
	inline Il2CppChar* get_address_of_m_CharValue_2() { return &___m_CharValue_2; }
	inline void set_m_CharValue_2(Il2CppChar value)
	{
		___m_CharValue_2 = value;
	}

	inline static int32_t get_offset_of_m_ByteValue_3() { return static_cast<int32_t>(offsetof(PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8, ___m_ByteValue_3)); }
	inline uint8_t get_m_ByteValue_3() const { return ___m_ByteValue_3; }
	inline uint8_t* get_address_of_m_ByteValue_3() { return &___m_ByteValue_3; }
	inline void set_m_ByteValue_3(uint8_t value)
	{
		___m_ByteValue_3 = value;
	}

	inline static int32_t get_offset_of_m_SByteValue_4() { return static_cast<int32_t>(offsetof(PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8, ___m_SByteValue_4)); }
	inline int8_t get_m_SByteValue_4() const { return ___m_SByteValue_4; }
	inline int8_t* get_address_of_m_SByteValue_4() { return &___m_SByteValue_4; }
	inline void set_m_SByteValue_4(int8_t value)
	{
		___m_SByteValue_4 = value;
	}

	inline static int32_t get_offset_of_m_ShortValue_5() { return static_cast<int32_t>(offsetof(PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8, ___m_ShortValue_5)); }
	inline int16_t get_m_ShortValue_5() const { return ___m_ShortValue_5; }
	inline int16_t* get_address_of_m_ShortValue_5() { return &___m_ShortValue_5; }
	inline void set_m_ShortValue_5(int16_t value)
	{
		___m_ShortValue_5 = value;
	}

	inline static int32_t get_offset_of_m_UShortValue_6() { return static_cast<int32_t>(offsetof(PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8, ___m_UShortValue_6)); }
	inline uint16_t get_m_UShortValue_6() const { return ___m_UShortValue_6; }
	inline uint16_t* get_address_of_m_UShortValue_6() { return &___m_UShortValue_6; }
	inline void set_m_UShortValue_6(uint16_t value)
	{
		___m_UShortValue_6 = value;
	}

	inline static int32_t get_offset_of_m_IntValue_7() { return static_cast<int32_t>(offsetof(PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8, ___m_IntValue_7)); }
	inline int32_t get_m_IntValue_7() const { return ___m_IntValue_7; }
	inline int32_t* get_address_of_m_IntValue_7() { return &___m_IntValue_7; }
	inline void set_m_IntValue_7(int32_t value)
	{
		___m_IntValue_7 = value;
	}

	inline static int32_t get_offset_of_m_UIntValue_8() { return static_cast<int32_t>(offsetof(PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8, ___m_UIntValue_8)); }
	inline uint32_t get_m_UIntValue_8() const { return ___m_UIntValue_8; }
	inline uint32_t* get_address_of_m_UIntValue_8() { return &___m_UIntValue_8; }
	inline void set_m_UIntValue_8(uint32_t value)
	{
		___m_UIntValue_8 = value;
	}

	inline static int32_t get_offset_of_m_LongValue_9() { return static_cast<int32_t>(offsetof(PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8, ___m_LongValue_9)); }
	inline int64_t get_m_LongValue_9() const { return ___m_LongValue_9; }
	inline int64_t* get_address_of_m_LongValue_9() { return &___m_LongValue_9; }
	inline void set_m_LongValue_9(int64_t value)
	{
		___m_LongValue_9 = value;
	}

	inline static int32_t get_offset_of_m_ULongValue_10() { return static_cast<int32_t>(offsetof(PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8, ___m_ULongValue_10)); }
	inline uint64_t get_m_ULongValue_10() const { return ___m_ULongValue_10; }
	inline uint64_t* get_address_of_m_ULongValue_10() { return &___m_ULongValue_10; }
	inline void set_m_ULongValue_10(uint64_t value)
	{
		___m_ULongValue_10 = value;
	}

	inline static int32_t get_offset_of_m_FloatValue_11() { return static_cast<int32_t>(offsetof(PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8, ___m_FloatValue_11)); }
	inline float get_m_FloatValue_11() const { return ___m_FloatValue_11; }
	inline float* get_address_of_m_FloatValue_11() { return &___m_FloatValue_11; }
	inline void set_m_FloatValue_11(float value)
	{
		___m_FloatValue_11 = value;
	}

	inline static int32_t get_offset_of_m_DoubleValue_12() { return static_cast<int32_t>(offsetof(PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8, ___m_DoubleValue_12)); }
	inline double get_m_DoubleValue_12() const { return ___m_DoubleValue_12; }
	inline double* get_address_of_m_DoubleValue_12() { return &___m_DoubleValue_12; }
	inline void set_m_DoubleValue_12(double value)
	{
		___m_DoubleValue_12 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Utilities.PrimitiveValue
struct PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8_marshaled_pinvoke
{
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			int32_t ___m_Type_0;
		};
		#pragma pack(pop, tp)
		struct
		{
			int32_t ___m_Type_0_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_BoolValue_1_OffsetPadding[4];
			int32_t ___m_BoolValue_1;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_BoolValue_1_OffsetPadding_forAlignmentOnly[4];
			int32_t ___m_BoolValue_1_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_CharValue_2_OffsetPadding[4];
			uint8_t ___m_CharValue_2;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_CharValue_2_OffsetPadding_forAlignmentOnly[4];
			uint8_t ___m_CharValue_2_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ByteValue_3_OffsetPadding[4];
			uint8_t ___m_ByteValue_3;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ByteValue_3_OffsetPadding_forAlignmentOnly[4];
			uint8_t ___m_ByteValue_3_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_SByteValue_4_OffsetPadding[4];
			int8_t ___m_SByteValue_4;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_SByteValue_4_OffsetPadding_forAlignmentOnly[4];
			int8_t ___m_SByteValue_4_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ShortValue_5_OffsetPadding[4];
			int16_t ___m_ShortValue_5;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ShortValue_5_OffsetPadding_forAlignmentOnly[4];
			int16_t ___m_ShortValue_5_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_UShortValue_6_OffsetPadding[4];
			uint16_t ___m_UShortValue_6;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_UShortValue_6_OffsetPadding_forAlignmentOnly[4];
			uint16_t ___m_UShortValue_6_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_IntValue_7_OffsetPadding[4];
			int32_t ___m_IntValue_7;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_IntValue_7_OffsetPadding_forAlignmentOnly[4];
			int32_t ___m_IntValue_7_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_UIntValue_8_OffsetPadding[4];
			uint32_t ___m_UIntValue_8;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_UIntValue_8_OffsetPadding_forAlignmentOnly[4];
			uint32_t ___m_UIntValue_8_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_LongValue_9_OffsetPadding[4];
			int64_t ___m_LongValue_9;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_LongValue_9_OffsetPadding_forAlignmentOnly[4];
			int64_t ___m_LongValue_9_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ULongValue_10_OffsetPadding[4];
			uint64_t ___m_ULongValue_10;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ULongValue_10_OffsetPadding_forAlignmentOnly[4];
			uint64_t ___m_ULongValue_10_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_FloatValue_11_OffsetPadding[4];
			float ___m_FloatValue_11;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_FloatValue_11_OffsetPadding_forAlignmentOnly[4];
			float ___m_FloatValue_11_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_DoubleValue_12_OffsetPadding[4];
			double ___m_DoubleValue_12;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_DoubleValue_12_OffsetPadding_forAlignmentOnly[4];
			double ___m_DoubleValue_12_forAlignmentOnly;
		};
	};
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Utilities.PrimitiveValue
struct PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8_marshaled_com
{
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			int32_t ___m_Type_0;
		};
		#pragma pack(pop, tp)
		struct
		{
			int32_t ___m_Type_0_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_BoolValue_1_OffsetPadding[4];
			int32_t ___m_BoolValue_1;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_BoolValue_1_OffsetPadding_forAlignmentOnly[4];
			int32_t ___m_BoolValue_1_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_CharValue_2_OffsetPadding[4];
			uint8_t ___m_CharValue_2;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_CharValue_2_OffsetPadding_forAlignmentOnly[4];
			uint8_t ___m_CharValue_2_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ByteValue_3_OffsetPadding[4];
			uint8_t ___m_ByteValue_3;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ByteValue_3_OffsetPadding_forAlignmentOnly[4];
			uint8_t ___m_ByteValue_3_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_SByteValue_4_OffsetPadding[4];
			int8_t ___m_SByteValue_4;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_SByteValue_4_OffsetPadding_forAlignmentOnly[4];
			int8_t ___m_SByteValue_4_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ShortValue_5_OffsetPadding[4];
			int16_t ___m_ShortValue_5;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ShortValue_5_OffsetPadding_forAlignmentOnly[4];
			int16_t ___m_ShortValue_5_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_UShortValue_6_OffsetPadding[4];
			uint16_t ___m_UShortValue_6;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_UShortValue_6_OffsetPadding_forAlignmentOnly[4];
			uint16_t ___m_UShortValue_6_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_IntValue_7_OffsetPadding[4];
			int32_t ___m_IntValue_7;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_IntValue_7_OffsetPadding_forAlignmentOnly[4];
			int32_t ___m_IntValue_7_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_UIntValue_8_OffsetPadding[4];
			uint32_t ___m_UIntValue_8;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_UIntValue_8_OffsetPadding_forAlignmentOnly[4];
			uint32_t ___m_UIntValue_8_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_LongValue_9_OffsetPadding[4];
			int64_t ___m_LongValue_9;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_LongValue_9_OffsetPadding_forAlignmentOnly[4];
			int64_t ___m_LongValue_9_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_ULongValue_10_OffsetPadding[4];
			uint64_t ___m_ULongValue_10;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_ULongValue_10_OffsetPadding_forAlignmentOnly[4];
			uint64_t ___m_ULongValue_10_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_FloatValue_11_OffsetPadding[4];
			float ___m_FloatValue_11;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_FloatValue_11_OffsetPadding_forAlignmentOnly[4];
			float ___m_FloatValue_11_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___m_DoubleValue_12_OffsetPadding[4];
			double ___m_DoubleValue_12;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___m_DoubleValue_12_OffsetPadding_forAlignmentOnly[4];
			double ___m_DoubleValue_12_forAlignmentOnly;
		};
	};
};

// UnityEngine.InputSystem.Utilities.JsonParser/JsonValue
struct  JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE 
{
public:
	// UnityEngine.InputSystem.Utilities.JsonParser/JsonValueType UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::type
	int32_t ___type_0;
	// System.Boolean UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::boolValue
	bool ___boolValue_1;
	// System.Double UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::realValue
	double ___realValue_2;
	// System.Int64 UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::integerValue
	int64_t ___integerValue_3;
	// UnityEngine.InputSystem.Utilities.JsonParser/JsonString UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::stringValue
	JsonString_tE3B4CC7543FEB24BCB9662EA44ACE137F9203F0E  ___stringValue_4;
	// System.Collections.Generic.List`1<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue> UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::arrayValue
	List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * ___arrayValue_5;
	// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue> UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::objectValue
	Dictionary_2_tDEF8A5BB0503C6EA9F96F292391AFCF18B07DEF3 * ___objectValue_6;
	// System.Object UnityEngine.InputSystem.Utilities.JsonParser/JsonValue::anyValue
	RuntimeObject * ___anyValue_7;

public:
	inline static int32_t get_offset_of_type_0() { return static_cast<int32_t>(offsetof(JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE, ___type_0)); }
	inline int32_t get_type_0() const { return ___type_0; }
	inline int32_t* get_address_of_type_0() { return &___type_0; }
	inline void set_type_0(int32_t value)
	{
		___type_0 = value;
	}

	inline static int32_t get_offset_of_boolValue_1() { return static_cast<int32_t>(offsetof(JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE, ___boolValue_1)); }
	inline bool get_boolValue_1() const { return ___boolValue_1; }
	inline bool* get_address_of_boolValue_1() { return &___boolValue_1; }
	inline void set_boolValue_1(bool value)
	{
		___boolValue_1 = value;
	}

	inline static int32_t get_offset_of_realValue_2() { return static_cast<int32_t>(offsetof(JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE, ___realValue_2)); }
	inline double get_realValue_2() const { return ___realValue_2; }
	inline double* get_address_of_realValue_2() { return &___realValue_2; }
	inline void set_realValue_2(double value)
	{
		___realValue_2 = value;
	}

	inline static int32_t get_offset_of_integerValue_3() { return static_cast<int32_t>(offsetof(JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE, ___integerValue_3)); }
	inline int64_t get_integerValue_3() const { return ___integerValue_3; }
	inline int64_t* get_address_of_integerValue_3() { return &___integerValue_3; }
	inline void set_integerValue_3(int64_t value)
	{
		___integerValue_3 = value;
	}

	inline static int32_t get_offset_of_stringValue_4() { return static_cast<int32_t>(offsetof(JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE, ___stringValue_4)); }
	inline JsonString_tE3B4CC7543FEB24BCB9662EA44ACE137F9203F0E  get_stringValue_4() const { return ___stringValue_4; }
	inline JsonString_tE3B4CC7543FEB24BCB9662EA44ACE137F9203F0E * get_address_of_stringValue_4() { return &___stringValue_4; }
	inline void set_stringValue_4(JsonString_tE3B4CC7543FEB24BCB9662EA44ACE137F9203F0E  value)
	{
		___stringValue_4 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___stringValue_4))->___text_0))->___m_String_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_arrayValue_5() { return static_cast<int32_t>(offsetof(JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE, ___arrayValue_5)); }
	inline List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * get_arrayValue_5() const { return ___arrayValue_5; }
	inline List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 ** get_address_of_arrayValue_5() { return &___arrayValue_5; }
	inline void set_arrayValue_5(List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * value)
	{
		___arrayValue_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___arrayValue_5), (void*)value);
	}

	inline static int32_t get_offset_of_objectValue_6() { return static_cast<int32_t>(offsetof(JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE, ___objectValue_6)); }
	inline Dictionary_2_tDEF8A5BB0503C6EA9F96F292391AFCF18B07DEF3 * get_objectValue_6() const { return ___objectValue_6; }
	inline Dictionary_2_tDEF8A5BB0503C6EA9F96F292391AFCF18B07DEF3 ** get_address_of_objectValue_6() { return &___objectValue_6; }
	inline void set_objectValue_6(Dictionary_2_tDEF8A5BB0503C6EA9F96F292391AFCF18B07DEF3 * value)
	{
		___objectValue_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___objectValue_6), (void*)value);
	}

	inline static int32_t get_offset_of_anyValue_7() { return static_cast<int32_t>(offsetof(JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE, ___anyValue_7)); }
	inline RuntimeObject * get_anyValue_7() const { return ___anyValue_7; }
	inline RuntimeObject ** get_address_of_anyValue_7() { return &___anyValue_7; }
	inline void set_anyValue_7(RuntimeObject * value)
	{
		___anyValue_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___anyValue_7), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Utilities.JsonParser/JsonValue
struct JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE_marshaled_pinvoke
{
	int32_t ___type_0;
	int32_t ___boolValue_1;
	double ___realValue_2;
	int64_t ___integerValue_3;
	JsonString_tE3B4CC7543FEB24BCB9662EA44ACE137F9203F0E_marshaled_pinvoke ___stringValue_4;
	List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * ___arrayValue_5;
	Dictionary_2_tDEF8A5BB0503C6EA9F96F292391AFCF18B07DEF3 * ___objectValue_6;
	Il2CppIUnknown* ___anyValue_7;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Utilities.JsonParser/JsonValue
struct JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE_marshaled_com
{
	int32_t ___type_0;
	int32_t ___boolValue_1;
	double ___realValue_2;
	int64_t ___integerValue_3;
	JsonString_tE3B4CC7543FEB24BCB9662EA44ACE137F9203F0E_marshaled_com ___stringValue_4;
	List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * ___arrayValue_5;
	Dictionary_2_tDEF8A5BB0503C6EA9F96F292391AFCF18B07DEF3 * ___objectValue_6;
	Il2CppIUnknown* ___anyValue_7;
};

// System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>
struct  Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::list
	List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * ___list_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::index
	int32_t ___index_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::version
	int32_t ___version_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  ___current_3;

public:
	inline static int32_t get_offset_of_list_0() { return static_cast<int32_t>(offsetof(Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F, ___list_0)); }
	inline List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * get_list_0() const { return ___list_0; }
	inline List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 ** get_address_of_list_0() { return &___list_0; }
	inline void set_list_0(List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * value)
	{
		___list_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___list_0), (void*)value);
	}

	inline static int32_t get_offset_of_index_1() { return static_cast<int32_t>(offsetof(Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F, ___index_1)); }
	inline int32_t get_index_1() const { return ___index_1; }
	inline int32_t* get_address_of_index_1() { return &___index_1; }
	inline void set_index_1(int32_t value)
	{
		___index_1 = value;
	}

	inline static int32_t get_offset_of_version_2() { return static_cast<int32_t>(offsetof(Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F, ___version_2)); }
	inline int32_t get_version_2() const { return ___version_2; }
	inline int32_t* get_address_of_version_2() { return &___version_2; }
	inline void set_version_2(int32_t value)
	{
		___version_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F, ___current_3)); }
	inline JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  get_current_3() const { return ___current_3; }
	inline JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  value)
	{
		___current_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___current_3))->___stringValue_4))->___text_0))->___m_String_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___current_3))->___arrayValue_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___current_3))->___objectValue_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___current_3))->___anyValue_7), (void*)NULL);
		#endif
	}
};


// System.Func`2<UnityEngine.Color,System.Boolean>
struct  Func_2_t3985FFDAB0D05F8E97E8EA849D5A24F16EFFC4FD  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,System.Boolean>
struct  Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Color>
struct  Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Vector3>
struct  Func_2_tA55660D7B36BC919063457215A12594F309CFDF1  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,Unity.Mathematics.float3>
struct  Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<System.Int32,System.Boolean>
struct  Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<System.Int32,System.Int32>
struct  Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.InputSystem.Utilities.InternedString,System.Boolean>
struct  Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString>
struct  Func_2_tEE37498C122C43E9F0D581326B5464292A55F235  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.InputSystem.Utilities.InternedString,System.Object>
struct  Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.InputSystem.Utilities.NameAndParameters,System.Boolean>
struct  Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.InputSystem.Utilities.NameAndParameters,UnityEngine.InputSystem.Utilities.InternedString>
struct  Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.InputSystem.Utilities.NameAndParameters,System.Object>
struct  Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<System.Object,System.Boolean>
struct  Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>
struct  Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<System.Object,System.Object>
struct  Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.Vector3,System.Boolean>
struct  Func_2_t3041FD3183D19FE8416AE2E43A6398B2C06B7269  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.Vector3Int,System.Boolean>
struct  Func_2_tB3AD6A340F9ED708E8459C7912C86F7504161867  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<Unity.Mathematics.float3,System.Boolean>
struct  Func_2_t43355C55B1BBA93635101F6AF90867509812D7E5  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,System.Boolean>
struct  Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,UnityEngine.Vector3Int>
struct  Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Boolean>
struct  Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,UnityEngine.InputSystem.Utilities.InternedString>
struct  Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Object>
struct  Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64  : public MulticastDelegate_t
{
public:

public:
};


// System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>
struct  KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4 
{
public:
	// TKey System.Collections.Generic.KeyValuePair`2::key
	RuntimeObject * ___key_0;
	// TValue System.Collections.Generic.KeyValuePair`2::value
	JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  ___value_1;

public:
	inline static int32_t get_offset_of_key_0() { return static_cast<int32_t>(offsetof(KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4, ___key_0)); }
	inline RuntimeObject * get_key_0() const { return ___key_0; }
	inline RuntimeObject ** get_address_of_key_0() { return &___key_0; }
	inline void set_key_0(RuntimeObject * value)
	{
		___key_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___key_0), (void*)value);
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4, ___value_1)); }
	inline JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  get_value_1() const { return ___value_1; }
	inline JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE * get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___value_1))->___stringValue_4))->___text_0))->___m_String_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___value_1))->___arrayValue_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___value_1))->___objectValue_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___value_1))->___anyValue_7), (void*)NULL);
		#endif
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Color>
struct  WhereSelectListIterator_2_t08B768B4AD54F201B800C51471E1C1C5FD1A8E8C  : public Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64 * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t08B768B4AD54F201B800C51471E1C1C5FD1A8E8C, ___source_3)); }
	inline List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * get_source_3() const { return ___source_3; }
	inline List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t08B768B4AD54F201B800C51471E1C1C5FD1A8E8C, ___predicate_4)); }
	inline Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t08B768B4AD54F201B800C51471E1C1C5FD1A8E8C, ___selector_5)); }
	inline Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64 * get_selector_5() const { return ___selector_5; }
	inline Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64 ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64 * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t08B768B4AD54F201B800C51471E1C1C5FD1A8E8C, ___enumerator_6)); }
	inline Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___Data_1), (void*)NULL);
		#endif
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Vector3>
struct  WhereSelectListIterator_2_t94F415FEA624816E42FAE1274A4EC29F5D5C1625  : public Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_tA55660D7B36BC919063457215A12594F309CFDF1 * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t94F415FEA624816E42FAE1274A4EC29F5D5C1625, ___source_3)); }
	inline List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * get_source_3() const { return ___source_3; }
	inline List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t94F415FEA624816E42FAE1274A4EC29F5D5C1625, ___predicate_4)); }
	inline Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t94F415FEA624816E42FAE1274A4EC29F5D5C1625, ___selector_5)); }
	inline Func_2_tA55660D7B36BC919063457215A12594F309CFDF1 * get_selector_5() const { return ___selector_5; }
	inline Func_2_tA55660D7B36BC919063457215A12594F309CFDF1 ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_tA55660D7B36BC919063457215A12594F309CFDF1 * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t94F415FEA624816E42FAE1274A4EC29F5D5C1625, ___enumerator_6)); }
	inline Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___Data_1), (void*)NULL);
		#endif
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,Unity.Mathematics.float3>
struct  WhereSelectListIterator_2_t8005F348CC0B870A84DE3E85429A840305201D6E  : public Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8005F348CC0B870A84DE3E85429A840305201D6E, ___source_3)); }
	inline List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * get_source_3() const { return ___source_3; }
	inline List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8005F348CC0B870A84DE3E85429A840305201D6E, ___predicate_4)); }
	inline Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8005F348CC0B870A84DE3E85429A840305201D6E, ___selector_5)); }
	inline Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C * get_selector_5() const { return ___selector_5; }
	inline Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8005F348CC0B870A84DE3E85429A840305201D6E, ___enumerator_6)); }
	inline Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___Data_1), (void*)NULL);
		#endif
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NameAndParameters,UnityEngine.InputSystem.Utilities.InternedString>
struct  WhereSelectListIterator_2_t9D660598407BAACFC571EA8D5994C24416E7EF72  : public Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2 * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_t3F22A2E619D662922F996C766D960AF285909004  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t9D660598407BAACFC571EA8D5994C24416E7EF72, ___source_3)); }
	inline List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * get_source_3() const { return ___source_3; }
	inline List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t9D660598407BAACFC571EA8D5994C24416E7EF72, ___predicate_4)); }
	inline Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t9D660598407BAACFC571EA8D5994C24416E7EF72, ___selector_5)); }
	inline Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2 * get_selector_5() const { return ___selector_5; }
	inline Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2 ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2 * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t9D660598407BAACFC571EA8D5994C24416E7EF72, ___enumerator_6)); }
	inline Enumerator_t3F22A2E619D662922F996C766D960AF285909004  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_t3F22A2E619D662922F996C766D960AF285909004 * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_t3F22A2E619D662922F996C766D960AF285909004  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___U3CnameU3Ek__BackingField_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___enumerator_6))->___current_3))->___U3CparametersU3Ek__BackingField_1))->___m_Array_0), (void*)NULL);
		#endif
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NameAndParameters,System.Object>
struct  WhereSelectListIterator_2_tA136D27DBB78E46ED7DC60EC99A376E9D816FC6A  : public Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_t3F22A2E619D662922F996C766D960AF285909004  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tA136D27DBB78E46ED7DC60EC99A376E9D816FC6A, ___source_3)); }
	inline List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * get_source_3() const { return ___source_3; }
	inline List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tA136D27DBB78E46ED7DC60EC99A376E9D816FC6A, ___predicate_4)); }
	inline Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tA136D27DBB78E46ED7DC60EC99A376E9D816FC6A, ___selector_5)); }
	inline Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F * get_selector_5() const { return ___selector_5; }
	inline Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tA136D27DBB78E46ED7DC60EC99A376E9D816FC6A, ___enumerator_6)); }
	inline Enumerator_t3F22A2E619D662922F996C766D960AF285909004  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_t3F22A2E619D662922F996C766D960AF285909004 * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_t3F22A2E619D662922F996C766D960AF285909004  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___U3CnameU3Ek__BackingField_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___enumerator_6))->___current_3))->___U3CparametersU3Ek__BackingField_1))->___m_Array_0), (void*)NULL);
		#endif
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,UnityEngine.Vector3Int>
struct  WhereSelectListIterator_2_t61A00440D82A40FF5366588862F077D31BB2B86D  : public Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t61A00440D82A40FF5366588862F077D31BB2B86D, ___source_3)); }
	inline List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 * get_source_3() const { return ___source_3; }
	inline List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t61A00440D82A40FF5366588862F077D31BB2B86D, ___predicate_4)); }
	inline Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t61A00440D82A40FF5366588862F077D31BB2B86D, ___selector_5)); }
	inline Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A * get_selector_5() const { return ___selector_5; }
	inline Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t61A00440D82A40FF5366588862F077D31BB2B86D, ___enumerator_6)); }
	inline Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___name_1), (void*)NULL);
		#endif
	}
};


// UnityEngine.InputSystem.Utilities.NamedValue
struct  NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0 
{
public:
	// System.String UnityEngine.InputSystem.Utilities.NamedValue::<name>k__BackingField
	String_t* ___U3CnameU3Ek__BackingField_1;
	// UnityEngine.InputSystem.Utilities.PrimitiveValue UnityEngine.InputSystem.Utilities.NamedValue::<value>k__BackingField
	PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8  ___U3CvalueU3Ek__BackingField_2;

public:
	inline static int32_t get_offset_of_U3CnameU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0, ___U3CnameU3Ek__BackingField_1)); }
	inline String_t* get_U3CnameU3Ek__BackingField_1() const { return ___U3CnameU3Ek__BackingField_1; }
	inline String_t** get_address_of_U3CnameU3Ek__BackingField_1() { return &___U3CnameU3Ek__BackingField_1; }
	inline void set_U3CnameU3Ek__BackingField_1(String_t* value)
	{
		___U3CnameU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CnameU3Ek__BackingField_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CvalueU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0, ___U3CvalueU3Ek__BackingField_2)); }
	inline PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8  get_U3CvalueU3Ek__BackingField_2() const { return ___U3CvalueU3Ek__BackingField_2; }
	inline PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8 * get_address_of_U3CvalueU3Ek__BackingField_2() { return &___U3CvalueU3Ek__BackingField_2; }
	inline void set_U3CvalueU3Ek__BackingField_2(PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8  value)
	{
		___U3CvalueU3Ek__BackingField_2 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.InputSystem.Utilities.NamedValue
struct NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0_marshaled_pinvoke
{
	char* ___U3CnameU3Ek__BackingField_1;
	PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8_marshaled_pinvoke ___U3CvalueU3Ek__BackingField_2;
};
// Native definition for COM marshalling of UnityEngine.InputSystem.Utilities.NamedValue
struct NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0_marshaled_com
{
	Il2CppChar* ___U3CnameU3Ek__BackingField_1;
	PrimitiveValue_t545E3337FA9F8053C33499E4CA556367E0FD56A8_marshaled_com ___U3CvalueU3Ek__BackingField_2;
};

// System.Collections.Generic.List`1/Enumerator<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>>
struct  Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::list
	List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * ___list_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::index
	int32_t ___index_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::version
	int32_t ___version_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  ___current_3;

public:
	inline static int32_t get_offset_of_list_0() { return static_cast<int32_t>(offsetof(Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF, ___list_0)); }
	inline List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * get_list_0() const { return ___list_0; }
	inline List_1_tA904E5F65F2154445E86287BD8613DCB85340206 ** get_address_of_list_0() { return &___list_0; }
	inline void set_list_0(List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * value)
	{
		___list_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___list_0), (void*)value);
	}

	inline static int32_t get_offset_of_index_1() { return static_cast<int32_t>(offsetof(Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF, ___index_1)); }
	inline int32_t get_index_1() const { return ___index_1; }
	inline int32_t* get_address_of_index_1() { return &___index_1; }
	inline void set_index_1(int32_t value)
	{
		___index_1 = value;
	}

	inline static int32_t get_offset_of_version_2() { return static_cast<int32_t>(offsetof(Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF, ___version_2)); }
	inline int32_t get_version_2() const { return ___version_2; }
	inline int32_t* get_address_of_version_2() { return &___version_2; }
	inline void set_version_2(int32_t value)
	{
		___version_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF, ___current_3)); }
	inline KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  get_current_3() const { return ___current_3; }
	inline KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4 * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  value)
	{
		___current_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___current_3))->___key_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&((&(((&___current_3))->___value_1))->___stringValue_4))->___text_0))->___m_String_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___current_3))->___value_1))->___arrayValue_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___current_3))->___value_1))->___objectValue_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___current_3))->___value_1))->___anyValue_7), (void*)NULL);
		#endif
	}
};


// System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.NamedValue>
struct  Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::list
	List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * ___list_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::index
	int32_t ___index_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::version
	int32_t ___version_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  ___current_3;

public:
	inline static int32_t get_offset_of_list_0() { return static_cast<int32_t>(offsetof(Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66, ___list_0)); }
	inline List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * get_list_0() const { return ___list_0; }
	inline List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 ** get_address_of_list_0() { return &___list_0; }
	inline void set_list_0(List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * value)
	{
		___list_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___list_0), (void*)value);
	}

	inline static int32_t get_offset_of_index_1() { return static_cast<int32_t>(offsetof(Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66, ___index_1)); }
	inline int32_t get_index_1() const { return ___index_1; }
	inline int32_t* get_address_of_index_1() { return &___index_1; }
	inline void set_index_1(int32_t value)
	{
		___index_1 = value;
	}

	inline static int32_t get_offset_of_version_2() { return static_cast<int32_t>(offsetof(Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66, ___version_2)); }
	inline int32_t get_version_2() const { return ___version_2; }
	inline int32_t* get_address_of_version_2() { return &___version_2; }
	inline void set_version_2(int32_t value)
	{
		___version_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66, ___current_3)); }
	inline NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  get_current_3() const { return ___current_3; }
	inline NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0 * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  value)
	{
		___current_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___current_3))->___U3CnameU3Ek__BackingField_1), (void*)NULL);
	}
};


// System.Func`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,System.Boolean>
struct  Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,UnityEngine.InputSystem.Utilities.InternedString>
struct  Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,System.Object>
struct  Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.InputSystem.Utilities.NamedValue,System.Boolean>
struct  Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.InputSystem.Utilities.NamedValue,UnityEngine.InputSystem.Utilities.InternedString>
struct  Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<UnityEngine.InputSystem.Utilities.NamedValue,System.Object>
struct  Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54  : public MulticastDelegate_t
{
public:

public:
};


// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,UnityEngine.InputSystem.Utilities.InternedString>
struct  WhereSelectListIterator_2_t8F78416238F9681ED8DD6A1888291B25087ADB48  : public Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8F78416238F9681ED8DD6A1888291B25087ADB48, ___source_3)); }
	inline List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * get_source_3() const { return ___source_3; }
	inline List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8F78416238F9681ED8DD6A1888291B25087ADB48, ___predicate_4)); }
	inline Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8F78416238F9681ED8DD6A1888291B25087ADB48, ___selector_5)); }
	inline Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C * get_selector_5() const { return ___selector_5; }
	inline Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8F78416238F9681ED8DD6A1888291B25087ADB48, ___enumerator_6)); }
	inline Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&((&(((&___enumerator_6))->___current_3))->___stringValue_4))->___text_0))->___m_String_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___arrayValue_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___objectValue_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___anyValue_7), (void*)NULL);
		#endif
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Object>
struct  WhereSelectListIterator_2_t7BD313142193815CBBFF1CDEAB29F9EAF147B7AA  : public Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t7BD313142193815CBBFF1CDEAB29F9EAF147B7AA, ___source_3)); }
	inline List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * get_source_3() const { return ___source_3; }
	inline List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t7BD313142193815CBBFF1CDEAB29F9EAF147B7AA, ___predicate_4)); }
	inline Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t7BD313142193815CBBFF1CDEAB29F9EAF147B7AA, ___selector_5)); }
	inline Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 * get_selector_5() const { return ___selector_5; }
	inline Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t7BD313142193815CBBFF1CDEAB29F9EAF147B7AA, ___enumerator_6)); }
	inline Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&((&(((&___enumerator_6))->___current_3))->___stringValue_4))->___text_0))->___m_String_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___arrayValue_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___objectValue_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___anyValue_7), (void*)NULL);
		#endif
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,UnityEngine.InputSystem.Utilities.InternedString>
struct  WhereSelectListIterator_2_t252DD2ECAA2598C5A96C9D96F81661DB7E55BBD5  : public Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9 * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t252DD2ECAA2598C5A96C9D96F81661DB7E55BBD5, ___source_3)); }
	inline List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * get_source_3() const { return ___source_3; }
	inline List_1_tA904E5F65F2154445E86287BD8613DCB85340206 ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t252DD2ECAA2598C5A96C9D96F81661DB7E55BBD5, ___predicate_4)); }
	inline Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t252DD2ECAA2598C5A96C9D96F81661DB7E55BBD5, ___selector_5)); }
	inline Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9 * get_selector_5() const { return ___selector_5; }
	inline Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9 ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9 * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t252DD2ECAA2598C5A96C9D96F81661DB7E55BBD5, ___enumerator_6)); }
	inline Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___key_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&((&((&(((&___enumerator_6))->___current_3))->___value_1))->___stringValue_4))->___text_0))->___m_String_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___enumerator_6))->___current_3))->___value_1))->___arrayValue_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___enumerator_6))->___current_3))->___value_1))->___objectValue_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___enumerator_6))->___current_3))->___value_1))->___anyValue_7), (void*)NULL);
		#endif
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,System.Object>
struct  WhereSelectListIterator_2_tEC5F4A5D3B70CD5D957FD6B731AFBD8925501168  : public Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tEC5F4A5D3B70CD5D957FD6B731AFBD8925501168, ___source_3)); }
	inline List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * get_source_3() const { return ___source_3; }
	inline List_1_tA904E5F65F2154445E86287BD8613DCB85340206 ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tEC5F4A5D3B70CD5D957FD6B731AFBD8925501168, ___predicate_4)); }
	inline Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tEC5F4A5D3B70CD5D957FD6B731AFBD8925501168, ___selector_5)); }
	inline Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE * get_selector_5() const { return ___selector_5; }
	inline Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tEC5F4A5D3B70CD5D957FD6B731AFBD8925501168, ___enumerator_6)); }
	inline Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___key_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&((&((&(((&___enumerator_6))->___current_3))->___value_1))->___stringValue_4))->___text_0))->___m_String_0), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___enumerator_6))->___current_3))->___value_1))->___arrayValue_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___enumerator_6))->___current_3))->___value_1))->___objectValue_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___enumerator_6))->___current_3))->___value_1))->___anyValue_7), (void*)NULL);
		#endif
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NamedValue,UnityEngine.InputSystem.Utilities.InternedString>
struct  WhereSelectListIterator_2_tDDA7D42453A9A6E14983F2A64F835CA82FB5C3D4  : public Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tDDA7D42453A9A6E14983F2A64F835CA82FB5C3D4, ___source_3)); }
	inline List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * get_source_3() const { return ___source_3; }
	inline List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tDDA7D42453A9A6E14983F2A64F835CA82FB5C3D4, ___predicate_4)); }
	inline Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tDDA7D42453A9A6E14983F2A64F835CA82FB5C3D4, ___selector_5)); }
	inline Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D * get_selector_5() const { return ___selector_5; }
	inline Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_tDDA7D42453A9A6E14983F2A64F835CA82FB5C3D4, ___enumerator_6)); }
	inline Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___U3CnameU3Ek__BackingField_1), (void*)NULL);
		#endif
	}
};


// System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NamedValue,System.Object>
struct  WhereSelectListIterator_2_t8DFCE6669BD07F0F7FD9461FACD9D83AAF9F8EE3  : public Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279
{
public:
	// System.Collections.Generic.List`1<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::source
	List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * ___source_3;
	// System.Func`2<TSource,System.Boolean> System.Linq.Enumerable/WhereSelectListIterator`2::predicate
	Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * ___predicate_4;
	// System.Func`2<TSource,TResult> System.Linq.Enumerable/WhereSelectListIterator`2::selector
	Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54 * ___selector_5;
	// System.Collections.Generic.List`1/Enumerator<TSource> System.Linq.Enumerable/WhereSelectListIterator`2::enumerator
	Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66  ___enumerator_6;

public:
	inline static int32_t get_offset_of_source_3() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8DFCE6669BD07F0F7FD9461FACD9D83AAF9F8EE3, ___source_3)); }
	inline List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * get_source_3() const { return ___source_3; }
	inline List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 ** get_address_of_source_3() { return &___source_3; }
	inline void set_source_3(List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * value)
	{
		___source_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_3), (void*)value);
	}

	inline static int32_t get_offset_of_predicate_4() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8DFCE6669BD07F0F7FD9461FACD9D83AAF9F8EE3, ___predicate_4)); }
	inline Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * get_predicate_4() const { return ___predicate_4; }
	inline Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 ** get_address_of_predicate_4() { return &___predicate_4; }
	inline void set_predicate_4(Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * value)
	{
		___predicate_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___predicate_4), (void*)value);
	}

	inline static int32_t get_offset_of_selector_5() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8DFCE6669BD07F0F7FD9461FACD9D83AAF9F8EE3, ___selector_5)); }
	inline Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54 * get_selector_5() const { return ___selector_5; }
	inline Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54 ** get_address_of_selector_5() { return &___selector_5; }
	inline void set_selector_5(Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54 * value)
	{
		___selector_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___selector_5), (void*)value);
	}

	inline static int32_t get_offset_of_enumerator_6() { return static_cast<int32_t>(offsetof(WhereSelectListIterator_2_t8DFCE6669BD07F0F7FD9461FACD9D83AAF9F8EE3, ___enumerator_6)); }
	inline Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66  get_enumerator_6() const { return ___enumerator_6; }
	inline Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 * get_address_of_enumerator_6() { return &___enumerator_6; }
	inline void set_enumerator_6(Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66  value)
	{
		___enumerator_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___enumerator_6))->___list_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___enumerator_6))->___current_3))->___U3CnameU3Ek__BackingField_1), (void*)NULL);
		#endif
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif


// !0 System.Collections.Generic.List`1/Enumerator<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>>::get_Current()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  Enumerator_get_Current_m60A7BC98ACC855A940897C0FDD226381D3E17BCD_gshared_inline (Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.List`1/Enumerator<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_m03E8649EAA3C72543BF00144DA904F2F391CB46B_gshared (Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1/Enumerator<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex>::get_Current()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  Enumerator_get_Current_mB9DED66EBA82669AB83832B40F60E1710B5179B4_gshared_inline (Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.List`1/Enumerator<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_mACDC401A875ECF83AEF9477068CDF02545A1D997_gshared (Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1/Enumerator<System.Int32>::get_Current()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Enumerator_get_Current_m6BBD624C51F7E20D347FE5894A6ECA94B8011181_gshared_inline (Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.List`1/Enumerator<System.Int32>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_m40FD166B6757334A2BBCF67238EFDF70D727A4A6_gshared (Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.InternedString>::get_Current()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  Enumerator_get_Current_mDFC8852F498B3A27BD601B8B3D1AAD9EFD96ED78_gshared_inline (Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.InternedString>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_mC85A573A7B1E29F62C95F0841F4368217B0FC647_gshared (Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.NameAndParameters>::get_Current()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  Enumerator_get_Current_mDA65875F4B6726349744D3FDA9F8F3D655CF843E_gshared_inline (Enumerator_t3F22A2E619D662922F996C766D960AF285909004 * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.NameAndParameters>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_m8C47DD84EE474A11C083B071DE1C5AF1AAE32DEE_gshared (Enumerator_t3F22A2E619D662922F996C766D960AF285909004 * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.NamedValue>::get_Current()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  Enumerator_get_Current_m1DAC585732F0CB8AA13B33E1015A60D953E69FA8_gshared_inline (Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.NamedValue>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_mF54BF589CE1C156DA753373FCEBC3D850B80CC01_gshared (Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1/Enumerator<System.Object>::get_Current()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject * Enumerator_get_Current_m9C4EBBD2108B51885E750F927D7936290C8E20EE_gshared_inline (Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.List`1/Enumerator<System.Object>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_m2E56233762839CE55C67E00AC8DD3D4D3F6C0DF0_gshared (Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1/Enumerator<UnityEngine.Tilemaps.GridInformation/GridInformationKey>::get_Current()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  Enumerator_get_Current_mCD38ED89C9598655A9824EA42E516F0F7822EF78_gshared_inline (Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.List`1/Enumerator<UnityEngine.Tilemaps.GridInformation/GridInformationKey>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_mD158898776983980E4A8FCD4C559022D608E854D_gshared (Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>::get_Current()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  Enumerator_get_Current_mA2F40010AB5E3D0B7854E66406831953599A7D11_gshared_inline (Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_mBA2E1218E317D2B755FE5DBCDD554A8D758EE9F9_gshared (Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F * __this, const RuntimeMethod* method);

// !0 System.Collections.Generic.List`1/Enumerator<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>>::get_Current()
inline KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  Enumerator_get_Current_m60A7BC98ACC855A940897C0FDD226381D3E17BCD_inline (Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF * __this, const RuntimeMethod* method)
{
	return ((  KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  (*) (Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF *, const RuntimeMethod*))Enumerator_get_Current_m60A7BC98ACC855A940897C0FDD226381D3E17BCD_gshared_inline)(__this, method);
}
// System.Boolean System.Collections.Generic.List`1/Enumerator<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>>::MoveNext()
inline bool Enumerator_MoveNext_m03E8649EAA3C72543BF00144DA904F2F391CB46B (Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF *, const RuntimeMethod*))Enumerator_MoveNext_m03E8649EAA3C72543BF00144DA904F2F391CB46B_gshared)(__this, method);
}
// !0 System.Collections.Generic.List`1/Enumerator<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex>::get_Current()
inline ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  Enumerator_get_Current_mB9DED66EBA82669AB83832B40F60E1710B5179B4_inline (Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 * __this, const RuntimeMethod* method)
{
	return ((  ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  (*) (Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *, const RuntimeMethod*))Enumerator_get_Current_mB9DED66EBA82669AB83832B40F60E1710B5179B4_gshared_inline)(__this, method);
}
// System.Boolean System.Collections.Generic.List`1/Enumerator<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex>::MoveNext()
inline bool Enumerator_MoveNext_mACDC401A875ECF83AEF9477068CDF02545A1D997 (Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *, const RuntimeMethod*))Enumerator_MoveNext_mACDC401A875ECF83AEF9477068CDF02545A1D997_gshared)(__this, method);
}
// !0 System.Collections.Generic.List`1/Enumerator<System.Int32>::get_Current()
inline int32_t Enumerator_get_Current_m6BBD624C51F7E20D347FE5894A6ECA94B8011181_inline (Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C *, const RuntimeMethod*))Enumerator_get_Current_m6BBD624C51F7E20D347FE5894A6ECA94B8011181_gshared_inline)(__this, method);
}
// System.Boolean System.Collections.Generic.List`1/Enumerator<System.Int32>::MoveNext()
inline bool Enumerator_MoveNext_m40FD166B6757334A2BBCF67238EFDF70D727A4A6 (Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C *, const RuntimeMethod*))Enumerator_MoveNext_m40FD166B6757334A2BBCF67238EFDF70D727A4A6_gshared)(__this, method);
}
// !0 System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.InternedString>::get_Current()
inline InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  Enumerator_get_Current_mDFC8852F498B3A27BD601B8B3D1AAD9EFD96ED78_inline (Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 * __this, const RuntimeMethod* method)
{
	return ((  InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  (*) (Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 *, const RuntimeMethod*))Enumerator_get_Current_mDFC8852F498B3A27BD601B8B3D1AAD9EFD96ED78_gshared_inline)(__this, method);
}
// System.Boolean System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.InternedString>::MoveNext()
inline bool Enumerator_MoveNext_mC85A573A7B1E29F62C95F0841F4368217B0FC647 (Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 *, const RuntimeMethod*))Enumerator_MoveNext_mC85A573A7B1E29F62C95F0841F4368217B0FC647_gshared)(__this, method);
}
// !0 System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.NameAndParameters>::get_Current()
inline NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  Enumerator_get_Current_mDA65875F4B6726349744D3FDA9F8F3D655CF843E_inline (Enumerator_t3F22A2E619D662922F996C766D960AF285909004 * __this, const RuntimeMethod* method)
{
	return ((  NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  (*) (Enumerator_t3F22A2E619D662922F996C766D960AF285909004 *, const RuntimeMethod*))Enumerator_get_Current_mDA65875F4B6726349744D3FDA9F8F3D655CF843E_gshared_inline)(__this, method);
}
// System.Boolean System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.NameAndParameters>::MoveNext()
inline bool Enumerator_MoveNext_m8C47DD84EE474A11C083B071DE1C5AF1AAE32DEE (Enumerator_t3F22A2E619D662922F996C766D960AF285909004 * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (Enumerator_t3F22A2E619D662922F996C766D960AF285909004 *, const RuntimeMethod*))Enumerator_MoveNext_m8C47DD84EE474A11C083B071DE1C5AF1AAE32DEE_gshared)(__this, method);
}
// !0 System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.NamedValue>::get_Current()
inline NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  Enumerator_get_Current_m1DAC585732F0CB8AA13B33E1015A60D953E69FA8_inline (Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 * __this, const RuntimeMethod* method)
{
	return ((  NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  (*) (Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 *, const RuntimeMethod*))Enumerator_get_Current_m1DAC585732F0CB8AA13B33E1015A60D953E69FA8_gshared_inline)(__this, method);
}
// System.Boolean System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.NamedValue>::MoveNext()
inline bool Enumerator_MoveNext_mF54BF589CE1C156DA753373FCEBC3D850B80CC01 (Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 *, const RuntimeMethod*))Enumerator_MoveNext_mF54BF589CE1C156DA753373FCEBC3D850B80CC01_gshared)(__this, method);
}
// !0 System.Collections.Generic.List`1/Enumerator<System.Object>::get_Current()
inline RuntimeObject * Enumerator_get_Current_m9C4EBBD2108B51885E750F927D7936290C8E20EE_inline (Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 * __this, const RuntimeMethod* method)
{
	return ((  RuntimeObject * (*) (Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 *, const RuntimeMethod*))Enumerator_get_Current_m9C4EBBD2108B51885E750F927D7936290C8E20EE_gshared_inline)(__this, method);
}
// System.Boolean System.Collections.Generic.List`1/Enumerator<System.Object>::MoveNext()
inline bool Enumerator_MoveNext_m2E56233762839CE55C67E00AC8DD3D4D3F6C0DF0 (Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 *, const RuntimeMethod*))Enumerator_MoveNext_m2E56233762839CE55C67E00AC8DD3D4D3F6C0DF0_gshared)(__this, method);
}
// !0 System.Collections.Generic.List`1/Enumerator<UnityEngine.Tilemaps.GridInformation/GridInformationKey>::get_Current()
inline GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  Enumerator_get_Current_mCD38ED89C9598655A9824EA42E516F0F7822EF78_inline (Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 * __this, const RuntimeMethod* method)
{
	return ((  GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  (*) (Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 *, const RuntimeMethod*))Enumerator_get_Current_mCD38ED89C9598655A9824EA42E516F0F7822EF78_gshared_inline)(__this, method);
}
// System.Boolean System.Collections.Generic.List`1/Enumerator<UnityEngine.Tilemaps.GridInformation/GridInformationKey>::MoveNext()
inline bool Enumerator_MoveNext_mD158898776983980E4A8FCD4C559022D608E854D (Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 *, const RuntimeMethod*))Enumerator_MoveNext_mD158898776983980E4A8FCD4C559022D608E854D_gshared)(__this, method);
}
// !0 System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>::get_Current()
inline JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  Enumerator_get_Current_mA2F40010AB5E3D0B7854E66406831953599A7D11_inline (Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F * __this, const RuntimeMethod* method)
{
	return ((  JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  (*) (Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F *, const RuntimeMethod*))Enumerator_get_Current_mA2F40010AB5E3D0B7854E66406831953599A7D11_gshared_inline)(__this, method);
}
// System.Boolean System.Collections.Generic.List`1/Enumerator<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>::MoveNext()
inline bool Enumerator_MoveNext_mBA2E1218E317D2B755FE5DBCDD554A8D758EE9F9 (Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F *, const RuntimeMethod*))Enumerator_MoveNext_mBA2E1218E317D2B755FE5DBCDD554A8D758EE9F9_gshared)(__this, method);
}
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectEnumerableIterator`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>::.ctor(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectEnumerableIterator_2__ctor_m49027F140F917213AC0AA108C395CFFF553F560E_gshared (WhereSelectEnumerableIterator_2_t2F210EE4B2CBE5E1F6A887A375170AD9D3066C6C * __this, RuntimeObject* ___source0, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate1, Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		((  void (*) (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		RuntimeObject* L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectEnumerableIterator`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 * WhereSelectEnumerableIterator_2_Clone_m7B342B2B8D08E61E5E1F7E95D36AE719FD608A5C_gshared (WhereSelectEnumerableIterator_2_t2F210EE4B2CBE5E1F6A887A375170AD9D3066C6C * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject* L_0 = (RuntimeObject*)__this->get_source_3();
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_1 = (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)__this->get_predicate_4();
		Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 * L_2 = (Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 *)__this->get_selector_5();
		WhereSelectEnumerableIterator_2_t2F210EE4B2CBE5E1F6A887A375170AD9D3066C6C * L_3 = (WhereSelectEnumerableIterator_2_t2F210EE4B2CBE5E1F6A887A375170AD9D3066C6C *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectEnumerableIterator_2_t2F210EE4B2CBE5E1F6A887A375170AD9D3066C6C *, RuntimeObject*, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (RuntimeObject*)L_0, (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_1, (Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)L_3;
	}
}
// System.Void System.Linq.Enumerable/WhereSelectEnumerableIterator`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectEnumerableIterator_2_Dispose_m00A801192BD60799B10EB7BD843E504A874EDFC1_gshared (WhereSelectEnumerableIterator_2_t2F210EE4B2CBE5E1F6A887A375170AD9D3066C6C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IDisposable_t099785737FC6A1E3699919A94109383715A8D807_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject* L_0 = (RuntimeObject*)__this->get_enumerator_6();
		if (!L_0)
		{
			goto IL_0013;
		}
	}
	{
		RuntimeObject* L_1 = (RuntimeObject*)__this->get_enumerator_6();
		NullCheck((RuntimeObject*)L_1);
		InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t099785737FC6A1E3699919A94109383715A8D807_il2cpp_TypeInfo_var, (RuntimeObject*)L_1);
	}

IL_0013:
	{
		__this->set_enumerator_6((RuntimeObject*)NULL);
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		((  void (*) (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		return;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectEnumerableIterator`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectEnumerableIterator_2_MoveNext_mABE92B17DF39742A2A5067DB7C203D61CC3E0D4D_gshared (WhereSelectEnumerableIterator_2_t2F210EE4B2CBE5E1F6A887A375170AD9D3066C6C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IEnumerator_t5956F3AFB7ECF1117E3BC5890E7FC7B7F7A04105_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	RuntimeObject * V_1 = NULL;
	{
		int32_t L_0 = (int32_t)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		RuntimeObject* L_3 = (RuntimeObject*)__this->get_source_3();
		NullCheck((RuntimeObject*)L_3);
		RuntimeObject* L_4;
		L_4 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<!0> System.Collections.Generic.IEnumerable`1<System.Object>::GetEnumerator() */, IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 5), (RuntimeObject*)L_3);
		__this->set_enumerator_6(L_4);
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		RuntimeObject* L_5 = (RuntimeObject*)__this->get_enumerator_6();
		NullCheck((RuntimeObject*)L_5);
		RuntimeObject * L_6;
		L_6 = InterfaceFuncInvoker0< RuntimeObject * >::Invoke(0 /* !0 System.Collections.Generic.IEnumerator`1<System.Object>::get_Current() */, IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 6), (RuntimeObject*)L_5);
		V_1 = (RuntimeObject *)L_6;
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_7 = (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_8 = (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)__this->get_predicate_4();
		RuntimeObject * L_9 = V_1;
		NullCheck((Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, RuntimeObject *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_8, (RuntimeObject *)L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 * L_11 = (Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 *)__this->get_selector_5();
		RuntimeObject * L_12 = V_1;
		NullCheck((Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 *)L_11);
		InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  L_13;
		L_13 = ((  InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  (*) (Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 *, RuntimeObject *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8)->methodPointer)((Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 *)L_11, (RuntimeObject *)L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		RuntimeObject* L_14 = (RuntimeObject*)__this->get_enumerator_6();
		NullCheck((RuntimeObject*)L_14);
		bool L_15;
		L_15 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t5956F3AFB7ECF1117E3BC5890E7FC7B7F7A04105_il2cpp_TypeInfo_var, (RuntimeObject*)L_14);
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<UnityEngine.InputSystem.Utilities.InternedString>::Dispose() */, (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectEnumerableIterator`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectEnumerableIterator_2_Where_mED2EE354F502C01490F4147D06191F9E107D451D_gshared (WhereSelectEnumerableIterator_2_t2F210EE4B2CBE5E1F6A887A375170AD9D3066C6C * __this, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 * L_1 = (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 9));
		((  void (*) (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *, RuntimeObject*, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 10)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 10));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectEnumerableIterator`2<System.Object,System.Object>::.ctor(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectEnumerableIterator_2__ctor_m6DFD3E949A8FA5121F520D501B78C17E84EBDFAC_gshared (WhereSelectEnumerableIterator_2_tDAA8BFBEA68F81670F3F51C6200EBD26D7A8FBAB * __this, RuntimeObject* ___source0, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate1, Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		((  void (*) (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		RuntimeObject* L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectEnumerableIterator`2<System.Object,System.Object>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 * WhereSelectEnumerableIterator_2_Clone_mD5F17A02281E6D1529D117CFF2E0F8C347D1B13F_gshared (WhereSelectEnumerableIterator_2_tDAA8BFBEA68F81670F3F51C6200EBD26D7A8FBAB * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject* L_0 = (RuntimeObject*)__this->get_source_3();
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_1 = (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)__this->get_predicate_4();
		Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 * L_2 = (Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 *)__this->get_selector_5();
		WhereSelectEnumerableIterator_2_tDAA8BFBEA68F81670F3F51C6200EBD26D7A8FBAB * L_3 = (WhereSelectEnumerableIterator_2_tDAA8BFBEA68F81670F3F51C6200EBD26D7A8FBAB *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectEnumerableIterator_2_tDAA8BFBEA68F81670F3F51C6200EBD26D7A8FBAB *, RuntimeObject*, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (RuntimeObject*)L_0, (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_1, (Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)L_3;
	}
}
// System.Void System.Linq.Enumerable/WhereSelectEnumerableIterator`2<System.Object,System.Object>::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectEnumerableIterator_2_Dispose_mAA70577DEF67CEC98FE677984AE2175B7D4E4D00_gshared (WhereSelectEnumerableIterator_2_tDAA8BFBEA68F81670F3F51C6200EBD26D7A8FBAB * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IDisposable_t099785737FC6A1E3699919A94109383715A8D807_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject* L_0 = (RuntimeObject*)__this->get_enumerator_6();
		if (!L_0)
		{
			goto IL_0013;
		}
	}
	{
		RuntimeObject* L_1 = (RuntimeObject*)__this->get_enumerator_6();
		NullCheck((RuntimeObject*)L_1);
		InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t099785737FC6A1E3699919A94109383715A8D807_il2cpp_TypeInfo_var, (RuntimeObject*)L_1);
	}

IL_0013:
	{
		__this->set_enumerator_6((RuntimeObject*)NULL);
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		((  void (*) (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		return;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectEnumerableIterator`2<System.Object,System.Object>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectEnumerableIterator_2_MoveNext_m95AEE737A22EFFFE6557F448BF5AFCC6241D0BD7_gshared (WhereSelectEnumerableIterator_2_tDAA8BFBEA68F81670F3F51C6200EBD26D7A8FBAB * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IEnumerator_t5956F3AFB7ECF1117E3BC5890E7FC7B7F7A04105_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	RuntimeObject * V_1 = NULL;
	{
		int32_t L_0 = (int32_t)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		RuntimeObject* L_3 = (RuntimeObject*)__this->get_source_3();
		NullCheck((RuntimeObject*)L_3);
		RuntimeObject* L_4;
		L_4 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<!0> System.Collections.Generic.IEnumerable`1<System.Object>::GetEnumerator() */, IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 5), (RuntimeObject*)L_3);
		__this->set_enumerator_6(L_4);
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		RuntimeObject* L_5 = (RuntimeObject*)__this->get_enumerator_6();
		NullCheck((RuntimeObject*)L_5);
		RuntimeObject * L_6;
		L_6 = InterfaceFuncInvoker0< RuntimeObject * >::Invoke(0 /* !0 System.Collections.Generic.IEnumerator`1<System.Object>::get_Current() */, IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 6), (RuntimeObject*)L_5);
		V_1 = (RuntimeObject *)L_6;
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_7 = (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_8 = (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)__this->get_predicate_4();
		RuntimeObject * L_9 = V_1;
		NullCheck((Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, RuntimeObject *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_8, (RuntimeObject *)L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 * L_11 = (Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 *)__this->get_selector_5();
		RuntimeObject * L_12 = V_1;
		NullCheck((Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 *)L_11);
		RuntimeObject * L_13;
		L_13 = ((  RuntimeObject * (*) (Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 *, RuntimeObject *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8)->methodPointer)((Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 *)L_11, (RuntimeObject *)L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		RuntimeObject* L_14 = (RuntimeObject*)__this->get_enumerator_6();
		NullCheck((RuntimeObject*)L_14);
		bool L_15;
		L_15 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t5956F3AFB7ECF1117E3BC5890E7FC7B7F7A04105_il2cpp_TypeInfo_var, (RuntimeObject*)L_14);
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<System.Object>::Dispose() */, (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectEnumerableIterator`2<System.Object,System.Object>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectEnumerableIterator_2_Where_m72A38A8170E8B837F5C090642BE08E3845A8EB37_gshared (WhereSelectEnumerableIterator_2_tDAA8BFBEA68F81670F3F51C6200EBD26D7A8FBAB * __this, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 * L_1 = (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 9));
		((  void (*) (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *, RuntimeObject*, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 10)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 10));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,UnityEngine.Vector3Int>::.ctor(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectEnumerableIterator_2__ctor_m6007B55A0060C2325F42174A3EC0F22E9424E42F_gshared (WhereSelectEnumerableIterator_2_tE7217C6271607DE91640E1C70700D8EAC5C79632 * __this, RuntimeObject* ___source0, Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * ___predicate1, Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this);
		((  void (*) (Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		RuntimeObject* L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,UnityEngine.Vector3Int>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 * WhereSelectEnumerableIterator_2_Clone_mE82E29936C72551FF6074FD3CEE579672595C23C_gshared (WhereSelectEnumerableIterator_2_tE7217C6271607DE91640E1C70700D8EAC5C79632 * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject* L_0 = (RuntimeObject*)__this->get_source_3();
		Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * L_1 = (Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *)__this->get_predicate_4();
		Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A * L_2 = (Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A *)__this->get_selector_5();
		WhereSelectEnumerableIterator_2_tE7217C6271607DE91640E1C70700D8EAC5C79632 * L_3 = (WhereSelectEnumerableIterator_2_tE7217C6271607DE91640E1C70700D8EAC5C79632 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectEnumerableIterator_2_tE7217C6271607DE91640E1C70700D8EAC5C79632 *, RuntimeObject*, Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *, Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (RuntimeObject*)L_0, (Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *)L_1, (Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)L_3;
	}
}
// System.Void System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,UnityEngine.Vector3Int>::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectEnumerableIterator_2_Dispose_m238DC2E5288B768EAC224282161C4E87137E6EC2_gshared (WhereSelectEnumerableIterator_2_tE7217C6271607DE91640E1C70700D8EAC5C79632 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IDisposable_t099785737FC6A1E3699919A94109383715A8D807_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject* L_0 = (RuntimeObject*)__this->get_enumerator_6();
		if (!L_0)
		{
			goto IL_0013;
		}
	}
	{
		RuntimeObject* L_1 = (RuntimeObject*)__this->get_enumerator_6();
		NullCheck((RuntimeObject*)L_1);
		InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t099785737FC6A1E3699919A94109383715A8D807_il2cpp_TypeInfo_var, (RuntimeObject*)L_1);
	}

IL_0013:
	{
		__this->set_enumerator_6((RuntimeObject*)NULL);
		NullCheck((Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this);
		((  void (*) (Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		return;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,UnityEngine.Vector3Int>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectEnumerableIterator_2_MoveNext_mA7EC71F70108C83DB95B0A167C16764AD4CD91FA_gshared (WhereSelectEnumerableIterator_2_tE7217C6271607DE91640E1C70700D8EAC5C79632 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IEnumerator_t5956F3AFB7ECF1117E3BC5890E7FC7B7F7A04105_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		RuntimeObject* L_3 = (RuntimeObject*)__this->get_source_3();
		NullCheck((RuntimeObject*)L_3);
		RuntimeObject* L_4;
		L_4 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<!0> System.Collections.Generic.IEnumerable`1<UnityEngine.Tilemaps.GridInformation/GridInformationKey>::GetEnumerator() */, IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 5), (RuntimeObject*)L_3);
		__this->set_enumerator_6(L_4);
		((Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		RuntimeObject* L_5 = (RuntimeObject*)__this->get_enumerator_6();
		NullCheck((RuntimeObject*)L_5);
		GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  L_6;
		L_6 = InterfaceFuncInvoker0< GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  >::Invoke(0 /* !0 System.Collections.Generic.IEnumerator`1<UnityEngine.Tilemaps.GridInformation/GridInformationKey>::get_Current() */, IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 6), (RuntimeObject*)L_5);
		V_1 = (GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941 )L_6;
		Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * L_7 = (Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * L_8 = (Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *)__this->get_predicate_4();
		GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  L_9 = V_1;
		NullCheck((Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *, GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *)L_8, (GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941 )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A * L_11 = (Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A *)__this->get_selector_5();
		GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  L_12 = V_1;
		NullCheck((Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A *)L_11);
		Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  L_13;
		L_13 = ((  Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  (*) (Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A *, GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8)->methodPointer)((Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A *)L_11, (GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941 )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		((Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		RuntimeObject* L_14 = (RuntimeObject*)__this->get_enumerator_6();
		NullCheck((RuntimeObject*)L_14);
		bool L_15;
		L_15 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t5956F3AFB7ECF1117E3BC5890E7FC7B7F7A04105_il2cpp_TypeInfo_var, (RuntimeObject*)L_14);
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<UnityEngine.Vector3Int>::Dispose() */, (Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,UnityEngine.Vector3Int>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectEnumerableIterator_2_Where_m3AA4B190B0FF248F09D813035A75D203CB5DE266_gshared (WhereSelectEnumerableIterator_2_tE7217C6271607DE91640E1C70700D8EAC5C79632 * __this, Func_2_tB3AD6A340F9ED708E8459C7912C86F7504161867 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_tB3AD6A340F9ED708E8459C7912C86F7504161867 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_tD2CF2E617E3FFF17EDE787C942514D3A3E76A8A2 * L_1 = (WhereEnumerableIterator_1_tD2CF2E617E3FFF17EDE787C942514D3A3E76A8A2 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 9));
		((  void (*) (WhereEnumerableIterator_1_tD2CF2E617E3FFF17EDE787C942514D3A3E76A8A2 *, RuntimeObject*, Func_2_tB3AD6A340F9ED708E8459C7912C86F7504161867 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 10)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_tB3AD6A340F9ED708E8459C7912C86F7504161867 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 10));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,UnityEngine.InputSystem.Utilities.InternedString>::.ctor(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectEnumerableIterator_2__ctor_mB6D0D91AC24732FEC2328B65056DAE1D9C35FFD8_gshared (WhereSelectEnumerableIterator_2_t2EF803FE6198D12622AB2AC13CC544D3382A753D * __this, RuntimeObject* ___source0, Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * ___predicate1, Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		((  void (*) (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		RuntimeObject* L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,UnityEngine.InputSystem.Utilities.InternedString>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 * WhereSelectEnumerableIterator_2_Clone_m81B2D5B1BAAD761083BD05729850199B529A3805_gshared (WhereSelectEnumerableIterator_2_t2EF803FE6198D12622AB2AC13CC544D3382A753D * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject* L_0 = (RuntimeObject*)__this->get_source_3();
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_1 = (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)__this->get_predicate_4();
		Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C * L_2 = (Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C *)__this->get_selector_5();
		WhereSelectEnumerableIterator_2_t2EF803FE6198D12622AB2AC13CC544D3382A753D * L_3 = (WhereSelectEnumerableIterator_2_t2EF803FE6198D12622AB2AC13CC544D3382A753D *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectEnumerableIterator_2_t2EF803FE6198D12622AB2AC13CC544D3382A753D *, RuntimeObject*, Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *, Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (RuntimeObject*)L_0, (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)L_1, (Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)L_3;
	}
}
// System.Void System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,UnityEngine.InputSystem.Utilities.InternedString>::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectEnumerableIterator_2_Dispose_mF74252F7F365B419915DE02801B87B7AFFA19886_gshared (WhereSelectEnumerableIterator_2_t2EF803FE6198D12622AB2AC13CC544D3382A753D * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IDisposable_t099785737FC6A1E3699919A94109383715A8D807_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject* L_0 = (RuntimeObject*)__this->get_enumerator_6();
		if (!L_0)
		{
			goto IL_0013;
		}
	}
	{
		RuntimeObject* L_1 = (RuntimeObject*)__this->get_enumerator_6();
		NullCheck((RuntimeObject*)L_1);
		InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t099785737FC6A1E3699919A94109383715A8D807_il2cpp_TypeInfo_var, (RuntimeObject*)L_1);
	}

IL_0013:
	{
		__this->set_enumerator_6((RuntimeObject*)NULL);
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		((  void (*) (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		return;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,UnityEngine.InputSystem.Utilities.InternedString>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectEnumerableIterator_2_MoveNext_mD1EEB5932A6847F37B588F7431BB24E5F4B85A23_gshared (WhereSelectEnumerableIterator_2_t2EF803FE6198D12622AB2AC13CC544D3382A753D * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IEnumerator_t5956F3AFB7ECF1117E3BC5890E7FC7B7F7A04105_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		RuntimeObject* L_3 = (RuntimeObject*)__this->get_source_3();
		NullCheck((RuntimeObject*)L_3);
		RuntimeObject* L_4;
		L_4 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<!0> System.Collections.Generic.IEnumerable`1<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>::GetEnumerator() */, IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 5), (RuntimeObject*)L_3);
		__this->set_enumerator_6(L_4);
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		RuntimeObject* L_5 = (RuntimeObject*)__this->get_enumerator_6();
		NullCheck((RuntimeObject*)L_5);
		JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  L_6;
		L_6 = InterfaceFuncInvoker0< JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  >::Invoke(0 /* !0 System.Collections.Generic.IEnumerator`1<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>::get_Current() */, IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 6), (RuntimeObject*)L_5);
		V_1 = (JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE )L_6;
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_7 = (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_8 = (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)__this->get_predicate_4();
		JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  L_9 = V_1;
		NullCheck((Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *, JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)L_8, (JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C * L_11 = (Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C *)__this->get_selector_5();
		JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  L_12 = V_1;
		NullCheck((Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C *)L_11);
		InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  L_13;
		L_13 = ((  InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  (*) (Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C *, JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8)->methodPointer)((Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C *)L_11, (JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		RuntimeObject* L_14 = (RuntimeObject*)__this->get_enumerator_6();
		NullCheck((RuntimeObject*)L_14);
		bool L_15;
		L_15 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t5956F3AFB7ECF1117E3BC5890E7FC7B7F7A04105_il2cpp_TypeInfo_var, (RuntimeObject*)L_14);
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<UnityEngine.InputSystem.Utilities.InternedString>::Dispose() */, (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,UnityEngine.InputSystem.Utilities.InternedString>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectEnumerableIterator_2_Where_mB1849CB561C84BCC1519B1CE09B9B804002DF1CD_gshared (WhereSelectEnumerableIterator_2_t2EF803FE6198D12622AB2AC13CC544D3382A753D * __this, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 * L_1 = (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 9));
		((  void (*) (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *, RuntimeObject*, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 10)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 10));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Object>::.ctor(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectEnumerableIterator_2__ctor_m045E9D09C30D35F2E0DD762E94894DF48093F84E_gshared (WhereSelectEnumerableIterator_2_tD966222D4DA5DCD2B3C06136FF40DAEF9F631D37 * __this, RuntimeObject* ___source0, Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * ___predicate1, Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		((  void (*) (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		RuntimeObject* L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Object>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 * WhereSelectEnumerableIterator_2_Clone_mDF68CD07B0C0C99DECFA50B8657E6F6C8A17F29F_gshared (WhereSelectEnumerableIterator_2_tD966222D4DA5DCD2B3C06136FF40DAEF9F631D37 * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject* L_0 = (RuntimeObject*)__this->get_source_3();
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_1 = (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)__this->get_predicate_4();
		Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 * L_2 = (Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 *)__this->get_selector_5();
		WhereSelectEnumerableIterator_2_tD966222D4DA5DCD2B3C06136FF40DAEF9F631D37 * L_3 = (WhereSelectEnumerableIterator_2_tD966222D4DA5DCD2B3C06136FF40DAEF9F631D37 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectEnumerableIterator_2_tD966222D4DA5DCD2B3C06136FF40DAEF9F631D37 *, RuntimeObject*, Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *, Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (RuntimeObject*)L_0, (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)L_1, (Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)L_3;
	}
}
// System.Void System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Object>::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectEnumerableIterator_2_Dispose_mFE44FA36C2E159D0C5F29FBF28BD5C1173C5EBB2_gshared (WhereSelectEnumerableIterator_2_tD966222D4DA5DCD2B3C06136FF40DAEF9F631D37 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IDisposable_t099785737FC6A1E3699919A94109383715A8D807_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject* L_0 = (RuntimeObject*)__this->get_enumerator_6();
		if (!L_0)
		{
			goto IL_0013;
		}
	}
	{
		RuntimeObject* L_1 = (RuntimeObject*)__this->get_enumerator_6();
		NullCheck((RuntimeObject*)L_1);
		InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t099785737FC6A1E3699919A94109383715A8D807_il2cpp_TypeInfo_var, (RuntimeObject*)L_1);
	}

IL_0013:
	{
		__this->set_enumerator_6((RuntimeObject*)NULL);
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		((  void (*) (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		return;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Object>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectEnumerableIterator_2_MoveNext_m98ED5C55F7A253F08A06FCF09D8E7AC439E82C14_gshared (WhereSelectEnumerableIterator_2_tD966222D4DA5DCD2B3C06136FF40DAEF9F631D37 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IEnumerator_t5956F3AFB7ECF1117E3BC5890E7FC7B7F7A04105_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		RuntimeObject* L_3 = (RuntimeObject*)__this->get_source_3();
		NullCheck((RuntimeObject*)L_3);
		RuntimeObject* L_4;
		L_4 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<!0> System.Collections.Generic.IEnumerable`1<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>::GetEnumerator() */, IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 5), (RuntimeObject*)L_3);
		__this->set_enumerator_6(L_4);
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		RuntimeObject* L_5 = (RuntimeObject*)__this->get_enumerator_6();
		NullCheck((RuntimeObject*)L_5);
		JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  L_6;
		L_6 = InterfaceFuncInvoker0< JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  >::Invoke(0 /* !0 System.Collections.Generic.IEnumerator`1<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>::get_Current() */, IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 6), (RuntimeObject*)L_5);
		V_1 = (JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE )L_6;
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_7 = (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_8 = (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)__this->get_predicate_4();
		JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  L_9 = V_1;
		NullCheck((Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *, JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)L_8, (JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 * L_11 = (Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 *)__this->get_selector_5();
		JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  L_12 = V_1;
		NullCheck((Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 *)L_11);
		RuntimeObject * L_13;
		L_13 = ((  RuntimeObject * (*) (Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 *, JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8)->methodPointer)((Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 *)L_11, (JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		RuntimeObject* L_14 = (RuntimeObject*)__this->get_enumerator_6();
		NullCheck((RuntimeObject*)L_14);
		bool L_15;
		L_15 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t5956F3AFB7ECF1117E3BC5890E7FC7B7F7A04105_il2cpp_TypeInfo_var, (RuntimeObject*)L_14);
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<System.Object>::Dispose() */, (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectEnumerableIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Object>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectEnumerableIterator_2_Where_m45BB6CB14275D166AFAFCFD0F8554DB8A8A8C83D_gshared (WhereSelectEnumerableIterator_2_tD966222D4DA5DCD2B3C06136FF40DAEF9F631D37 * __this, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 * L_1 = (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 9));
		((  void (*) (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *, RuntimeObject*, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 10)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 10));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,UnityEngine.InputSystem.Utilities.InternedString>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_m4CD14F0299BCCB3F8D4A6CA9E5F02065F23FC338_gshared (WhereSelectListIterator_2_t252DD2ECAA2598C5A96C9D96F81661DB7E55BBD5 * __this, List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * ___source0, Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * ___predicate1, Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9 * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		((  void (*) (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9 * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,UnityEngine.InputSystem.Utilities.InternedString>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 * WhereSelectListIterator_2_Clone_m9423E8C439C2B9AEE0BDAA2FAFF621579E039F72_gshared (WhereSelectListIterator_2_t252DD2ECAA2598C5A96C9D96F81661DB7E55BBD5 * __this, const RuntimeMethod* method)
{
	{
		List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * L_0 = (List_1_tA904E5F65F2154445E86287BD8613DCB85340206 *)__this->get_source_3();
		Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * L_1 = (Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *)__this->get_predicate_4();
		Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9 * L_2 = (Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9 *)__this->get_selector_5();
		WhereSelectListIterator_2_t252DD2ECAA2598C5A96C9D96F81661DB7E55BBD5 * L_3 = (WhereSelectListIterator_2_t252DD2ECAA2598C5A96C9D96F81661DB7E55BBD5 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_t252DD2ECAA2598C5A96C9D96F81661DB7E55BBD5 *, List_1_tA904E5F65F2154445E86287BD8613DCB85340206 *, Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *, Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_tA904E5F65F2154445E86287BD8613DCB85340206 *)L_0, (Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *)L_1, (Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9 *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,UnityEngine.InputSystem.Utilities.InternedString>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_m895AE7F14963E8C979570AE5ADAAA1616B4EBB8C_gshared (WhereSelectListIterator_2_t252DD2ECAA2598C5A96C9D96F81661DB7E55BBD5 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * L_3 = (List_1_tA904E5F65F2154445E86287BD8613DCB85340206 *)__this->get_source_3();
		NullCheck((List_1_tA904E5F65F2154445E86287BD8613DCB85340206 *)L_3);
		Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF  L_4;
		L_4 = ((  Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF  (*) (List_1_tA904E5F65F2154445E86287BD8613DCB85340206 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_tA904E5F65F2154445E86287BD8613DCB85340206 *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF * L_5 = (Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF *)__this->get_address_of_enumerator_6();
		KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  L_6;
		L_6 = Enumerator_get_Current_m60A7BC98ACC855A940897C0FDD226381D3E17BCD_inline((Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF *)(Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4 )L_6;
		Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * L_7 = (Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * L_8 = (Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *)__this->get_predicate_4();
		KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  L_9 = V_1;
		NullCheck((Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *, KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *)L_8, (KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4 )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9 * L_11 = (Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9 *)__this->get_selector_5();
		KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  L_12 = V_1;
		NullCheck((Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9 *)L_11);
		InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  L_13;
		L_13 = ((  InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  (*) (Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9 *, KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_t1CBCB7E0DDCD522B716A3CD37702FE3C671293C9 *)L_11, (KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4 )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF * L_14 = (Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_m03E8649EAA3C72543BF00144DA904F2F391CB46B((Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF *)(Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<UnityEngine.InputSystem.Utilities.InternedString>::Dispose() */, (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,UnityEngine.InputSystem.Utilities.InternedString>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_mEAE30C59ABD016E8FA03346860714029E4E72E53_gshared (WhereSelectListIterator_2_t252DD2ECAA2598C5A96C9D96F81661DB7E55BBD5 * __this, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 * L_1 = (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *, RuntimeObject*, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,System.Object>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_m7FE23322429773D8D4862774459AA8DD474387F0_gshared (WhereSelectListIterator_2_tEC5F4A5D3B70CD5D957FD6B731AFBD8925501168 * __this, List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * ___source0, Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * ___predicate1, Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		((  void (*) (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,System.Object>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 * WhereSelectListIterator_2_Clone_m4530C9795BD19E4D6D250430D2B9792BD268C2DC_gshared (WhereSelectListIterator_2_tEC5F4A5D3B70CD5D957FD6B731AFBD8925501168 * __this, const RuntimeMethod* method)
{
	{
		List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * L_0 = (List_1_tA904E5F65F2154445E86287BD8613DCB85340206 *)__this->get_source_3();
		Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * L_1 = (Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *)__this->get_predicate_4();
		Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE * L_2 = (Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE *)__this->get_selector_5();
		WhereSelectListIterator_2_tEC5F4A5D3B70CD5D957FD6B731AFBD8925501168 * L_3 = (WhereSelectListIterator_2_tEC5F4A5D3B70CD5D957FD6B731AFBD8925501168 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_tEC5F4A5D3B70CD5D957FD6B731AFBD8925501168 *, List_1_tA904E5F65F2154445E86287BD8613DCB85340206 *, Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *, Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_tA904E5F65F2154445E86287BD8613DCB85340206 *)L_0, (Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *)L_1, (Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,System.Object>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_mC1297F9D6461ABF31F89349C5C941B9DD8744A6E_gshared (WhereSelectListIterator_2_tEC5F4A5D3B70CD5D957FD6B731AFBD8925501168 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_tA904E5F65F2154445E86287BD8613DCB85340206 * L_3 = (List_1_tA904E5F65F2154445E86287BD8613DCB85340206 *)__this->get_source_3();
		NullCheck((List_1_tA904E5F65F2154445E86287BD8613DCB85340206 *)L_3);
		Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF  L_4;
		L_4 = ((  Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF  (*) (List_1_tA904E5F65F2154445E86287BD8613DCB85340206 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_tA904E5F65F2154445E86287BD8613DCB85340206 *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF * L_5 = (Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF *)__this->get_address_of_enumerator_6();
		KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  L_6;
		L_6 = Enumerator_get_Current_m60A7BC98ACC855A940897C0FDD226381D3E17BCD_inline((Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF *)(Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4 )L_6;
		Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * L_7 = (Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 * L_8 = (Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *)__this->get_predicate_4();
		KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  L_9 = V_1;
		NullCheck((Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *, KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_t578863D9F9AA89630C4C6ABD80C3D0BE07C2F863 *)L_8, (KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4 )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE * L_11 = (Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE *)__this->get_selector_5();
		KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  L_12 = V_1;
		NullCheck((Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE *)L_11);
		RuntimeObject * L_13;
		L_13 = ((  RuntimeObject * (*) (Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE *, KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_tAEA61AE786D1A92198831769EBB5D30C86CFFFEE *)L_11, (KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4 )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF * L_14 = (Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_m03E8649EAA3C72543BF00144DA904F2F391CB46B((Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF *)(Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<System.Object>::Dispose() */, (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<System.Collections.Generic.KeyValuePair`2<System.Object,UnityEngine.InputSystem.Utilities.JsonParser/JsonValue>,System.Object>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_m96CE7C4BC3488B8B7073B4C20B982588B8F9F652_gshared (WhereSelectListIterator_2_tEC5F4A5D3B70CD5D957FD6B731AFBD8925501168 * __this, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 * L_1 = (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *, RuntimeObject*, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Color>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_m4ECBB9EDB81DC5D81C2F729F3A528B5345D36418_gshared (WhereSelectListIterator_2_t08B768B4AD54F201B800C51471E1C1C5FD1A8E8C * __this, List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * ___source0, Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * ___predicate1, Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64 * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76 *)__this);
		((  void (*) (Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64 * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Color>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76 * WhereSelectListIterator_2_Clone_m002D801C6321DC9447528A3FC50556077FBF5AAE_gshared (WhereSelectListIterator_2_t08B768B4AD54F201B800C51471E1C1C5FD1A8E8C * __this, const RuntimeMethod* method)
{
	{
		List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * L_0 = (List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *)__this->get_source_3();
		Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * L_1 = (Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)__this->get_predicate_4();
		Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64 * L_2 = (Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64 *)__this->get_selector_5();
		WhereSelectListIterator_2_t08B768B4AD54F201B800C51471E1C1C5FD1A8E8C * L_3 = (WhereSelectListIterator_2_t08B768B4AD54F201B800C51471E1C1C5FD1A8E8C *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_t08B768B4AD54F201B800C51471E1C1C5FD1A8E8C *, List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *, Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *, Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *)L_0, (Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)L_1, (Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64 *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76 *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Color>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_m5C99254EED16684A96D5361E3BE8A8406B86C533_gshared (WhereSelectListIterator_2_t08B768B4AD54F201B800C51471E1C1C5FD1A8E8C * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * L_3 = (List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *)__this->get_source_3();
		NullCheck((List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *)L_3);
		Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11  L_4;
		L_4 = ((  Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11  (*) (List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 * L_5 = (Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)__this->get_address_of_enumerator_6();
		ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  L_6;
		L_6 = Enumerator_get_Current_mB9DED66EBA82669AB83832B40F60E1710B5179B4_inline((Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)(Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 )L_6;
		Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * L_7 = (Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * L_8 = (Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)__this->get_predicate_4();
		ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  L_9 = V_1;
		NullCheck((Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *, ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)L_8, (ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64 * L_11 = (Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64 *)__this->get_selector_5();
		ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  L_12 = V_1;
		NullCheck((Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64 *)L_11);
		Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  L_13;
		L_13 = ((  Color_tF40DAF76C04FFECF3FE6024F85A294741C9CC659  (*) (Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64 *, ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_t07574F1E7EF84CF543A9B2FF0E62BB6B96696C64 *)L_11, (ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 * L_14 = (Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_mACDC401A875ECF83AEF9477068CDF02545A1D997((Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)(Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<UnityEngine.Color>::Dispose() */, (Iterator_1_tDEF6AC46E52D8687C27A6E60B6E0200D50011D76 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Color>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_mDECC30954B416D7786855DD9643B46A7E6DEB8C2_gshared (WhereSelectListIterator_2_t08B768B4AD54F201B800C51471E1C1C5FD1A8E8C * __this, Func_2_t3985FFDAB0D05F8E97E8EA849D5A24F16EFFC4FD * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t3985FFDAB0D05F8E97E8EA849D5A24F16EFFC4FD * L_0 = ___predicate0;
		WhereEnumerableIterator_1_tEDD9A2C48D1FE8BE0706121F2B6C8A796196FFF2 * L_1 = (WhereEnumerableIterator_1_tEDD9A2C48D1FE8BE0706121F2B6C8A796196FFF2 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_tEDD9A2C48D1FE8BE0706121F2B6C8A796196FFF2 *, RuntimeObject*, Func_2_t3985FFDAB0D05F8E97E8EA849D5A24F16EFFC4FD *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t3985FFDAB0D05F8E97E8EA849D5A24F16EFFC4FD *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Vector3>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_mD3F8F885B0AF6977BCFCC072276C87068F087FB2_gshared (WhereSelectListIterator_2_t94F415FEA624816E42FAE1274A4EC29F5D5C1625 * __this, List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * ___source0, Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * ___predicate1, Func_2_tA55660D7B36BC919063457215A12594F309CFDF1 * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF *)__this);
		((  void (*) (Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_tA55660D7B36BC919063457215A12594F309CFDF1 * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Vector3>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF * WhereSelectListIterator_2_Clone_m699590CC3733CE2DB41ABA02182719C678DAE562_gshared (WhereSelectListIterator_2_t94F415FEA624816E42FAE1274A4EC29F5D5C1625 * __this, const RuntimeMethod* method)
{
	{
		List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * L_0 = (List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *)__this->get_source_3();
		Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * L_1 = (Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)__this->get_predicate_4();
		Func_2_tA55660D7B36BC919063457215A12594F309CFDF1 * L_2 = (Func_2_tA55660D7B36BC919063457215A12594F309CFDF1 *)__this->get_selector_5();
		WhereSelectListIterator_2_t94F415FEA624816E42FAE1274A4EC29F5D5C1625 * L_3 = (WhereSelectListIterator_2_t94F415FEA624816E42FAE1274A4EC29F5D5C1625 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_t94F415FEA624816E42FAE1274A4EC29F5D5C1625 *, List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *, Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *, Func_2_tA55660D7B36BC919063457215A12594F309CFDF1 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *)L_0, (Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)L_1, (Func_2_tA55660D7B36BC919063457215A12594F309CFDF1 *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Vector3>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_m9FEC951E923EFC23AC8A86016D6A795C3275319E_gshared (WhereSelectListIterator_2_t94F415FEA624816E42FAE1274A4EC29F5D5C1625 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * L_3 = (List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *)__this->get_source_3();
		NullCheck((List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *)L_3);
		Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11  L_4;
		L_4 = ((  Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11  (*) (List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 * L_5 = (Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)__this->get_address_of_enumerator_6();
		ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  L_6;
		L_6 = Enumerator_get_Current_mB9DED66EBA82669AB83832B40F60E1710B5179B4_inline((Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)(Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 )L_6;
		Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * L_7 = (Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * L_8 = (Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)__this->get_predicate_4();
		ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  L_9 = V_1;
		NullCheck((Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *, ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)L_8, (ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_tA55660D7B36BC919063457215A12594F309CFDF1 * L_11 = (Func_2_tA55660D7B36BC919063457215A12594F309CFDF1 *)__this->get_selector_5();
		ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  L_12 = V_1;
		NullCheck((Func_2_tA55660D7B36BC919063457215A12594F309CFDF1 *)L_11);
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_13;
		L_13 = ((  Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  (*) (Func_2_tA55660D7B36BC919063457215A12594F309CFDF1 *, ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_tA55660D7B36BC919063457215A12594F309CFDF1 *)L_11, (ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 * L_14 = (Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_mACDC401A875ECF83AEF9477068CDF02545A1D997((Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)(Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<UnityEngine.Vector3>::Dispose() */, (Iterator_1_t04F5D870FD247BBBEE27254587FA10F440D4EEFF *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,UnityEngine.Vector3>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_mA49B2D74E495EFA26A1F215E3E809BAD571BCDA2_gshared (WhereSelectListIterator_2_t94F415FEA624816E42FAE1274A4EC29F5D5C1625 * __this, Func_2_t3041FD3183D19FE8416AE2E43A6398B2C06B7269 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t3041FD3183D19FE8416AE2E43A6398B2C06B7269 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t0E01F06572EA26BE9E79530811037753CF6B3BF8 * L_1 = (WhereEnumerableIterator_1_t0E01F06572EA26BE9E79530811037753CF6B3BF8 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_t0E01F06572EA26BE9E79530811037753CF6B3BF8 *, RuntimeObject*, Func_2_t3041FD3183D19FE8416AE2E43A6398B2C06B7269 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t3041FD3183D19FE8416AE2E43A6398B2C06B7269 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,Unity.Mathematics.float3>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_m429BD6BE31891961B06ECB6C64AF6D8BCE978A14_gshared (WhereSelectListIterator_2_t8005F348CC0B870A84DE3E85429A840305201D6E * __this, List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * ___source0, Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * ___predicate1, Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A *)__this);
		((  void (*) (Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,Unity.Mathematics.float3>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A * WhereSelectListIterator_2_Clone_m1B6B9C419A94F245358A5FCE850E012EB6F3C51D_gshared (WhereSelectListIterator_2_t8005F348CC0B870A84DE3E85429A840305201D6E * __this, const RuntimeMethod* method)
{
	{
		List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * L_0 = (List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *)__this->get_source_3();
		Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * L_1 = (Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)__this->get_predicate_4();
		Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C * L_2 = (Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C *)__this->get_selector_5();
		WhereSelectListIterator_2_t8005F348CC0B870A84DE3E85429A840305201D6E * L_3 = (WhereSelectListIterator_2_t8005F348CC0B870A84DE3E85429A840305201D6E *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_t8005F348CC0B870A84DE3E85429A840305201D6E *, List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *, Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *, Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *)L_0, (Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)L_1, (Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,Unity.Mathematics.float3>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_mC1816C78F69033DDC9FC62D30AAD5FC4D9A3AF18_gshared (WhereSelectListIterator_2_t8005F348CC0B870A84DE3E85429A840305201D6E * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C * L_3 = (List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *)__this->get_source_3();
		NullCheck((List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *)L_3);
		Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11  L_4;
		L_4 = ((  Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11  (*) (List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_t793A994CE01AE29FEE85500B7E3540653BFE5A0C *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 * L_5 = (Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)__this->get_address_of_enumerator_6();
		ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  L_6;
		L_6 = Enumerator_get_Current_mB9DED66EBA82669AB83832B40F60E1710B5179B4_inline((Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)(Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 )L_6;
		Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * L_7 = (Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A * L_8 = (Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)__this->get_predicate_4();
		ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  L_9 = V_1;
		NullCheck((Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *, ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_tD4EF074F88731E713305C48E156AB9F6F0F9324A *)L_8, (ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C * L_11 = (Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C *)__this->get_selector_5();
		ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  L_12 = V_1;
		NullCheck((Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C *)L_11);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_13;
		L_13 = ((  float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  (*) (Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C *, ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_t4ADAECFAD3DFE1FE3B6834A49502FA772B85CB3C *)L_11, (ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 * L_14 = (Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_mACDC401A875ECF83AEF9477068CDF02545A1D997((Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)(Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<Unity.Mathematics.float3>::Dispose() */, (Iterator_1_tCEC2E244A64F110B247B6A3DF34DE60D4456BA1A *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Experimental.Rendering.Universal.LibTessDotNet.ContourVertex,Unity.Mathematics.float3>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_m918384340B3A615C024FE2469E19186423B5ECC1_gshared (WhereSelectListIterator_2_t8005F348CC0B870A84DE3E85429A840305201D6E * __this, Func_2_t43355C55B1BBA93635101F6AF90867509812D7E5 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t43355C55B1BBA93635101F6AF90867509812D7E5 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t3450D7A9CB5BBEE711BB0ADD51AC530BD969D13F * L_1 = (WhereEnumerableIterator_1_t3450D7A9CB5BBEE711BB0ADD51AC530BD969D13F *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_t3450D7A9CB5BBEE711BB0ADD51AC530BD969D13F *, RuntimeObject*, Func_2_t43355C55B1BBA93635101F6AF90867509812D7E5 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t43355C55B1BBA93635101F6AF90867509812D7E5 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<System.Int32,System.Int32>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_m895E21AE9AB1E3F19B3147EDC913BB567B1A65C7_gshared (WhereSelectListIterator_2_t4CC3FE3A35610DC6F761EE7DB863B845957AD325 * __this, List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 * ___source0, Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 * ___predicate1, Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379 *)__this);
		((  void (*) (Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<System.Int32,System.Int32>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379 * WhereSelectListIterator_2_Clone_mEE6375B2C79172E13732CA49AAF389493C1C7100_gshared (WhereSelectListIterator_2_t4CC3FE3A35610DC6F761EE7DB863B845957AD325 * __this, const RuntimeMethod* method)
{
	{
		List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 * L_0 = (List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 *)__this->get_source_3();
		Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 * L_1 = (Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 *)__this->get_predicate_4();
		Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA * L_2 = (Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA *)__this->get_selector_5();
		WhereSelectListIterator_2_t4CC3FE3A35610DC6F761EE7DB863B845957AD325 * L_3 = (WhereSelectListIterator_2_t4CC3FE3A35610DC6F761EE7DB863B845957AD325 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_t4CC3FE3A35610DC6F761EE7DB863B845957AD325 *, List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 *, Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 *, Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 *)L_0, (Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 *)L_1, (Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379 *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<System.Int32,System.Int32>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_m637B802A50BA94CD511636CAF5D912C6B96B18A1_gshared (WhereSelectListIterator_2_t4CC3FE3A35610DC6F761EE7DB863B845957AD325 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	{
		int32_t L_0 = (int32_t)((Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 * L_3 = (List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 *)__this->get_source_3();
		NullCheck((List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 *)L_3);
		Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C  L_4;
		L_4 = ((  Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C  (*) (List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_t260B41F956D673396C33A4CF94E8D6C4389EACB7 *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C * L_5 = (Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C *)__this->get_address_of_enumerator_6();
		int32_t L_6;
		L_6 = Enumerator_get_Current_m6BBD624C51F7E20D347FE5894A6ECA94B8011181_inline((Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C *)(Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (int32_t)L_6;
		Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 * L_7 = (Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 * L_8 = (Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 *)__this->get_predicate_4();
		int32_t L_9 = V_1;
		NullCheck((Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 *, int32_t, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 *)L_8, (int32_t)L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA * L_11 = (Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA *)__this->get_selector_5();
		int32_t L_12 = V_1;
		NullCheck((Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA *)L_11);
		int32_t L_13;
		L_13 = ((  int32_t (*) (Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA *, int32_t, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_tFF6AE79EFD0857556AD37A1A1594C43F76012FEA *)L_11, (int32_t)L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C * L_14 = (Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_m40FD166B6757334A2BBCF67238EFDF70D727A4A6((Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C *)(Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<System.Int32>::Dispose() */, (Iterator_1_tCFFC952B03DBE4E956DE317DB9704D936AEA2379 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<System.Int32,System.Int32>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_m7F75FF628D2E99D2BA127B84FDD08DD88048ADB0_gshared (WhereSelectListIterator_2_t4CC3FE3A35610DC6F761EE7DB863B845957AD325 * __this, Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t9F4DDC70173BABD72AEC7AA00D62F4FAE2613CEA * L_1 = (WhereEnumerableIterator_1_t9F4DDC70173BABD72AEC7AA00D62F4FAE2613CEA *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_t9F4DDC70173BABD72AEC7AA00D62F4FAE2613CEA *, RuntimeObject*, Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t2EBF98B0BA555D9F0633C9BCCBE3DF332B9C1274 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_m152DE7D52A23EE1B613545FAEF74CDDCFF4CCD33_gshared (WhereSelectListIterator_2_tAEAF0881ED609445F03C4E5691A27493B13F5D3E * __this, List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * ___source0, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * ___predicate1, Func_2_tEE37498C122C43E9F0D581326B5464292A55F235 * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		((  void (*) (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_tEE37498C122C43E9F0D581326B5464292A55F235 * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 * WhereSelectListIterator_2_Clone_m43C5877DA458522989A291FE3A2B1C11633F71A7_gshared (WhereSelectListIterator_2_tAEAF0881ED609445F03C4E5691A27493B13F5D3E * __this, const RuntimeMethod* method)
{
	{
		List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * L_0 = (List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 *)__this->get_source_3();
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_1 = (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)__this->get_predicate_4();
		Func_2_tEE37498C122C43E9F0D581326B5464292A55F235 * L_2 = (Func_2_tEE37498C122C43E9F0D581326B5464292A55F235 *)__this->get_selector_5();
		WhereSelectListIterator_2_tAEAF0881ED609445F03C4E5691A27493B13F5D3E * L_3 = (WhereSelectListIterator_2_tAEAF0881ED609445F03C4E5691A27493B13F5D3E *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_tAEAF0881ED609445F03C4E5691A27493B13F5D3E *, List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 *, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *, Func_2_tEE37498C122C43E9F0D581326B5464292A55F235 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 *)L_0, (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)L_1, (Func_2_tEE37498C122C43E9F0D581326B5464292A55F235 *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_mC481037A8B8C6CCC37B62340960223444EA12262_gshared (WhereSelectListIterator_2_tAEAF0881ED609445F03C4E5691A27493B13F5D3E * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * L_3 = (List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 *)__this->get_source_3();
		NullCheck((List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 *)L_3);
		Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72  L_4;
		L_4 = ((  Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72  (*) (List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 * L_5 = (Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 *)__this->get_address_of_enumerator_6();
		InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  L_6;
		L_6 = Enumerator_get_Current_mDFC8852F498B3A27BD601B8B3D1AAD9EFD96ED78_inline((Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 *)(Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D )L_6;
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_7 = (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_8 = (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)__this->get_predicate_4();
		InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  L_9 = V_1;
		NullCheck((Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *, InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)L_8, (InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_tEE37498C122C43E9F0D581326B5464292A55F235 * L_11 = (Func_2_tEE37498C122C43E9F0D581326B5464292A55F235 *)__this->get_selector_5();
		InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  L_12 = V_1;
		NullCheck((Func_2_tEE37498C122C43E9F0D581326B5464292A55F235 *)L_11);
		InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  L_13;
		L_13 = ((  InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  (*) (Func_2_tEE37498C122C43E9F0D581326B5464292A55F235 *, InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_tEE37498C122C43E9F0D581326B5464292A55F235 *)L_11, (InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 * L_14 = (Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_mC85A573A7B1E29F62C95F0841F4368217B0FC647((Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 *)(Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<UnityEngine.InputSystem.Utilities.InternedString>::Dispose() */, (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.InternedString,UnityEngine.InputSystem.Utilities.InternedString>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_m3542D3CE5B5321947E5D280063CC82E23EA2F575_gshared (WhereSelectListIterator_2_tAEAF0881ED609445F03C4E5691A27493B13F5D3E * __this, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 * L_1 = (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *, RuntimeObject*, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.InternedString,System.Object>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_mC125C79DCE8105675B4E82F7424B3154B50BB2A8_gshared (WhereSelectListIterator_2_t65F4408766820863D04329D21B3BDFB6FD5625B8 * __this, List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * ___source0, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * ___predicate1, Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720 * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		((  void (*) (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720 * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.InternedString,System.Object>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 * WhereSelectListIterator_2_Clone_mEE60DBFF49F2028575863F9E32D14E799FCF3B53_gshared (WhereSelectListIterator_2_t65F4408766820863D04329D21B3BDFB6FD5625B8 * __this, const RuntimeMethod* method)
{
	{
		List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * L_0 = (List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 *)__this->get_source_3();
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_1 = (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)__this->get_predicate_4();
		Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720 * L_2 = (Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720 *)__this->get_selector_5();
		WhereSelectListIterator_2_t65F4408766820863D04329D21B3BDFB6FD5625B8 * L_3 = (WhereSelectListIterator_2_t65F4408766820863D04329D21B3BDFB6FD5625B8 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_t65F4408766820863D04329D21B3BDFB6FD5625B8 *, List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 *, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *, Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 *)L_0, (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)L_1, (Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720 *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.InternedString,System.Object>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_m1E540AED8781D5856C27FFB7FDED8B2BDE02304D_gshared (WhereSelectListIterator_2_t65F4408766820863D04329D21B3BDFB6FD5625B8 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 * L_3 = (List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 *)__this->get_source_3();
		NullCheck((List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 *)L_3);
		Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72  L_4;
		L_4 = ((  Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72  (*) (List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_t3C767C293DF7F1DB869265A875EF5AE59EFAAC49 *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 * L_5 = (Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 *)__this->get_address_of_enumerator_6();
		InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  L_6;
		L_6 = Enumerator_get_Current_mDFC8852F498B3A27BD601B8B3D1AAD9EFD96ED78_inline((Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 *)(Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D )L_6;
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_7 = (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_8 = (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)__this->get_predicate_4();
		InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  L_9 = V_1;
		NullCheck((Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *, InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)L_8, (InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720 * L_11 = (Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720 *)__this->get_selector_5();
		InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  L_12 = V_1;
		NullCheck((Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720 *)L_11);
		RuntimeObject * L_13;
		L_13 = ((  RuntimeObject * (*) (Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720 *, InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_t4E43B897DFB4B89CB2DCD0F8E48304DB2416A720 *)L_11, (InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 * L_14 = (Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_mC85A573A7B1E29F62C95F0841F4368217B0FC647((Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 *)(Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<System.Object>::Dispose() */, (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.InternedString,System.Object>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_m394C1439730A86FA60DDF8B6FDA7D651E0F6A8D6_gshared (WhereSelectListIterator_2_t65F4408766820863D04329D21B3BDFB6FD5625B8 * __this, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 * L_1 = (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *, RuntimeObject*, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NameAndParameters,UnityEngine.InputSystem.Utilities.InternedString>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_m9EA31491C052B921C7B694CE40F0A76F9747E6B7_gshared (WhereSelectListIterator_2_t9D660598407BAACFC571EA8D5994C24416E7EF72 * __this, List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * ___source0, Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * ___predicate1, Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2 * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		((  void (*) (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2 * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NameAndParameters,UnityEngine.InputSystem.Utilities.InternedString>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 * WhereSelectListIterator_2_Clone_m0C233A4E22F6AB3DE2DB6D5F414F3DAACF8D27F5_gshared (WhereSelectListIterator_2_t9D660598407BAACFC571EA8D5994C24416E7EF72 * __this, const RuntimeMethod* method)
{
	{
		List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * L_0 = (List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D *)__this->get_source_3();
		Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * L_1 = (Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *)__this->get_predicate_4();
		Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2 * L_2 = (Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2 *)__this->get_selector_5();
		WhereSelectListIterator_2_t9D660598407BAACFC571EA8D5994C24416E7EF72 * L_3 = (WhereSelectListIterator_2_t9D660598407BAACFC571EA8D5994C24416E7EF72 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_t9D660598407BAACFC571EA8D5994C24416E7EF72 *, List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D *, Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *, Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D *)L_0, (Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *)L_1, (Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2 *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NameAndParameters,UnityEngine.InputSystem.Utilities.InternedString>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_m5B888971EC0E6DE8EEC59DCABEEE87D4EAA5BB1E_gshared (WhereSelectListIterator_2_t9D660598407BAACFC571EA8D5994C24416E7EF72 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * L_3 = (List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D *)__this->get_source_3();
		NullCheck((List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D *)L_3);
		Enumerator_t3F22A2E619D662922F996C766D960AF285909004  L_4;
		L_4 = ((  Enumerator_t3F22A2E619D662922F996C766D960AF285909004  (*) (List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_t3F22A2E619D662922F996C766D960AF285909004 * L_5 = (Enumerator_t3F22A2E619D662922F996C766D960AF285909004 *)__this->get_address_of_enumerator_6();
		NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  L_6;
		L_6 = Enumerator_get_Current_mDA65875F4B6726349744D3FDA9F8F3D655CF843E_inline((Enumerator_t3F22A2E619D662922F996C766D960AF285909004 *)(Enumerator_t3F22A2E619D662922F996C766D960AF285909004 *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344 )L_6;
		Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * L_7 = (Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * L_8 = (Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *)__this->get_predicate_4();
		NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  L_9 = V_1;
		NullCheck((Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *, NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *)L_8, (NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344 )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2 * L_11 = (Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2 *)__this->get_selector_5();
		NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  L_12 = V_1;
		NullCheck((Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2 *)L_11);
		InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  L_13;
		L_13 = ((  InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  (*) (Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2 *, NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_tD183628B59BD73259BA2FA1B5A3DE185E73CF7B2 *)L_11, (NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344 )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_t3F22A2E619D662922F996C766D960AF285909004 * L_14 = (Enumerator_t3F22A2E619D662922F996C766D960AF285909004 *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_m8C47DD84EE474A11C083B071DE1C5AF1AAE32DEE((Enumerator_t3F22A2E619D662922F996C766D960AF285909004 *)(Enumerator_t3F22A2E619D662922F996C766D960AF285909004 *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<UnityEngine.InputSystem.Utilities.InternedString>::Dispose() */, (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NameAndParameters,UnityEngine.InputSystem.Utilities.InternedString>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_m656A85B2B3A5A8258C4B5FBCE82838718331A9E0_gshared (WhereSelectListIterator_2_t9D660598407BAACFC571EA8D5994C24416E7EF72 * __this, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 * L_1 = (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *, RuntimeObject*, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NameAndParameters,System.Object>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_m78FEF2E08BEA95534D08639BC4655608C6FFB740_gshared (WhereSelectListIterator_2_tA136D27DBB78E46ED7DC60EC99A376E9D816FC6A * __this, List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * ___source0, Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * ___predicate1, Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		((  void (*) (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NameAndParameters,System.Object>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 * WhereSelectListIterator_2_Clone_m0AC84221205D095B55ED9B805D0E028006230B2A_gshared (WhereSelectListIterator_2_tA136D27DBB78E46ED7DC60EC99A376E9D816FC6A * __this, const RuntimeMethod* method)
{
	{
		List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * L_0 = (List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D *)__this->get_source_3();
		Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * L_1 = (Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *)__this->get_predicate_4();
		Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F * L_2 = (Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F *)__this->get_selector_5();
		WhereSelectListIterator_2_tA136D27DBB78E46ED7DC60EC99A376E9D816FC6A * L_3 = (WhereSelectListIterator_2_tA136D27DBB78E46ED7DC60EC99A376E9D816FC6A *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_tA136D27DBB78E46ED7DC60EC99A376E9D816FC6A *, List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D *, Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *, Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D *)L_0, (Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *)L_1, (Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NameAndParameters,System.Object>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_m445709C86C8522EE86F420A9EECD905551B50361_gshared (WhereSelectListIterator_2_tA136D27DBB78E46ED7DC60EC99A376E9D816FC6A * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D * L_3 = (List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D *)__this->get_source_3();
		NullCheck((List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D *)L_3);
		Enumerator_t3F22A2E619D662922F996C766D960AF285909004  L_4;
		L_4 = ((  Enumerator_t3F22A2E619D662922F996C766D960AF285909004  (*) (List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_t921F1AD2EC9D547F1822C5817D6D6A073FE0E78D *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_t3F22A2E619D662922F996C766D960AF285909004 * L_5 = (Enumerator_t3F22A2E619D662922F996C766D960AF285909004 *)__this->get_address_of_enumerator_6();
		NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  L_6;
		L_6 = Enumerator_get_Current_mDA65875F4B6726349744D3FDA9F8F3D655CF843E_inline((Enumerator_t3F22A2E619D662922F996C766D960AF285909004 *)(Enumerator_t3F22A2E619D662922F996C766D960AF285909004 *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344 )L_6;
		Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * L_7 = (Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 * L_8 = (Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *)__this->get_predicate_4();
		NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  L_9 = V_1;
		NullCheck((Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *, NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_t26C96BD8AC4D702CB8C69FAD5D9BEE6A2BA55082 *)L_8, (NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344 )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F * L_11 = (Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F *)__this->get_selector_5();
		NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  L_12 = V_1;
		NullCheck((Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F *)L_11);
		RuntimeObject * L_13;
		L_13 = ((  RuntimeObject * (*) (Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F *, NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_t6FC1DF68B6459C3BDB22BED5FB9D0331FD64B80F *)L_11, (NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344 )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_t3F22A2E619D662922F996C766D960AF285909004 * L_14 = (Enumerator_t3F22A2E619D662922F996C766D960AF285909004 *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_m8C47DD84EE474A11C083B071DE1C5AF1AAE32DEE((Enumerator_t3F22A2E619D662922F996C766D960AF285909004 *)(Enumerator_t3F22A2E619D662922F996C766D960AF285909004 *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<System.Object>::Dispose() */, (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NameAndParameters,System.Object>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_mB2650958C4C147644D61BB461303DEBA1D2ED033_gshared (WhereSelectListIterator_2_tA136D27DBB78E46ED7DC60EC99A376E9D816FC6A * __this, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 * L_1 = (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *, RuntimeObject*, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NamedValue,UnityEngine.InputSystem.Utilities.InternedString>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_m9967AE4C90FE512FAA26AABB25A38F95E20ACA54_gshared (WhereSelectListIterator_2_tDDA7D42453A9A6E14983F2A64F835CA82FB5C3D4 * __this, List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * ___source0, Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * ___predicate1, Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		((  void (*) (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NamedValue,UnityEngine.InputSystem.Utilities.InternedString>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 * WhereSelectListIterator_2_Clone_m419C08045B95A23B96FEF85AE8E4D18B3013D4F9_gshared (WhereSelectListIterator_2_tDDA7D42453A9A6E14983F2A64F835CA82FB5C3D4 * __this, const RuntimeMethod* method)
{
	{
		List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * L_0 = (List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 *)__this->get_source_3();
		Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * L_1 = (Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *)__this->get_predicate_4();
		Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D * L_2 = (Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D *)__this->get_selector_5();
		WhereSelectListIterator_2_tDDA7D42453A9A6E14983F2A64F835CA82FB5C3D4 * L_3 = (WhereSelectListIterator_2_tDDA7D42453A9A6E14983F2A64F835CA82FB5C3D4 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_tDDA7D42453A9A6E14983F2A64F835CA82FB5C3D4 *, List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 *, Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *, Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 *)L_0, (Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *)L_1, (Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NamedValue,UnityEngine.InputSystem.Utilities.InternedString>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_m92D03A1B77B7CEDDC3929720A8857312A09F2F8A_gshared (WhereSelectListIterator_2_tDDA7D42453A9A6E14983F2A64F835CA82FB5C3D4 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * L_3 = (List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 *)__this->get_source_3();
		NullCheck((List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 *)L_3);
		Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66  L_4;
		L_4 = ((  Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66  (*) (List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 * L_5 = (Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 *)__this->get_address_of_enumerator_6();
		NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  L_6;
		L_6 = Enumerator_get_Current_m1DAC585732F0CB8AA13B33E1015A60D953E69FA8_inline((Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 *)(Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0 )L_6;
		Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * L_7 = (Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * L_8 = (Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *)__this->get_predicate_4();
		NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  L_9 = V_1;
		NullCheck((Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *, NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *)L_8, (NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0 )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D * L_11 = (Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D *)__this->get_selector_5();
		NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  L_12 = V_1;
		NullCheck((Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D *)L_11);
		InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  L_13;
		L_13 = ((  InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  (*) (Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D *, NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_t4355A234BA1F974CDFD22E13FC44967B7B53233D *)L_11, (NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0 )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 * L_14 = (Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_mF54BF589CE1C156DA753373FCEBC3D850B80CC01((Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 *)(Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<UnityEngine.InputSystem.Utilities.InternedString>::Dispose() */, (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NamedValue,UnityEngine.InputSystem.Utilities.InternedString>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_m702ADA224467AD4C1799A90DE7A8F6675327E942_gshared (WhereSelectListIterator_2_tDDA7D42453A9A6E14983F2A64F835CA82FB5C3D4 * __this, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 * L_1 = (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *, RuntimeObject*, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NamedValue,System.Object>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_m59B776BA53FA8BFD9DF05B8C21B81B3A9D3FE9D4_gshared (WhereSelectListIterator_2_t8DFCE6669BD07F0F7FD9461FACD9D83AAF9F8EE3 * __this, List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * ___source0, Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * ___predicate1, Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54 * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		((  void (*) (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54 * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NamedValue,System.Object>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 * WhereSelectListIterator_2_Clone_mFD3892B224D42B0BDBF6986A58A42AD5C94855D9_gshared (WhereSelectListIterator_2_t8DFCE6669BD07F0F7FD9461FACD9D83AAF9F8EE3 * __this, const RuntimeMethod* method)
{
	{
		List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * L_0 = (List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 *)__this->get_source_3();
		Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * L_1 = (Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *)__this->get_predicate_4();
		Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54 * L_2 = (Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54 *)__this->get_selector_5();
		WhereSelectListIterator_2_t8DFCE6669BD07F0F7FD9461FACD9D83AAF9F8EE3 * L_3 = (WhereSelectListIterator_2_t8DFCE6669BD07F0F7FD9461FACD9D83AAF9F8EE3 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_t8DFCE6669BD07F0F7FD9461FACD9D83AAF9F8EE3 *, List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 *, Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *, Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 *)L_0, (Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *)L_1, (Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54 *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NamedValue,System.Object>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_mEB8C5B0D99F46041EE113B1D728B3245AF0766C3_gshared (WhereSelectListIterator_2_t8DFCE6669BD07F0F7FD9461FACD9D83AAF9F8EE3 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 * L_3 = (List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 *)__this->get_source_3();
		NullCheck((List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 *)L_3);
		Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66  L_4;
		L_4 = ((  Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66  (*) (List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_t2914E3F9A3EE34B368277CD737C640AA8AAA6774 *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 * L_5 = (Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 *)__this->get_address_of_enumerator_6();
		NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  L_6;
		L_6 = Enumerator_get_Current_m1DAC585732F0CB8AA13B33E1015A60D953E69FA8_inline((Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 *)(Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0 )L_6;
		Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * L_7 = (Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 * L_8 = (Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *)__this->get_predicate_4();
		NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  L_9 = V_1;
		NullCheck((Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *, NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_t2F791B3C5C6B030148ED40275B7D062D5D0247F8 *)L_8, (NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0 )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54 * L_11 = (Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54 *)__this->get_selector_5();
		NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  L_12 = V_1;
		NullCheck((Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54 *)L_11);
		RuntimeObject * L_13;
		L_13 = ((  RuntimeObject * (*) (Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54 *, NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_tD1280D9EBC68887081FB2E62A4348D8BC154BC54 *)L_11, (NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0 )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 * L_14 = (Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_mF54BF589CE1C156DA753373FCEBC3D850B80CC01((Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 *)(Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<System.Object>::Dispose() */, (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.NamedValue,System.Object>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_m93D2DA0A0069DA23D246D4285DB5F443F4F85A12_gshared (WhereSelectListIterator_2_t8DFCE6669BD07F0F7FD9461FACD9D83AAF9F8EE3 * __this, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 * L_1 = (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *, RuntimeObject*, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_m140DC13BA6A925DC41EF20BEAC8354414C1376B3_gshared (WhereSelectListIterator_2_t8E02B4908AA9B882EBD941ADBA2D45EAEA8BF72B * __this, List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * ___source0, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate1, Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		((  void (*) (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 * WhereSelectListIterator_2_Clone_m7C16DE11A83CAB5AF9DFBAEE65CCAA7714716DC3_gshared (WhereSelectListIterator_2_t8E02B4908AA9B882EBD941ADBA2D45EAEA8BF72B * __this, const RuntimeMethod* method)
{
	{
		List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * L_0 = (List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 *)__this->get_source_3();
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_1 = (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)__this->get_predicate_4();
		Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 * L_2 = (Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 *)__this->get_selector_5();
		WhereSelectListIterator_2_t8E02B4908AA9B882EBD941ADBA2D45EAEA8BF72B * L_3 = (WhereSelectListIterator_2_t8E02B4908AA9B882EBD941ADBA2D45EAEA8BF72B *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_t8E02B4908AA9B882EBD941ADBA2D45EAEA8BF72B *, List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 *, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 *)L_0, (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_1, (Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_m3B9F336EE5085B167B721D9F123A7E0B2B5D397E_gshared (WhereSelectListIterator_2_t8E02B4908AA9B882EBD941ADBA2D45EAEA8BF72B * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	RuntimeObject * V_1 = NULL;
	{
		int32_t L_0 = (int32_t)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * L_3 = (List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 *)__this->get_source_3();
		NullCheck((List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 *)L_3);
		Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6  L_4;
		L_4 = ((  Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6  (*) (List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 * L_5 = (Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 *)__this->get_address_of_enumerator_6();
		RuntimeObject * L_6;
		L_6 = Enumerator_get_Current_m9C4EBBD2108B51885E750F927D7936290C8E20EE_inline((Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 *)(Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (RuntimeObject *)L_6;
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_7 = (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_8 = (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)__this->get_predicate_4();
		RuntimeObject * L_9 = V_1;
		NullCheck((Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, RuntimeObject *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_8, (RuntimeObject *)L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 * L_11 = (Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 *)__this->get_selector_5();
		RuntimeObject * L_12 = V_1;
		NullCheck((Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 *)L_11);
		InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  L_13;
		L_13 = ((  InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  (*) (Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 *, RuntimeObject *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_tE0B9FC15B889A22E849A040F0703B353C9D6DF93 *)L_11, (RuntimeObject *)L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 * L_14 = (Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_m2E56233762839CE55C67E00AC8DD3D4D3F6C0DF0((Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 *)(Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<UnityEngine.InputSystem.Utilities.InternedString>::Dispose() */, (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<System.Object,UnityEngine.InputSystem.Utilities.InternedString>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_mE1B618C3F1FD5EF8C2C91023B5AC5B06BE6D0505_gshared (WhereSelectListIterator_2_t8E02B4908AA9B882EBD941ADBA2D45EAEA8BF72B * __this, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 * L_1 = (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *, RuntimeObject*, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<System.Object,System.Object>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_mCF313A191371C8CCC2E79D89A3BF21714EFDB20E_gshared (WhereSelectListIterator_2_t85B78DFF0573BC95A62C79D6088FA39DFEBE1AF2 * __this, List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * ___source0, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate1, Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		((  void (*) (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<System.Object,System.Object>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 * WhereSelectListIterator_2_Clone_m667BCD94E83BB3A02AF2D66E07B089FA86971342_gshared (WhereSelectListIterator_2_t85B78DFF0573BC95A62C79D6088FA39DFEBE1AF2 * __this, const RuntimeMethod* method)
{
	{
		List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * L_0 = (List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 *)__this->get_source_3();
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_1 = (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)__this->get_predicate_4();
		Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 * L_2 = (Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 *)__this->get_selector_5();
		WhereSelectListIterator_2_t85B78DFF0573BC95A62C79D6088FA39DFEBE1AF2 * L_3 = (WhereSelectListIterator_2_t85B78DFF0573BC95A62C79D6088FA39DFEBE1AF2 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_t85B78DFF0573BC95A62C79D6088FA39DFEBE1AF2 *, List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 *, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 *)L_0, (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_1, (Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<System.Object,System.Object>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_mEE0E8B173345B059100E0736D106FFAE0C2D29CA_gshared (WhereSelectListIterator_2_t85B78DFF0573BC95A62C79D6088FA39DFEBE1AF2 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	RuntimeObject * V_1 = NULL;
	{
		int32_t L_0 = (int32_t)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 * L_3 = (List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 *)__this->get_source_3();
		NullCheck((List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 *)L_3);
		Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6  L_4;
		L_4 = ((  Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6  (*) (List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_t3F94120C77410A62EAE48421CF166B83AB95A2F5 *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 * L_5 = (Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 *)__this->get_address_of_enumerator_6();
		RuntimeObject * L_6;
		L_6 = Enumerator_get_Current_m9C4EBBD2108B51885E750F927D7936290C8E20EE_inline((Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 *)(Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (RuntimeObject *)L_6;
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_7 = (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_8 = (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)__this->get_predicate_4();
		RuntimeObject * L_9 = V_1;
		NullCheck((Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, RuntimeObject *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_8, (RuntimeObject *)L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 * L_11 = (Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 *)__this->get_selector_5();
		RuntimeObject * L_12 = V_1;
		NullCheck((Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 *)L_11);
		RuntimeObject * L_13;
		L_13 = ((  RuntimeObject * (*) (Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 *, RuntimeObject *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_tFF5BB8F40A35B1BEA00D4EBBC6CBE7184A584436 *)L_11, (RuntimeObject *)L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 * L_14 = (Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_m2E56233762839CE55C67E00AC8DD3D4D3F6C0DF0((Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 *)(Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<System.Object>::Dispose() */, (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<System.Object,System.Object>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_mAC87184664F73DD7F3EC4AB4CE2BDE71BE76249D_gshared (WhereSelectListIterator_2_t85B78DFF0573BC95A62C79D6088FA39DFEBE1AF2 * __this, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 * L_1 = (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *, RuntimeObject*, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,UnityEngine.Vector3Int>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_m65A12DB88A2E293BF4C131A072949305D82FB2D9_gshared (WhereSelectListIterator_2_t61A00440D82A40FF5366588862F077D31BB2B86D * __this, List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 * ___source0, Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * ___predicate1, Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this);
		((  void (*) (Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,UnityEngine.Vector3Int>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 * WhereSelectListIterator_2_Clone_mA711CFE45DEF2F03850168C8EABFB4D999B00947_gshared (WhereSelectListIterator_2_t61A00440D82A40FF5366588862F077D31BB2B86D * __this, const RuntimeMethod* method)
{
	{
		List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 * L_0 = (List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 *)__this->get_source_3();
		Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * L_1 = (Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *)__this->get_predicate_4();
		Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A * L_2 = (Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A *)__this->get_selector_5();
		WhereSelectListIterator_2_t61A00440D82A40FF5366588862F077D31BB2B86D * L_3 = (WhereSelectListIterator_2_t61A00440D82A40FF5366588862F077D31BB2B86D *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_t61A00440D82A40FF5366588862F077D31BB2B86D *, List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 *, Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *, Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 *)L_0, (Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *)L_1, (Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,UnityEngine.Vector3Int>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_mBD78444E5CA9B39B33F397BE943AF2C13E92A84E_gshared (WhereSelectListIterator_2_t61A00440D82A40FF5366588862F077D31BB2B86D * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 * L_3 = (List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 *)__this->get_source_3();
		NullCheck((List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 *)L_3);
		Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502  L_4;
		L_4 = ((  Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502  (*) (List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_t63003D93D72D544D4DFBA71C344D7215B64440F0 *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 * L_5 = (Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 *)__this->get_address_of_enumerator_6();
		GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  L_6;
		L_6 = Enumerator_get_Current_mCD38ED89C9598655A9824EA42E516F0F7822EF78_inline((Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 *)(Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941 )L_6;
		Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * L_7 = (Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C * L_8 = (Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *)__this->get_predicate_4();
		GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  L_9 = V_1;
		NullCheck((Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *, GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_t7ECA77682660B9CB2F1CEB2EBDED0B73F81FBF0C *)L_8, (GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941 )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A * L_11 = (Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A *)__this->get_selector_5();
		GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  L_12 = V_1;
		NullCheck((Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A *)L_11);
		Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  L_13;
		L_13 = ((  Vector3Int_t197C3BA05CF19F1A22D40F8AE64CD4102AFB77EA  (*) (Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A *, GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_t7512EA542CD96E7DC9368E2F05D7DA950624D30A *)L_11, (GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941 )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 * L_14 = (Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_mD158898776983980E4A8FCD4C559022D608E854D((Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 *)(Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<UnityEngine.Vector3Int>::Dispose() */, (Iterator_1_t4D9C2A5C9081E2D575BBF66C425228347C3B6EF1 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.Tilemaps.GridInformation/GridInformationKey,UnityEngine.Vector3Int>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_m43CBF4CB706A8E8A7CA0E8DFC6761F844CF491C3_gshared (WhereSelectListIterator_2_t61A00440D82A40FF5366588862F077D31BB2B86D * __this, Func_2_tB3AD6A340F9ED708E8459C7912C86F7504161867 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_tB3AD6A340F9ED708E8459C7912C86F7504161867 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_tD2CF2E617E3FFF17EDE787C942514D3A3E76A8A2 * L_1 = (WhereEnumerableIterator_1_tD2CF2E617E3FFF17EDE787C942514D3A3E76A8A2 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_tD2CF2E617E3FFF17EDE787C942514D3A3E76A8A2 *, RuntimeObject*, Func_2_tB3AD6A340F9ED708E8459C7912C86F7504161867 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_tB3AD6A340F9ED708E8459C7912C86F7504161867 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,UnityEngine.InputSystem.Utilities.InternedString>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_mF158523517A4CDAA4B128C393FF64D6440DCA9E2_gshared (WhereSelectListIterator_2_t8F78416238F9681ED8DD6A1888291B25087ADB48 * __this, List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * ___source0, Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * ___predicate1, Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		((  void (*) (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,UnityEngine.InputSystem.Utilities.InternedString>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 * WhereSelectListIterator_2_Clone_m0587D09C2D23C7915658C61755E28319ACD99381_gshared (WhereSelectListIterator_2_t8F78416238F9681ED8DD6A1888291B25087ADB48 * __this, const RuntimeMethod* method)
{
	{
		List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * L_0 = (List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 *)__this->get_source_3();
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_1 = (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)__this->get_predicate_4();
		Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C * L_2 = (Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C *)__this->get_selector_5();
		WhereSelectListIterator_2_t8F78416238F9681ED8DD6A1888291B25087ADB48 * L_3 = (WhereSelectListIterator_2_t8F78416238F9681ED8DD6A1888291B25087ADB48 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_t8F78416238F9681ED8DD6A1888291B25087ADB48 *, List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 *, Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *, Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 *)L_0, (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)L_1, (Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,UnityEngine.InputSystem.Utilities.InternedString>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_mD4175455F5B7B625B7638CBB1CF276F22C8D7978_gshared (WhereSelectListIterator_2_t8F78416238F9681ED8DD6A1888291B25087ADB48 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * L_3 = (List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 *)__this->get_source_3();
		NullCheck((List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 *)L_3);
		Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F  L_4;
		L_4 = ((  Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F  (*) (List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F * L_5 = (Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F *)__this->get_address_of_enumerator_6();
		JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  L_6;
		L_6 = Enumerator_get_Current_mA2F40010AB5E3D0B7854E66406831953599A7D11_inline((Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F *)(Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE )L_6;
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_7 = (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_8 = (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)__this->get_predicate_4();
		JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  L_9 = V_1;
		NullCheck((Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *, JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)L_8, (JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C * L_11 = (Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C *)__this->get_selector_5();
		JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  L_12 = V_1;
		NullCheck((Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C *)L_11);
		InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  L_13;
		L_13 = ((  InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  (*) (Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C *, JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_tBB8D09A333F4F4DFE9108428323C8E22A3B2D56C *)L_11, (JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F * L_14 = (Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_mBA2E1218E317D2B755FE5DBCDD554A8D758EE9F9((Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F *)(Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<UnityEngine.InputSystem.Utilities.InternedString>::Dispose() */, (Iterator_1_t939C2623621EB3C488847B8BD51081F25BE5CB94 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,UnityEngine.InputSystem.Utilities.InternedString>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_m850BEE41A3E19E0E3053DA5D2E22714194A28FCB_gshared (WhereSelectListIterator_2_t8F78416238F9681ED8DD6A1888291B25087ADB48 * __this, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 * L_1 = (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_t4832343B9BEE30DDE7147E346AC09B43A2F84F59 *, RuntimeObject*, Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t4EB0539C0DEE5BD1BAF5DFC421295F2C941C8E17 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Object>::.ctor(System.Collections.Generic.List`1<TSource>,System.Func`2<TSource,System.Boolean>,System.Func`2<TSource,TResult>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WhereSelectListIterator_2__ctor_mE97BED01F13B94F1F2AB460B63A156FCF0E35302_gshared (WhereSelectListIterator_2_t7BD313142193815CBBFF1CDEAB29F9EAF147B7AA * __this, List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * ___source0, Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * ___predicate1, Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 * ___selector2, const RuntimeMethod* method)
{
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		((  void (*) (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0)->methodPointer)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 0));
		List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * L_0 = ___source0;
		__this->set_source_3(L_0);
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_1 = ___predicate1;
		__this->set_predicate_4(L_1);
		Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 * L_2 = ___selector2;
		__this->set_selector_5(L_2);
		return;
	}
}
// System.Linq.Enumerable/Iterator`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Object>::Clone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 * WhereSelectListIterator_2_Clone_m76755BA9BB94282F6E9A2E80F59FDC1093F1E96E_gshared (WhereSelectListIterator_2_t7BD313142193815CBBFF1CDEAB29F9EAF147B7AA * __this, const RuntimeMethod* method)
{
	{
		List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * L_0 = (List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 *)__this->get_source_3();
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_1 = (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)__this->get_predicate_4();
		Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 * L_2 = (Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 *)__this->get_selector_5();
		WhereSelectListIterator_2_t7BD313142193815CBBFF1CDEAB29F9EAF147B7AA * L_3 = (WhereSelectListIterator_2_t7BD313142193815CBBFF1CDEAB29F9EAF147B7AA *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 2));
		((  void (*) (WhereSelectListIterator_2_t7BD313142193815CBBFF1CDEAB29F9EAF147B7AA *, List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 *, Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *, Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3)->methodPointer)(L_3, (List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 *)L_0, (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)L_1, (Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 *)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 3));
		return (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)L_3;
	}
}
// System.Boolean System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Object>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WhereSelectListIterator_2_MoveNext_mD8BF48948E4E70804A4F466DB6D94001EB6DDE43_gshared (WhereSelectListIterator_2_t7BD313142193815CBBFF1CDEAB29F9EAF147B7AA * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		int32_t L_0 = (int32_t)((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->get_state_1();
		V_0 = (int32_t)L_0;
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)2)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_0074;
	}

IL_0011:
	{
		List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 * L_3 = (List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 *)__this->get_source_3();
		NullCheck((List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 *)L_3);
		Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F  L_4;
		L_4 = ((  Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F  (*) (List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4)->methodPointer)((List_1_t8E54CEEFCFF271362B30B91DB8B9E5DDDBCC8D45 *)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 4));
		__this->set_enumerator_6(L_4);
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_state_1(2);
		goto IL_0061;
	}

IL_002b:
	{
		Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F * L_5 = (Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F *)__this->get_address_of_enumerator_6();
		JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  L_6;
		L_6 = Enumerator_get_Current_mA2F40010AB5E3D0B7854E66406831953599A7D11_inline((Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F *)(Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F *)L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 5));
		V_1 = (JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE )L_6;
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_7 = (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)__this->get_predicate_4();
		if (!L_7)
		{
			goto IL_004d;
		}
	}
	{
		Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 * L_8 = (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)__this->get_predicate_4();
		JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  L_9 = V_1;
		NullCheck((Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)L_8);
		bool L_10;
		L_10 = ((  bool (*) (Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *, JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6)->methodPointer)((Func_2_t4A7D36F36C7BFF7FE0EA91BDC506E381E7926747 *)L_8, (JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE )L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 6));
		if (!L_10)
		{
			goto IL_0061;
		}
	}

IL_004d:
	{
		Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 * L_11 = (Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 *)__this->get_selector_5();
		JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  L_12 = V_1;
		NullCheck((Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 *)L_11);
		RuntimeObject * L_13;
		L_13 = ((  RuntimeObject * (*) (Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 *, JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7)->methodPointer)((Func_2_t57F1ECD6A7A58BC86DF60FA3DD95CB9E3066CE64 *)L_11, (JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE )L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 7));
		((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this)->set_current_2(L_13);
		return (bool)1;
	}

IL_0061:
	{
		Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F * L_14 = (Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F *)__this->get_address_of_enumerator_6();
		bool L_15;
		L_15 = Enumerator_MoveNext_mBA2E1218E317D2B755FE5DBCDD554A8D758EE9F9((Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F *)(Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F *)L_14, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 8));
		if (L_15)
		{
			goto IL_002b;
		}
	}
	{
		NullCheck((Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
		VirtActionInvoker0::Invoke(12 /* System.Void System.Linq.Enumerable/Iterator`1<System.Object>::Dispose() */, (Iterator_1_t674ABE41CF4096D4BE4D51E21FEBDADBF74CC279 *)__this);
	}

IL_0074:
	{
		return (bool)0;
	}
}
// System.Collections.Generic.IEnumerable`1<TResult> System.Linq.Enumerable/WhereSelectListIterator`2<UnityEngine.InputSystem.Utilities.JsonParser/JsonValue,System.Object>::Where(System.Func`2<TResult,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* WhereSelectListIterator_2_Where_m7C92B336E9F4C60F641A2313AC9E420137AF764E_gshared (WhereSelectListIterator_2_t7BD313142193815CBBFF1CDEAB29F9EAF147B7AA * __this, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * ___predicate0, const RuntimeMethod* method)
{
	{
		Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 * L_0 = ___predicate0;
		WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 * L_1 = (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *)il2cpp_codegen_object_new(IL2CPP_RGCTX_DATA(method->klass->rgctx_data, 10));
		((  void (*) (WhereEnumerableIterator_1_t1E9FDCFD8F8136C6A5A5740C1E093EF03F0B5CE0 *, RuntimeObject*, Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11)->methodPointer)(L_1, (RuntimeObject*)__this, (Func_2_t99409DECFF50F0FA9B427C863AC6C99C66E6F9F8 *)L_0, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->klass->rgctx_data, 11));
		return (RuntimeObject*)L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  Enumerator_get_Current_m60A7BC98ACC855A940897C0FDD226381D3E17BCD_gshared_inline (Enumerator_t579CA030F848F0F3AEEEB2BAEAF9D980604CABEF * __this, const RuntimeMethod* method)
{
	{
		KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4  L_0 = (KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4 )__this->get_current_3();
		return (KeyValuePair_2_tEFD9F29BCA12DFC2ABB550727934E646CDA919F4 )L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  Enumerator_get_Current_mB9DED66EBA82669AB83832B40F60E1710B5179B4_gshared_inline (Enumerator_t0A364062D6EEDD0B306D570939B5709AEAA88D11 * __this, const RuntimeMethod* method)
{
	{
		ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536  L_0 = (ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 )__this->get_current_3();
		return (ContourVertex_tF9E27CB6BCC62DF5F4202153BBBECDE5E3283536 )L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Enumerator_get_Current_m6BBD624C51F7E20D347FE5894A6ECA94B8011181_gshared_inline (Enumerator_t7BA00929E14A2F2A62CE085585044A3FEB2C5F3C * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = (int32_t)__this->get_current_3();
		return (int32_t)L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  Enumerator_get_Current_mDFC8852F498B3A27BD601B8B3D1AAD9EFD96ED78_gshared_inline (Enumerator_tF4F71EFD2818A255000B0F530E9D138E9FA40F72 * __this, const RuntimeMethod* method)
{
	{
		InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D  L_0 = (InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D )__this->get_current_3();
		return (InternedString_tB2087E77839CDE16F49C1292A5498F0B946FFD2D )L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  Enumerator_get_Current_mDA65875F4B6726349744D3FDA9F8F3D655CF843E_gshared_inline (Enumerator_t3F22A2E619D662922F996C766D960AF285909004 * __this, const RuntimeMethod* method)
{
	{
		NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344  L_0 = (NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344 )__this->get_current_3();
		return (NameAndParameters_tA022D2E4D2813FACDE7544B69DC653A6BFFFE344 )L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  Enumerator_get_Current_m1DAC585732F0CB8AA13B33E1015A60D953E69FA8_gshared_inline (Enumerator_tFAF6EF48ADF0D60C825202A218ABF96A534C6F66 * __this, const RuntimeMethod* method)
{
	{
		NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0  L_0 = (NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0 )__this->get_current_3();
		return (NamedValue_t9946E47B97BCA67CB906E50EBE37F895CB00B5F0 )L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject * Enumerator_get_Current_m9C4EBBD2108B51885E750F927D7936290C8E20EE_gshared_inline (Enumerator_tB6009981BD4E3881E3EC83627255A24198F902D6 * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject * L_0 = (RuntimeObject *)__this->get_current_3();
		return (RuntimeObject *)L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  Enumerator_get_Current_mCD38ED89C9598655A9824EA42E516F0F7822EF78_gshared_inline (Enumerator_t3DF313116164351EE9F1E9B225C10D9014586502 * __this, const RuntimeMethod* method)
{
	{
		GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941  L_0 = (GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941 )__this->get_current_3();
		return (GridInformationKey_tF00E3D60C37934AABE74B390BFBB85A93B4F9941 )L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  Enumerator_get_Current_mA2F40010AB5E3D0B7854E66406831953599A7D11_gshared_inline (Enumerator_tBA1BD6F4B49C8B53CF4C0E546F4D70FD3C21882F * __this, const RuntimeMethod* method)
{
	{
		JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE  L_0 = (JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE )__this->get_current_3();
		return (JsonValue_tA9412EC82DBAE03B8724A0252CAEF7701B69D6BE )L_0;
	}
}
